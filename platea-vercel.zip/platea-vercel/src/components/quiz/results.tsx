import type { ReactNode } from "react";
import { ArrowUpRight, RotateCcw, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PLATFORM_META, type Movie, type Platform } from "@/data/types";
import {
  AXIS_LABEL,
  buildProfile,
  movieSearchLinks,
  pickArchetype,
  rankMovies,
  searchRecipes,
  topAxes,
} from "@/lib/scoring";
import { useQuiz } from "@/lib/store";
import { AdSlot } from "@/components/ads/ad-slot";
import { LegalFooter } from "@/components/legal/legal-footer";

export function Results() {
  const answers = useQuiz((s) => s.answers);
  const platforms = useQuiz((s) => s.platforms);
  const reset = useQuiz((s) => s.reset);
  const goTo = useQuiz((s) => s.goTo);
  const editPlatforms = useQuiz((s) => s.editPlatforms);

  const profile = buildProfile(answers, platforms);
  const matches = rankMovies(profile).slice(0, 8);
  const tonight = matches[0];
  const archetype = pickArchetype(profile.vector);
  const axes = topAxes(profile.vector, 6);
  const maxAxis = axes[0]?.value || 1;
  const recipes = searchRecipes(profile, matches);
  const owned = platforms.length ? platforms : (profile.flags.platforms ?? []);
  const platformLine =
    owned.length > 0
      ? owned.map((p) => PLATFORM_META[p].label).join(" · ")
      : "Nessun abbonamento indicato";

  return (
    <main id="contenuto" className="mx-auto max-w-3xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="rise-in">
        <p className="text-xs font-medium tracking-[0.22em] text-muted uppercase">
          Profilo · {profile.answered} risposte
        </p>
        <h1 className="mt-4 font-display text-4xl italic leading-[1.1] text-fg md:text-[2.9rem]">
          {archetype.name}
        </h1>
        <p className="mt-3 max-w-xl text-base text-muted">{archetype.line}</p>
      </header>

      <section className="rise-in rise-in-delay-1 mt-8 rounded-lg border border-border bg-surface p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-xs font-medium tracking-[0.18em] text-subtle uppercase">
              Le tue piattaforme
            </h2>
            <p className="mt-2 text-sm text-fg">{platformLine}</p>
            <p className="mt-1 text-xs text-subtle">
              I titoli sulle librerie che hai segnato salgono in classifica.
            </p>
          </div>
          <Button variant="secondary" size="sm" className="min-h-11" onClick={editPlatforms}>
            Modifica
          </Button>
        </div>
      </section>

      <section className="rise-in rise-in-delay-1 mt-10">
        <h2 className="text-xs font-medium tracking-[0.18em] text-subtle uppercase">
          Coordinate
        </h2>
        <ul className="mt-4 space-y-3">
          {axes.map((a) => (
            <li key={a.axis} className="grid grid-cols-[8.5rem_1fr] items-center gap-3 sm:grid-cols-[10rem_1fr]">
              <span className="text-sm text-muted">{AXIS_LABEL[a.axis]}</span>
              <span className="h-1.5 overflow-hidden rounded-full bg-raised">
                <span
                  className="block h-full rounded-full bg-accent"
                  style={{ width: `${Math.max(8, (a.value / maxAxis) * 100)}%` }}
                />
              </span>
            </li>
          ))}
        </ul>
      </section>

      {tonight ? (
        <section className="rise-in rise-in-delay-2 mt-12 rounded-xl border border-border bg-surface p-6 sm:p-8">
          <p className="text-xs font-medium tracking-[0.18em] text-subtle uppercase">
            Stasera
          </p>
          <h2 className="mt-3 font-display text-2xl italic leading-tight text-fg sm:text-3xl">
            {tonight.movie.title}
          </h2>
          <Meta movie={tonight.movie} />
          <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted">
            {tonight.movie.synopsis}
          </p>
          {tonight.reasons.length ? (
            <ul className="mt-4 flex flex-wrap gap-2">
              {tonight.reasons.map((r) => (
                <li
                  key={r}
                  className="rounded-full border border-border px-3 py-1 text-xs text-muted"
                >
                  {r}
                </li>
              ))}
            </ul>
          ) : null}
          <SearchRow movie={tonight.movie} platforms={tonight.overlap.length ? tonight.overlap : owned} />
        </section>
      ) : (
        <p className="mt-10 text-muted">
          Rispondi ad almeno qualche domanda per avere una proposta.
        </p>
      )}

      <AdSlot format="feed" className="mt-10" />

      <section className="mt-12">
        <h2 className="text-xs font-medium tracking-[0.18em] text-subtle uppercase">
          Altre otto, quasi
        </h2>
        <ol className="mt-4 divide-y divide-border border-y border-border">
          {matches.slice(1).map((m, i) => (
            <li key={m.movie.id} className="py-5">
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="font-display text-xl italic text-fg">
                  <span className="mr-3 font-mono text-xs not-italic text-subtle">
                    {i + 2}
                  </span>
                  {m.movie.title}
                </h3>
                <span className="shrink-0 font-mono text-xs tabular-nums text-subtle">
                  {m.movie.year}
                </span>
              </div>
              <Meta movie={m.movie} />
              <p className="mt-2 text-sm text-muted">{m.movie.synopsis}</p>
              {m.reasons[0] ? (
                <p className="mt-2 text-xs text-subtle">{m.reasons[0]}</p>
              ) : null}
              <SearchRow movie={m.movie} platforms={m.overlap} compact />
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-12 rounded-lg border border-border bg-surface p-6">
        <div className="flex items-center gap-2 text-fg">
          <Search className="size-4 text-accent" strokeWidth={1.6} />
          <h2 className="font-display text-xl italic">Cerca sulle piattaforme</h2>
        </div>
        <p className="mt-2 text-sm text-muted">
          I cataloghi si muovono. Queste ricerche aprono JustWatch Italia o Google
          con la query giusta per il tuo profilo.
        </p>
        <ul className="mt-5 space-y-4">
          {recipes.map((r) => (
            <li key={r.label}>
              <p className="text-sm text-fg">{r.label}</p>
              <p className="font-mono text-xs text-subtle">{r.query}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <OutLink href={r.justwatch}>JustWatch</OutLink>
                <OutLink href={r.google}>Google</OutLink>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <footer className="mt-12 flex flex-col gap-3 sm:flex-row">
        <Button variant="secondary" onClick={() => goTo(0)} className="min-h-12">
          Rifinisci le risposte
        </Button>
        <Button variant="ghost" onClick={reset} className="min-h-12">
          <RotateCcw className="size-4" />
          Ricomincia
        </Button>
      </footer>
      <LegalFooter />
    </main>
  );
}

function Meta({ movie }: { movie: Movie }) {
  return (
    <p className="mt-2 text-sm text-subtle">
      {movie.director} · {movie.year} · {movie.runtime} min · {movie.country}
      {movie.originalTitle && movie.originalTitle !== movie.title
        ? ` · ${movie.originalTitle}`
        : ""}
    </p>
  );
}

function SearchRow({
  movie,
  platforms,
  compact,
}: {
  movie: Movie;
  platforms: Platform[];
  compact?: boolean;
}) {
  const links = movieSearchLinks(movie, platforms);
  return (
    <div className={compact ? "mt-3 flex flex-wrap gap-2" : "mt-6 flex flex-wrap gap-2"}>
      <OutLink href={links.justwatch}>Dove vederlo</OutLink>
      <OutLink href={links.google}>Cerca in rete</OutLink>
      {links.platformLinks.slice(0, compact ? 2 : 4).map((p) => (
        <OutLink key={p.id} href={p.href}>
          {p.label}
        </OutLink>
      ))}
    </div>
  );
}

function OutLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className="inline-flex min-h-10 items-center gap-1 rounded-sm border border-border-strong bg-raised px-3 text-xs font-medium text-fg transition-colors duration-150 hover:border-accent"
    >
      {children}
      <ArrowUpRight className="size-3.5 text-muted" />
    </a>
  );
}
