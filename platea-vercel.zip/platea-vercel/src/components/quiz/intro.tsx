import { useEffect, useState } from "react";
import { Clapperboard, Clock3, MonitorPlay } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LegalFooter } from "@/components/legal/legal-footer";
import { PLATFORM_META } from "@/data/types";
import { LEGAL } from "@/lib/legal";
import { useLegal } from "@/lib/legal-store";
import { useQuiz } from "@/lib/store";

const POINTS = [
  {
    icon: Clock3,
    title: "Cento domande, dieci atti",
    body: "Genere, tono, ritmo, compagnie. Puoi saltare: il profilo resta utile anche a metà.",
  },
  {
    icon: Clapperboard,
    title: "Un film per stasera",
    body: "Non una classifica eterna. Una proposta calibrata su come stai ora, e su quanto tempo hai.",
  },
  {
    icon: MonitorPlay,
    title: "Sulle tue piattaforme",
    body: "Prima segnati gli abbonamenti. Poi cerchi su JustWatch, Google e le app che hai già.",
  },
];

export function Intro() {
  const start = useQuiz((s) => s.start);
  const answers = useQuiz((s) => s.answers);
  const platforms = useQuiz((s) => s.platforms);
  const goTo = useQuiz((s) => s.goTo);
  const ageOk = useLegal((s) => s.ageOk);
  const confirmAge = useLegal((s) => s.confirmAge);
  const [hydrated, setHydrated] = useState(false);
  const hasProgress = Object.keys(answers).length > 0;
  const platformLine =
    platforms.length > 0
      ? platforms.map((p) => PLATFORM_META[p].label).join(" · ")
      : null;

  useEffect(() => {
    const unsub = useLegal.persist.onFinishHydration(() => setHydrated(true));
    if (useLegal.persist.hasHydrated()) setHydrated(true);
    return unsub;
  }, []);

  return (
    <main
      id="contenuto"
      className="relative mx-auto flex min-h-dvh max-w-3xl flex-col justify-between px-5 py-10 sm:px-8 sm:py-16"
    >
      <div className="pointer-events-none absolute inset-x-0 top-0 h-64 bg-[radial-gradient(ellipse_at_top,color-mix(in_oklab,var(--color-fg)_8%,transparent),transparent_70%)]" />

      <header className="rise-in relative">
        <p className="text-xs font-medium tracking-[0.22em] text-muted uppercase">Platea</p>
        <h1 className="mt-6 max-w-[14ch] font-display text-4xl italic leading-[1.05] text-fg md:text-[3.35rem]">
          Il film giusto, stasera.
        </h1>
        <p className="mt-5 max-w-lg text-base leading-relaxed text-muted">
          Un questionario di gusto, non un test di cinefilia. Prima gli
          abbonamenti, poi cento domande per capire cosa vuoi vedere adesso.
        </p>
        {platformLine ? (
          <p className="mt-3 text-sm text-subtle">Abbonamenti salvati: {platformLine}</p>
        ) : null}
      </header>

      <ul className="rise-in rise-in-delay-2 relative mt-12 grid gap-4 sm:grid-cols-3">
        {POINTS.map((item) => (
          <li
            key={item.title}
            className="rounded-lg border border-border bg-surface p-5"
          >
            <item.icon className="size-4 text-accent" strokeWidth={1.6} />
            <h2 className="mt-4 font-display text-lg text-fg italic">{item.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">{item.body}</p>
          </li>
        ))}
      </ul>

      <footer className="rise-in rise-in-delay-4 relative z-10 mt-12 flex flex-col gap-4">
        <label className="flex items-start gap-3 text-sm text-muted">
          <input
            type="checkbox"
            className="mt-1 size-4 shrink-0 accent-accent"
            checked={hydrated && ageOk}
            onChange={(e) => {
              if (e.target.checked) confirmAge();
            }}
          />
          <span>
            Ho almeno {LEGAL.ageMin} anni. Il servizio non è destinato ai minori
            di {LEGAL.ageMin}.
          </span>
        </label>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <Button
            size="lg"
            onClick={start}
            disabled={!hydrated || !ageOk}
            className="min-h-14 w-full sm:w-auto"
          >
            {platformLine ? "Aggiorna abbonamenti e inizia" : "Scegli le piattaforme"}
          </Button>
          {hasProgress ? (
            <Button
              variant="secondary"
              size="lg"
              className="min-h-14 w-full sm:w-auto"
              disabled={!hydrated || !ageOk}
              onClick={() => goTo(0)}
            >
              Riprendi il questionario
            </Button>
          ) : null}
          <p className="text-xs text-subtle sm:ml-2">
            Circa 15–20 minuti. Le risposte restano su questo dispositivo.
          </p>
        </div>
        <LegalFooter />
      </footer>
    </main>
  );
}
