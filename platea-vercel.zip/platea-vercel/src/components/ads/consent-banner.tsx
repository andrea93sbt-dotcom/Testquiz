import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { useAds } from "@/lib/ads-store";

export function ConsentBanner() {
  const [ready, setReady] = useState(false);
  const [detail, setDetail] = useState(false);
  const consent = useAds((s) => s.consent);
  const accept = useAds((s) => s.accept);
  const decline = useAds((s) => s.decline);

  useEffect(() => {
    const unsub = useAds.persist.onFinishHydration(() => setReady(true));
    if (useAds.persist.hasHydrated()) setReady(true);
    return unsub;
  }, []);

  if (!ready || consent !== "unknown") return null;

  return (
    <>
      <div className="h-56 sm:h-40" aria-hidden />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="ads-consent-title"
        className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-surface/95 p-4 backdrop-blur-md sm:p-5"
      >
        <div className="mx-auto flex max-w-3xl flex-col gap-4">
          <div>
            <p id="ads-consent-title" className="font-display text-lg italic text-fg">
              Il tuo consenso, prima di qualsiasi tracker
            </p>
            <p className="mt-1.5 text-sm leading-relaxed text-muted">
              Le risposte del quiz restano su questo dispositivo (necessarie al
              servizio). Gli annunci Google si caricano solo se accetti. Rifiutare
              è altrettanto facile: l'app funziona lo stesso.{" "}
              <Link to="/privacy" className="text-fg underline underline-offset-2">
                Privacy
              </Link>
              {" · "}
              <Link to="/cookie" className="text-fg underline underline-offset-2">
                Cookie
              </Link>
            </p>
          </div>

          {detail ? (
            <ul className="space-y-2 rounded-md border border-border bg-raised p-4 text-sm text-muted">
              <li>
                <span className="text-fg">Tecnici (sempre attivi).</span> Salvataggio
                locale del questionario, delle piattaforme e di questa scelta. Base:
                art. 6.1.b GDPR.
              </li>
              <li>
                <span className="text-fg">Pubblicità (facoltativa).</span> Cookie e
                identificatori di Google AdSense, anche verso gli USA, solo con il
                tuo sì. Base: art. 6.1.a GDPR. Puoi ritirarlo quando vuoi.
              </li>
              <li>Nessuna analitica propria. Nessun account. Nessun dato sul nostro server.</li>
            </ul>
          ) : (
            <button
              type="button"
              className="self-start text-sm text-fg underline underline-offset-2"
              onClick={() => setDetail(true)}
            >
              Dettaglio delle finalità
            </button>
          )}

          <div className="flex flex-col gap-2 sm:flex-row">
            <Button variant="secondary" className="min-h-12 flex-1" onClick={decline}>
              Rifiuta gli annunci
            </Button>
            <Button variant="secondary" className="min-h-12 flex-1" onClick={accept}>
              Accetta gli annunci
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
