import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Intro } from "@/components/quiz/intro";
import { Platforms } from "@/components/quiz/platforms";
import { QuizView } from "@/components/quiz/quiz-view";
import { Results } from "@/components/quiz/results";
import { useQuiz } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [ready, setReady] = useState(false);
  const phase = useQuiz((s) => s.phase);

  useEffect(() => {
    const unsub = useQuiz.persist.onFinishHydration(() => setReady(true));
    if (useQuiz.persist.hasHydrated()) setReady(true);
    return unsub;
  }, []);

  if (!ready || phase === "intro") return <Intro />;
  if (phase === "platforms") return <Platforms />;
  if (phase === "quiz") return <QuizView />;
  return <Results />;
}
