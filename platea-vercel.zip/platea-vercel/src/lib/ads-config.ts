/**
 * Monetizzazione: Google AdSense (web, PWA e APK via Trusted Web Activity).
 * Incolla l'ID editore approvato. Senza client gli slot restano in anteprima.
 * AdSense richiede un dominio di tua proprietà: un sottodominio ospitato
 * da terzi di solito non viene approvato.
 */
export const ADS_CONFIG = {
  client: "",
  slots: {
    banner: "",
    feed: "",
  },
} as const;

export function adsReady() {
  return /^ca-pub-\d+$/.test(ADS_CONFIG.client);
}
