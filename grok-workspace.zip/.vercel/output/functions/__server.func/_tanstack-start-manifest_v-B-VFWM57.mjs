//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B-VFWM57.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/accessibilita",
			"/condividi",
			"/cookie",
			"/privacy",
			"/termini",
			"/tag/$tag"
		],
		preloads: [
			"/assets/index-Dhv9smU7.js",
			"/assets/legal-JhscIOta.js",
			"/assets/preload-helper-DYm4R5T0.js",
			"/assets/ads-config-6dwb5IX8.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dhv9smU7.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CJyJ42po.js",
			"/assets/film-card-BvLkbqN8.js",
			"/assets/legal-footer-Bv6P2gcg.js",
			"/assets/share-DYeNdCD5.js"
		]
	},
	"/accessibilita": {
		filePath: "/workspace/src/routes/accessibilita.tsx",
		children: void 0,
		preloads: ["/assets/accessibilita-DWxFrvLS.js", "/assets/legal-page-DXwg43IH.js"]
	},
	"/condividi": {
		filePath: "/workspace/src/routes/condividi.tsx",
		children: void 0,
		preloads: [
			"/assets/condividi-K9cUVxsH.js",
			"/assets/film-card-BvLkbqN8.js",
			"/assets/legal-footer-Bv6P2gcg.js",
			"/assets/share-DYeNdCD5.js",
			"/assets/must-consent-pkJACiu4.js"
		]
	},
	"/cookie": {
		filePath: "/workspace/src/routes/cookie.tsx",
		children: void 0,
		preloads: ["/assets/cookie-Bxq_fwsD.js", "/assets/legal-page-DXwg43IH.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-DAYrX0nd.js", "/assets/legal-page-DXwg43IH.js"]
	},
	"/termini": {
		filePath: "/workspace/src/routes/termini.tsx",
		children: void 0,
		preloads: ["/assets/termini-BN9LE_Yr.js", "/assets/legal-page-DXwg43IH.js"]
	},
	"/tag/$tag": {
		filePath: "/workspace/src/routes/tag.$tag.tsx",
		children: void 0,
		preloads: [
			"/assets/tag._tag-Dc65zfQA.js",
			"/assets/film-card-BvLkbqN8.js",
			"/assets/legal-footer-Bv6P2gcg.js",
			"/assets/must-consent-pkJACiu4.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
