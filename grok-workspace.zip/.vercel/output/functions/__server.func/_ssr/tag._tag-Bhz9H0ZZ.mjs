import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as moviesForTag, f as useQuiz, n as Route } from "./router-DEhEfwv_.mjs";
import { t as LegalFooter } from "./legal-footer-V7DmZbK1.mjs";
import { t as MustConsent } from "./must-consent-ChFSqNr8.mjs";
import { h as useFilmMeta, i as Availability, n as AdSlot, o as Poster, r as AppBar, s as Tags } from "./film-card-BRhH8_dR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tag._tag-Bhz9H0ZZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE = 36;
function TagPage({ tag }) {
	const owned = useQuiz((s) => s.platforms);
	const found = (0, import_react.useMemo)(() => moviesForTag(decodeURIComponent(tag)), [tag]);
	const [shown, setShown] = (0, import_react.useState)(PAGE);
	const list = found.movies.slice(0, shown);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "mx-auto min-h-dvh max-w-xl px-4 py-8 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium tracking-[0.18em] text-ticket uppercase",
				children: [found.movies.length.toLocaleString("it-IT"), " film di questo tipo"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl italic leading-tight text-fg",
				children: found.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base leading-relaxed text-muted",
				children: "Altri film così. I primi sono quelli più vicini al tuo gusto."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-4 inline-flex min-h-11 items-center text-sm text-ticket underline-offset-2 hover:underline",
				children: "Torna all'inizio"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, {
				format: "banner",
				className: "mt-8"
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-muted",
				children: "Nessun film di questo tipo."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-10 divide-y divide-border border-y border-border",
				children: list.map((movie, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagRow, {
						movie,
						index: i + 1,
						owned
					})
				}, movie.id))
			}),
			shown < found.movies.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "mt-6 min-h-12 w-full rounded-md border border-border-strong bg-raised text-sm font-medium text-fg",
				onClick: () => setShown((n) => n + PAGE),
				children: [
					"Mostra altri (",
					(found.movies.length - shown).toLocaleString("it-IT"),
					")"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalFooter, {})
			})
		]
	});
}
function TagRow({ movie, index, owned }) {
	const meta = useFilmMeta(movie);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
			movie,
			meta,
			size: "row"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-xl italic text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mr-3 font-mono text-xs not-italic text-subtle",
						children: index
					}), movie.title]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-subtle",
					children: [
						movie.year,
						" · ",
						movie.runtime,
						" min",
						movie.director ? ` · ${movie.director}` : "",
						movie.originalTitle && movie.originalTitle !== movie.title ? ` · ${movie.originalTitle}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tags, {
					movie,
					compact: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Availability, {
					movie,
					owned
				})
			]
		})]
	});
}
function TagRoute() {
	const { tag } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MustConsent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagPage, { tag }) });
}
//#endregion
export { TagRoute as component };
