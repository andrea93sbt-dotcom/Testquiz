import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as useAds } from "./router-DEhEfwv_.mjs";
import { t as LegalPage } from "./legal-page-4iKQo5OE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cookie-D5Rvufvq.js
var import_jsx_runtime = require_jsx_runtime();
function CookiePage() {
	const consent = useAds((s) => s.consent);
	const resetConsent = useAds((s) => s.resetConsent);
	const decidedAt = useAds((s) => s.decidedAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Cookie",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Informativa resa ai sensi dell'art. 122 del d.lgs. 196/2003 e del provvedimento del Garante sull'uso dei cookie, in attuazione della direttiva ePrivacy." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Stato attuale: ",
				consent === "all" ? "hai accettato gli annunci" : consent === "none" ? "hai rifiutato gli annunci" : "non hai ancora scelto",
				decidedAt ? ` (scelta del ${new Date(decidedAt).toLocaleString("it-IT")})` : "",
				"."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-fg underline underline-offset-2",
				onClick: resetConsent,
				children: "Cambia la scelta"
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Cookie e archivi necessari" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Non richiedono consenso. Servono a far funzionare Platea." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-fg",
					children: "platea-quiz"
				}), " — risposte e piattaforme, solo su questo browser, fino a quando non le cancelli."] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-fg",
					children: "platea-ads"
				}), " — la tua scelta sugli annunci."] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-fg",
					children: "platea-legal"
				}), " — conferma di età minima."] })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Pubblicità (facoltativa)" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Solo dopo un sì distinto. Rifiutare ha la stessa evidenza visiva dell'accettare. Si carica allora lo script di Google AdSense, che può impostare cookie e identificatori propri (anche di profilazione). Elenco aggiornato presso Google:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://policies.google.com/privacy",
					rel: "noreferrer",
					target: "_blank",
					children: "Privacy Policy Google"
				}),
				"."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Gli spazi sono etichettati «Pubblicità». Non sono inserzioni di Platea: sono di terzi. Il catalogo film non è personalizzato da Google." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Cosa non usiamo" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Nessuna analitica propria (niente Google Analytics, Meta Pixel, ecc.)." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Nessun cookie di social plugin." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "I font sono ospitati con l'app: nessuna richiesta a Google Fonts." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Segnali globali" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Se il browser invia Global Privacy Control, gli annunci restano disattivati." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Altre informative" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/privacy",
					children: "Privacy"
				}),
				" · ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/termini",
					children: "Termini"
				})
			] })
		]
	});
}
//#endregion
export { CookiePage as component };
