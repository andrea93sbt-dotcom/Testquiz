import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as controllerLabel, t as LEGAL } from "./legal-footer-EkpRMsjk.mjs";
import { t as LegalPage } from "./legal-page-DqFRmc41.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/termini-Bk6LqtV4.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Termini di utilizzo",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Usando Platea accetti questi termini. Se non li accetti, non usare l'app. Servizio rivolto a chi ha almeno ",
				LEGAL.ageMin,
				" anni."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "1. Cos'è Platea" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Uno strumento gratuito di suggerimento cinematografico. Non è un catalogo ufficiale di Netflix, Prime Video o altre piattaforme. I link di ricerca aprono siti di terzi. La disponibilità dei titoli cambia senza preavviso." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "2. Editore" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Il servizio è pubblicato da ",
				controllerLabel(),
				"."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "3. Proprietà intellettuale" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Marchi, titoli e opere citati appartengono ai rispettivi titolari. Platea non rivendica diritti sui film. È lecito citarli per indicarli come possibile visione. Non offriamo copie, streaming né poster protetti." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "4. Pubblicità" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Eventuali annunci sono di terzi, etichettati come tali (Regolamento UE 2022/2065, DSA). Non sono una raccomandazione editoriale." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "5. Nessuna garanzia" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I suggerimenti sono statistici e culturali, non un consiglio professionale. Nei limiti di legge non rispondiamo di inesattezze del catalogo, di interruzioni o di contenuti aperti tramite link esterni (JustWatch, Google, piattaforme)." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "6. Pratiche commerciali" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nessun acquisto in-app. Nessun abbonamento a Platea. Non usiamo preselezioni occulte sul consenso. I prezzi di terzi, se compaiono in un annuncio, sono responsabilità dell'inserzionista." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "7. Legge e foro" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Si applica il diritto ",
				LEGAL.jurisdiction === "Italia" ? "italiano" : LEGAL.jurisdiction,
				" e, per i consumatori UE, le norme inderogabili del Paese di residenza (Reg. 1215/2012, direttiva 2011/83/UE)."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/privacy",
					children: "Privacy"
				}),
				" · ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/cookie",
					children: "Cookie"
				})
			] })
		]
	});
}
//#endregion
export { TermsPage as component };
