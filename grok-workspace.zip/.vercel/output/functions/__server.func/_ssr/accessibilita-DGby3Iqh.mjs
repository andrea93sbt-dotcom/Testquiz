import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as LEGAL } from "./legal-footer-EkpRMsjk.mjs";
import { t as LegalPage } from "./legal-page-DqFRmc41.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/accessibilita-DGby3Iqh.js
var import_jsx_runtime = require_jsx_runtime();
function A11yPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Dichiarazione di accessibilità",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Platea è progettata in linea con i principi della Direttiva (UE) 2019/882 (European Accessibility Act) e delle WCAG 2.2 livello AA, per quanto applicabile a un questionario web." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Cosa c'è" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Lingua della pagina dichiarata (italiano)." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Contrasto alto su fondo scuro, un solo accento." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Aree cliccabili di almeno 44px, navigazione da tastiera." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stati di focus visibili; rispetto di «prefers-reduced-motion»." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Dialog di consenso con titolo e alternative testuali." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Possibilità di saltare domande e di usare l'app senza annunci." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Limiti noti" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Il questionario è lungo: offriamo salvataggio locale e uscita anticipata dopo venti risposte. I siti di terzi aperti dai link (JustWatch, piattaforme) hanno la loro accessibilità, fuori dal nostro controllo." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Segnalazioni" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				LEGAL.controllerEmail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"Scrivi a ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `mailto:${LEGAL.controllerEmail}`,
						children: LEGAL.controllerEmail
					}),
					"."
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "L'editore deve pubblicare un recapito in questa pagina." }),
				" ",
				"In Italia puoi anche rivolgerti all'AgID o all'autorità competente in materia di accessibilità."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "Torna a Platea"
			}) })
		]
	});
}
//#endregion
export { A11yPage as component };
