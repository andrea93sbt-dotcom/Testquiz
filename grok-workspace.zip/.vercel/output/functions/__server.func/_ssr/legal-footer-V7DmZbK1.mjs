import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as useAds } from "./router-DEhEfwv_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/legal-footer-V7DmZbK1.js
var import_jsx_runtime = require_jsx_runtime();
var LINKS = [
	{
		to: "/privacy",
		label: "Privacy"
	},
	{
		to: "/cookie",
		label: "Cookie"
	},
	{
		to: "/termini",
		label: "Termini"
	},
	{
		to: "/accessibilita",
		label: "Accessibilità"
	}
];
function LegalFooter() {
	useAds((s) => s.consent);
	useAds((s) => s.resetConsent);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		"aria-label": "Informazioni legali",
		className: "mt-10 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-border pt-5 text-xs text-subtle",
		children: [LINKS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: l.to,
			className: "min-h-11 inline-flex items-center underline-offset-2 hover:text-muted hover:underline",
			children: l.label
		}, l.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "/platea-vercel.zip",
			download: "platea-vercel.zip",
			className: "min-h-11 inline-flex items-center underline-offset-2 hover:text-muted hover:underline",
			children: "Scarica una copia del sito"
		})]
	});
}
//#endregion
export { LegalFooter as t };
