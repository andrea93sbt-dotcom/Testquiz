import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Play } from "../_libs/lucide-react.mjs";
import { E as useAds, S as QUESTIONS, c as ADS_CONFIG, d as unlockAudio, f as useQuiz, g as PLATFORM_META, l as adsReady, m as AXES, o as Button, s as cn, v as MOVIES, y as movieById } from "./router-DEhEfwv_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/film-card-BRhH8_dR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AppBar() {
	const home = useQuiz((s) => s.home);
	const decline = useAds((s) => s.decline);
	const navigate = useNavigate();
	const [askOff, setAskOff] = (0, import_react.useState)(false);
	const toMenu = () => {
		home();
		navigate({ to: "/" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				className: "min-h-11 px-2",
				onClick: toMenu,
				children: "Torna all'inizio"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "inline-flex min-h-11 items-center rounded-md border border-border bg-raised px-3 text-sm text-fg",
				onClick: () => setAskOff((v) => !v),
				"aria-expanded": askOff,
				children: "Annunci accesi"
			})]
		}), askOff ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-md border border-border bg-surface p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Gli annunci tengono Platea gratis. Se li spegni, torni all'inizio e non puoi giocare."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					className: "min-h-11",
					onClick: () => setAskOff(false),
					children: "Tienili accesi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					className: "min-h-11",
					onClick: () => {
						decline();
						toMenu();
					},
					children: "Spegni e esci"
				})]
			})]
		}) : null]
	});
}
function AdSlot({ format, className }) {
	const consent = useAds((s) => s.consent);
	const live = adsReady() && consent === "all";
	const slot = ADS_CONFIG.slots[format];
	const pushed = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!live || !slot || pushed.current) return;
		try {
			(window.adsbygoogle = window.adsbygoogle || []).push({});
			pushed.current = true;
		} catch {}
	}, [live, slot]);
	if (consent === "none") return null;
	const tall = format === "feed";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		"aria-label": "Pubblicità",
		className: cn("overflow-hidden rounded-md border border-border bg-raised", tall ? "min-h-40" : "min-h-20", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "border-b border-border px-3 py-1.5 text-xs tracking-[0.16em] text-subtle uppercase",
			children: "Pubblicità"
		}), live && slot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ins", {
			className: cn("adsbygoogle block w-full", tall ? "min-h-72" : "min-h-24"),
			"data-ad-client": ADS_CONFIG.client,
			"data-ad-slot": slot,
			"data-ad-format": "auto",
			"data-full-width-responsive": "true"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
			tall,
			waitingConsent: consent !== "all"
		})]
	});
}
function Preview({ tall, waitingConsent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-col items-center justify-center gap-1 px-4 text-center", tall ? "min-h-36 py-8" : "min-h-16 py-4"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: waitingConsent ? "Lo spazio si attiva se accetti gli annunci." : "Qui comparirà un annuncio."
		}), waitingConsent ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-subtle",
			children: "Per ora è vuoto: non è un inserzionista reale."
		})]
	});
}
var mem = /* @__PURE__ */ new Map();
var emptyMeta = () => ({
	poster: null,
	plot: null,
	wikiTitle: null,
	wikiLang: null,
	trailerId: null
});
async function loadFilmMeta(movie) {
	const cached = mem.get(movie.id) ?? readSession(movie.id);
	if (cached) {
		const full = {
			...emptyMeta(),
			...cached
		};
		if (full.trailerId || cached.trailerId === null) {
			mem.set(movie.id, full);
			return full;
		}
	}
	const [wiki, trailerId] = await Promise.all([wikiLookup(movie), youtubeTrailerId(movie.id)]);
	const merged = {
		...wiki ?? emptyMeta(),
		trailerId
	};
	mem.set(movie.id, merged);
	writeSession(movie.id, merged);
	return merged;
}
function youtubeSearchUrl(movie) {
	const name = movie.originalTitle && movie.originalTitle !== movie.title ? movie.originalTitle : movie.title;
	return `https://www.youtube.com/results?search_query=${encodeURIComponent(`${name} ${movie.year} trailer ufficiale`)}`;
}
function youtubeEmbedUrl(id) {
	return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?rel=0&modestbranding=1`;
}
function readSession(key) {
	try {
		const raw = sessionStorage.getItem(`platea-film:${key}`);
		return raw ? JSON.parse(raw) : null;
	} catch {
		return null;
	}
}
function writeSession(key, meta) {
	try {
		sessionStorage.setItem(`platea-film:${key}`, JSON.stringify(meta));
	} catch {}
}
async function wikiLookup(movie) {
	const queries = [
		`${movie.title} ${movie.year} film`,
		movie.originalTitle ? `${movie.originalTitle} ${movie.year} film` : null,
		`${movie.title} film`
	].filter((q) => Boolean(q));
	for (const lang of ["it", "en"]) for (const q of queries) {
		const hit = await wikiPage(lang, q);
		if (hit && (hit.poster || hit.plot)) return hit;
	}
	return null;
}
async function wikiPage(lang, query) {
	const url = new URL(`https://${lang}.wikipedia.org/w/api.php`);
	url.searchParams.set("action", "query");
	url.searchParams.set("format", "json");
	url.searchParams.set("origin", "*");
	url.searchParams.set("generator", "search");
	url.searchParams.set("gsrsearch", query);
	url.searchParams.set("gsrlimit", "1");
	url.searchParams.set("prop", "pageimages|extracts");
	url.searchParams.set("piprop", "thumbnail");
	url.searchParams.set("pithumbsize", "480");
	url.searchParams.set("explaintext", "1");
	url.searchParams.set("exsectionformat", "plain");
	url.searchParams.set("exchars", "3500");
	try {
		const res = await fetch(url.toString());
		if (!res.ok) return null;
		const data = await res.json();
		const page = Object.values(data.query?.pages ?? {})[0];
		if (!page) return null;
		const blob = `${page.title} ${page.extract ?? ""}`.toLowerCase();
		if (!/\b(film|movie|cinema|regist|director)\b/.test(blob)) return null;
		return {
			poster: page.thumbnail?.source ?? null,
			plot: takePlot(page.extract ?? "", lang),
			wikiTitle: page.title,
			wikiLang: lang,
			trailerId: null
		};
	} catch {
		return null;
	}
}
function takePlot(extract, lang) {
	const heading = lang === "it" ? "(?:Trama|Sinossi|Plot)" : "(?:Plot|Synopsis|Premise)";
	const raw = (extract.match(new RegExp(`(?:^|\\n)${heading}\\n+([\\s\\S]+?)(?:\\n[^\\n]{1,48}\\n|$)`, "i"))?.[1] ?? "").replace(/\s+/g, " ").trim();
	return raw.length >= 80 ? raw : null;
}
async function youtubeTrailerId(imdbId) {
	if (!/^tt\d+$/.test(imdbId)) return null;
	const query = `SELECT ?yt WHERE { ?item wdt:P345 "${imdbId}" . ?item wdt:P1651 ?yt } LIMIT 1`;
	const url = `https://query.wikidata.org/sparql?format=json&query=${encodeURIComponent(query)}`;
	try {
		const res = await fetch(url, { headers: { Accept: "application/sparql-results+json" } });
		if (!res.ok) return null;
		const raw = (await res.json()).results?.bindings?.[0]?.yt?.value ?? "";
		return raw.match(/(?:v=|youtu\.be\/)?([A-Za-z0-9_-]{11})$/)?.[1] ?? (/^[A-Za-z0-9_-]{11}$/.test(raw) ? raw : null);
	} catch {
		return null;
	}
}
var AXIS_LABEL = {
	azione: "azione",
	commedia: "commedia",
	dramma: "dramma",
	thriller: "thriller",
	horror: "horror",
	scifi: "fantascienza",
	romance: "storie d'amore",
	crime: "crime",
	fantasy: "fantasy",
	animazione: "animazione",
	documentario: "documentario",
	avventura: "avventura",
	guerra: "guerra",
	mistero: "mistero",
	biografico: "biografie",
	western: "western",
	musical: "musical",
	leggero: "film leggeri",
	oscuro: "film cupi",
	teso: "tensione",
	malinconico: "malinconia",
	sollevante: "film allegri",
	strano: "film strani",
	ironico: "ironia",
	lento: "ritmo lento",
	veloce: "ritmo veloce",
	semplice: "facile da seguire",
	complesso: "film impegnativi",
	intimo: "storie intime",
	spettacolo: "grande spettacolo",
	stilizzato: "stile marcato",
	dialoghi: "dialoghi",
	immagini: "immagini",
	classico: "classici",
	moderno: "film recenti",
	italiano: "cinema italiano",
	hollywood: "Hollywood",
	europa: "Europa",
	asia: "Asia",
	speranza: "finali che rialzano",
	cinico: "film cinici",
	vero: "storie vere",
	famiglia: "famiglia",
	amore: "amore",
	potere: "potere",
	identita: "identità",
	breve: "film corti",
	lungo: "film lunghi"
};
function emptyVector() {
	return Object.fromEntries(AXES.map((a) => [a, 0]));
}
function buildProfile(answers, subscribed = [], seen = {}) {
	const vector = emptyVector();
	const flags = {
		platforms: [],
		avoid: [],
		require: []
	};
	let answered = 0;
	for (const question of QUESTIONS) {
		const picked = answers[question.id];
		if (!picked?.length) continue;
		answered += 1;
		const chapterBoost = question.ch === 1 ? 2.3 : question.ch === 10 ? 1.4 : 1;
		const share = 1 / picked.length;
		for (const optId of picked) {
			const opt = question.opts.find((o) => o.id === optId);
			if (!opt) continue;
			for (const [axis, value] of Object.entries(opt.w)) vector[axis] += value * chapterBoost * share;
			const f = opt.f;
			if (!f) continue;
			if (f.maxMinutes != null) flags.maxMinutes = flags.maxMinutes ? Math.min(flags.maxMinutes, f.maxMinutes) : f.maxMinutes;
			if (f.minMinutes != null) flags.minMinutes = flags.minMinutes ? Math.max(flags.minMinutes, f.minMinutes) : f.minMinutes;
			if (f.minYear != null) flags.minYear = flags.minYear ? Math.max(flags.minYear, f.minYear) : f.minYear;
			if (f.maxYear != null) flags.maxYear = flags.maxYear ? Math.min(flags.maxYear, f.maxYear) : f.maxYear;
			if (f.platforms) flags.platforms = [.../* @__PURE__ */ new Set([...flags.platforms ?? [], ...f.platforms])];
			if (f.avoid) flags.avoid = [.../* @__PURE__ */ new Set([...flags.avoid ?? [], ...f.avoid])];
			if (f.require) flags.require = [.../* @__PURE__ */ new Set([...flags.require ?? [], ...f.require])];
			if (f.company) flags.company = f.company;
			if (f.dubbed) flags.dubbed = true;
			if (f.kidsOk) flags.kidsOk = true;
		}
	}
	for (const [id, verdict] of Object.entries(seen)) {
		const movie = movieById(id);
		if (!movie) continue;
		if (verdict === "unseen") continue;
		answered += 1;
		const scale = verdict === "like" ? 2.4 : -1.6;
		for (const [axis, value] of Object.entries(movie.v)) vector[axis] += value * scale;
		if (verdict === "dislike") {
			const top = Object.entries(movie.v).sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0)).slice(0, 1).map(([axis]) => axis);
			flags.avoid = [.../* @__PURE__ */ new Set([...flags.avoid ?? [], ...top])];
		}
	}
	if (subscribed.length) flags.platforms = [.../* @__PURE__ */ new Set([...subscribed, ...flags.platforms ?? []])];
	return {
		vector,
		flags,
		answered,
		seen
	};
}
function topAxes(vector, n = 6) {
	return AXES.map((axis) => ({
		axis,
		value: vector[axis]
	})).filter((x) => x.value > .8).sort((a, b) => b.value - a.value).slice(0, n);
}
function pickArchetype(vector) {
	const packs = [
		{
			name: "Serata comoda",
			line: "Stasera vuoi un film che ti fa stare bene.",
			axes: [
				"commedia",
				"leggero",
				"semplice",
				"sollevante",
				"breve"
			]
		},
		{
			name: "Voglia di azione",
			line: "Vuoi ritmo, inseguimenti e qualcosa di grande da vedere.",
			axes: [
				"azione",
				"spettacolo",
				"veloce",
				"hollywood",
				"avventura"
			]
		},
		{
			name: "Ti piace il brivido",
			line: "Vuoi un film che ti tiene teso, non rumore a caso.",
			axes: [
				"horror",
				"teso",
				"oscuro",
				"thriller"
			]
		},
		{
			name: "Film da lasciare in testa",
			line: "Tempi lunghi, e qualcosa a cui pensare dopo.",
			axes: [
				"lento",
				"malinconico",
				"intimo",
				"complesso",
				"immagini"
			]
		},
		{
			name: "Mondi nuovi",
			line: "Idee e posti che non esistono.",
			axes: [
				"scifi",
				"complesso",
				"fantasy",
				"spettacolo"
			]
		},
		{
			name: "Amore, senza troppi zuccheri",
			line: "Una storia d'amore, non un melodramma.",
			axes: [
				"romance",
				"amore",
				"intimo",
				"malinconico"
			]
		},
		{
			name: "Storie vere",
			line: "Persone vere, niente costume.",
			axes: [
				"vero",
				"biografico",
				"dramma",
				"crime"
			]
		},
		{
			name: "Fuori dal solito",
			line: "Non solo i film che senti nominare sempre.",
			axes: [
				"europa",
				"asia",
				"italiano",
				"classico"
			]
		}
	];
	let best = packs[0];
	let bestScore = -1;
	for (const pack of packs) {
		const score = pack.axes.reduce((n, axis) => n + (vector[axis] ?? 0), 0);
		if (score > bestScore) {
			best = pack;
			bestScore = score;
		}
	}
	return {
		name: best.name,
		line: best.line
	};
}
function cosine(a, b) {
	let dot = 0;
	let na = 0;
	let nb = 0;
	for (const axis of AXES) {
		const va = a[axis] ?? 0;
		const vb = b[axis] ?? 0;
		dot += va * vb;
		na += va * va;
		nb += vb * vb;
	}
	if (na === 0 || nb === 0) return 0;
	return dot / (Math.sqrt(na) * Math.sqrt(nb));
}
function reasonsFor(movie, profile) {
	const shared = topAxes(profile.vector, 8).filter((t) => (movie.v[t.axis] ?? 0) >= 5).slice(0, 3).map((t) => AXIS_LABEL[t.axis]);
	const out = [];
	if (shared.length) out.push(`Perché: ${shared.join(", ")}`);
	if (profile.flags.maxMinutes && movie.runtime <= profile.flags.maxMinutes) out.push(`Dura ${movie.runtime} min, come volevi`);
	if (profile.flags.company === "famiglia" && movie.kidsOk) out.push("Va bene in famiglia");
	const owned = profile.flags.platforms ?? [];
	const on = movie.platforms.filter((p) => owned.includes(p));
	if (on.length) out.push(`Da cercare su ${on.map((p) => PLATFORM_META[p].label).join(", ")}`);
	if (movie.tags.length) out.push(movie.tags.slice(0, 3).join(" · "));
	return out.slice(0, 3);
}
function rankMovies(profile) {
	const { vector, flags, seen } = profile;
	const owned = new Set(flags.platforms ?? []);
	return MOVIES.map((movie) => {
		let score = cosine(vector, movie.v) * 100;
		if (flags.maxMinutes && movie.runtime > flags.maxMinutes + 8) score *= .42;
		if (flags.minMinutes && movie.runtime < flags.minMinutes - 10) score *= .75;
		if (flags.minYear && movie.year < flags.minYear) score *= .55;
		if (flags.maxYear && movie.year > flags.maxYear) score *= .55;
		if (flags.kidsOk && flags.company === "famiglia" && !movie.kidsOk) score *= .25;
		if (flags.company === "famiglia" && (movie.v.horror ?? 0) > 5) score *= .2;
		if (flags.avoid) {
			for (const axis of flags.avoid) if ((movie.v[axis] ?? 0) >= 6) score *= .28;
		}
		if (flags.require) {
			for (const axis of flags.require) if ((movie.v[axis] ?? 0) < 5) score *= .5;
		}
		const overlap = owned.size ? movie.platforms.filter((p) => owned.has(p)) : movie.platforms.slice(0, 3);
		if (movie.platforms.length && owned.size && overlap.length) score *= 1.28 + overlap.length * .06;
		else if (movie.platforms.length && owned.size && overlap.length === 0) score *= .68;
		const verdict = seen[movie.id];
		if (verdict === "dislike") score *= .02;
		else if (verdict === "like") score *= .42;
		else if (verdict === "unseen") score *= 1.06;
		return {
			movie,
			score,
			reasons: reasonsFor(movie, profile),
			overlap
		};
	}).filter((m) => m.movie.runtime > 40).sort((a, b) => b.score - a.score);
}
function searchRecipes(profile, matches) {
	const axes = topAxes(profile.vector, 5).map((t) => AXIS_LABEL[t.axis]);
	const first = matches[0]?.movie;
	const q1 = axes.slice(0, 3).join(" ");
	const q2 = first ? `${first.title} ${first.year} streaming` : q1;
	const mk = (label, query) => ({
		label,
		query,
		justwatch: `https://www.justwatch.com/it/ricerca?q=${encodeURIComponent(query)}`,
		google: `https://www.google.com/search?q=${encodeURIComponent(query + " film streaming")}`
	});
	return [mk("Cerca film di questo tipo", q1 || "film stasera"), mk("Cerca a partire da questo film", q2)];
}
function movieSearchLinks(movie, _platforms = []) {
	const q = `${movie.title} ${movie.year}`;
	return {
		justwatch: `https://www.justwatch.com/it/ricerca?q=${encodeURIComponent(q)}`,
		google: `https://www.google.com/search?q=${encodeURIComponent(q + " dove vederlo")}`
	};
}
function useFilmMeta(movie) {
	const [meta, setMeta] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		loadFilmMeta(movie).then((m) => {
			if (live) setMeta(m);
		});
		return () => {
			live = false;
		};
	}, [movie.id]);
	return meta;
}
function Poster({ movie, meta, size }) {
	const src = meta?.poster;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
		className: cn("shrink-0 overflow-hidden rounded-md bg-raised ring-2 ring-paper/80", size === "hero" ? "w-36 sm:w-40" : "w-[4.5rem] sm:w-20"),
		children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: `Locandina di ${movie.title}`,
			width: size === "hero" ? 160 : 80,
			height: size === "hero" ? 240 : 120,
			className: "aspect-[2/3] w-full object-cover",
			referrerPolicy: "no-referrer"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex aspect-[2/3] w-full items-center justify-center bg-raised px-2 text-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-sm italic leading-tight text-paper",
				children: movie.title
			})
		})
	});
}
function Tags({ movie, compact, linked = true }) {
	const tags = compact ? movie.tags.slice(0, 6) : movie.tags;
	if (!tags.length) return null;
	const chip = "inline-flex min-h-10 items-center rounded-sm border border-border bg-raised px-2 py-0.5 text-xs leading-snug text-muted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 flex flex-wrap gap-1.5",
		children: tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: linked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/tag/$tag",
			params: { tag: t },
			className: `${chip} transition-colors duration-150 hover:border-accent hover:text-fg`,
			children: t
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: chip,
			children: t
		}) }, t))
	});
}
function Availability({ movie, owned }) {
	const links = movieSearchLinks(movie, owned);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3",
		children: [owned.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-wrap gap-2",
			children: owned.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: PLATFORM_META[p].search(movie.title),
				target: "_blank",
				rel: "noreferrer",
				className: "inline-flex min-h-10 items-center rounded-sm border border-ok/50 bg-ok/15 px-2.5 text-xs font-medium text-fg",
				children: PLATFORM_META[p].label
			}) }, p))
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: links.justwatch,
			target: "_blank",
			rel: "noreferrer",
			className: "mt-2 inline-flex min-h-10 items-center text-xs font-medium text-ticket underline-offset-2 hover:underline",
			children: "Dove si vede adesso"
		})]
	});
}
function Plot({ movie, meta, compact }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const plot = meta?.plot;
	const teaser = compact ? movie.synopsis : plot ?? movie.synopsis;
	const shown = open && plot ? plot : teaser;
	const wiki = meta?.wikiTitle && meta.wikiLang ? `https://${meta.wikiLang}.wikipedia.org/wiki/${encodeURIComponent(meta.wikiTitle.replace(/ /g, "_"))}` : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("text-sm leading-relaxed text-muted", !open && compact && "line-clamp-2", !open && !compact && plot && "line-clamp-5"),
			children: shown
		}),
		plot && plot !== movie.synopsis ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-2 min-h-11 text-left text-xs font-medium text-ticket underline-offset-2 hover:underline",
			onClick: () => setOpen((v) => !v),
			children: open ? "Nascondi" : compact ? "Leggi la trama" : "Tutta la trama"
		}) : null,
		wiki ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-[11px] text-subtle",
			children: [
				"Locandina e trama da",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: wiki,
					target: "_blank",
					rel: "noreferrer",
					className: "underline underline-offset-2",
					children: "Wikipedia"
				}),
				", licenza CC BY-SA."
			]
		}) : null
	] });
}
function Trailer({ movie, meta }) {
	const [on, setOn] = (0, import_react.useState)(false);
	const search = youtubeSearchUrl(movie);
	const embed = meta?.trailerId ? youtubeEmbedUrl(meta.trailerId) : null;
	if (!meta) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-5 text-sm text-subtle",
		children: "Cerco il trailer…"
	});
	if (on && embed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-5 overflow-hidden rounded-md bg-raised ring-2 ring-paper/80",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative aspect-video",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				title: `Trailer di ${movie.title}`,
				src: `${embed}&autoplay=1`,
				className: "absolute inset-0 h-full w-full",
				allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
				allowFullScreen: true,
				referrerPolicy: "strict-origin-when-cross-origin"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: `https://www.youtube.com/watch?v=${meta?.trailerId}`,
			target: "_blank",
			rel: "noreferrer",
			className: "block px-3 py-2 text-xs text-subtle underline-offset-2 hover:text-muted hover:underline",
			children: "Apri su YouTube"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-5 flex flex-wrap gap-2",
		children: embed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => {
				unlockAudio();
				setOn(true);
			},
			className: "inline-flex min-h-12 items-center gap-2 rounded-md bg-accent px-4 text-sm font-medium text-accent-fg hover:bg-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Guarda il trailer"]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: search,
			target: "_blank",
			rel: "noreferrer",
			className: "inline-flex min-h-12 items-center gap-2 rounded-md bg-accent px-4 text-sm font-medium text-accent-fg hover:bg-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Guarda il trailer"]
		})
	});
}
//#endregion
export { Plot as a, Trailer as c, pickArchetype as d, rankMovies as f, youtubeSearchUrl as g, useFilmMeta as h, Availability as i, buildProfile as l, topAxes as m, AdSlot as n, Poster as o, searchRecipes as p, AppBar as r, Tags as s, AXIS_LABEL as t, movieSearchLinks as u };
