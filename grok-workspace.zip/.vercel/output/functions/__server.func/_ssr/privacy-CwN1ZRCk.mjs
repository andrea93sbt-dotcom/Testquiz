import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Button } from "./router-DAzBTxrJ.mjs";
import { r as controllerLabel, t as LEGAL } from "./legal-footer-EkpRMsjk.mjs";
import { t as LegalPage } from "./legal-page-DqFRmc41.mjs";
import { n as wipeLocalData } from "./legal-store-CWyb5xZR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-CwN1ZRCk.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	const who = controllerLabel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Informativa sulla privacy",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Questa informativa è resa ai sensi degli artt. 13 e 14 del Regolamento (UE) 2016/679 (GDPR) e del d.lgs. 196/2003. Platea è un questionario di gusto cinematografico che gira nel tuo browser." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "1. Titolare del trattamento" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Il titolare è ",
				who,
				".",
				LEGAL.controllerEmail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					" ",
					"Recapito:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `mailto:${LEGAL.controllerEmail}`,
						children: LEGAL.controllerEmail
					}),
					"."
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" ", "L'editore deve indicare nome, recapito e, se tenuta, la partita IVA in questa pagina prima di una pubblicazione commerciale."] })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "2. Dati trattati e dove stanno" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Non c'è un account. Non inviamo le tue risposte a un nostro server. Restano in ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
					className: "font-mono text-fg",
					children: "localStorage"
				}),
				" su questo dispositivo:"
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "risposte al questionario e piattaforme che hai segnato;" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "scelta sul consenso cookie/annunci e conferma dell'età;" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "se accetti gli annunci, Google può trattare identificatori, IP approssimato e dati di navigazione secondo la sua informativa." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Non trattiamo categorie particolari di dati. Non profiliamo i gusti cinematografici fuori da questo dispositivo." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "3. Finalità e basi giuridiche" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Erogare il questionario e i suggerimenti (art. 6.1.b GDPR — servizio richiesto)." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Memorizzare la tua scelta di consenso (art. 6.1.c / 6.1.f e art. 122 Codice Privacy)." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Pubblicità di terze parti, solo con consenso libero e specifico (art. 6.1.a GDPR e direttiva ePrivacy). Il consenso è ritirabile in ogni momento, con la stessa facilità con cui è stato dato." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "4. Trasferimenti extra-SEE" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Il servizio di base non trasferisce dati. Se accetti gli annunci, Google LLC (Stati Uniti) può trattare dati. Google aderisce al Data Privacy Framework UE-USA e usa clausole contrattuali tipo. Senza consenso, lo script di AdSense non viene caricato." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "5. Conservazione" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I dati locali restano finché non li cancelli, non pulisci il browser o non usi il pulsante sotto. Google conserva i propri dati secondo i suoi termini." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "6. I tuoi diritti" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Accesso, rettifica, cancellazione, limitazione, opposizione, portabilità, revoca del consenso, reclamo all'autorità. Per i dati che stanno solo sul dispositivo, la cancellazione è immediata:" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				className: "min-h-11",
				onClick: wipeLocalData,
				children: "Cancella i dati su questo dispositivo"
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Reclamo: ",
				LEGAL.supervisory,
				". Puoi anche rivolgerti all'autorità del tuo Paese UE."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "7. Minori" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Il servizio è pensato per chi ha almeno ",
				LEGAL.ageMin,
				" anni (pubblicità inclusa). Non è destinato a chi ha meno di 16 anni."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "8. Cookie" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Dettaglio in ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/cookie",
					children: "Informativa cookie"
				}),
				"."
			] })
		]
	});
}
//#endregion
export { PrivacyPage as component };
