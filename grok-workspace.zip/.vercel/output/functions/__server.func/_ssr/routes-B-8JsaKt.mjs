import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Clock3, c as ChevronLeft, i as MonitorPlay, l as Check, n as Search, o as Clapperboard, r as RotateCcw, s as ChevronRight, u as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as ADS_CONFIG, i as useAds, n as Button, o as adsReady, r as cn } from "./router-DAzBTxrJ.mjs";
import { n as LegalFooter, t as LEGAL } from "./legal-footer-EkpRMsjk.mjs";
import { t as useLegal } from "./legal-store-CWyb5xZR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B-8JsaKt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AXES = [
	"azione",
	"commedia",
	"dramma",
	"thriller",
	"horror",
	"scifi",
	"romance",
	"crime",
	"fantasy",
	"animazione",
	"documentario",
	"avventura",
	"guerra",
	"mistero",
	"biografico",
	"western",
	"musical",
	"leggero",
	"oscuro",
	"teso",
	"malinconico",
	"sollevante",
	"strano",
	"ironico",
	"lento",
	"veloce",
	"semplice",
	"complesso",
	"intimo",
	"spettacolo",
	"stilizzato",
	"dialoghi",
	"immagini",
	"classico",
	"moderno",
	"italiano",
	"hollywood",
	"europa",
	"asia",
	"speranza",
	"cinico",
	"vero",
	"famiglia",
	"amore",
	"potere",
	"identita",
	"breve",
	"lungo"
];
var PLATFORMS = [
	"netflix",
	"prime",
	"disney",
	"apple",
	"now",
	"mubi",
	"raiplay",
	"paramount"
];
var PLATFORM_META = {
	netflix: {
		label: "Netflix",
		search: (q) => `https://www.netflix.com/search?q=${encodeURIComponent(q)}`
	},
	prime: {
		label: "Prime Video",
		search: (q) => `https://www.primevideo.com/search?phrase=${encodeURIComponent(q)}`
	},
	disney: {
		label: "Disney+",
		search: (q) => `https://www.disneyplus.com/search/${encodeURIComponent(q)}`
	},
	apple: {
		label: "Apple TV",
		search: (q) => `https://tv.apple.com/search?term=${encodeURIComponent(q)}`
	},
	now: {
		label: "NOW",
		search: (q) => `https://www.nowtv.it/search?q=${encodeURIComponent(q)}`
	},
	mubi: {
		label: "MUBI",
		search: (q) => `https://mubi.com/it/search/${encodeURIComponent(q)}`
	},
	raiplay: {
		label: "RaiPlay",
		search: (q) => `https://www.raiplay.it/ricerca.html?q=${encodeURIComponent(q)}`
	},
	paramount: {
		label: "Paramount+",
		search: (q) => `https://www.paramountplus.com/search/?q=${encodeURIComponent(q)}`
	}
};
function q(id, ch, prompt, raw, extra) {
	return {
		id,
		ch,
		q: prompt,
		hint: extra?.hint,
		type: extra?.type ?? "single",
		opts: raw.map(([label, w, f], i) => ({
			id: `${id}-${i}`,
			label,
			w,
			f
		}))
	};
}
var QUESTIONS = [
	q(1, 1, "Quanto tempo hai, stasera?", [
		[
			"Meno di 90 minuti",
			{ breve: 9 },
			{ maxMinutes: 100 }
		],
		[
			"Circa due ore",
			{
				breve: 2,
				lungo: 1
			},
			{ maxMinutes: 140 }
		],
		["Posso stare fino a tardi", { lungo: 7 }],
		["Il tempo non conta", {
			lungo: 4,
			complesso: 2
		}]
	]),
	q(2, 1, "Con chi guardi?", [
		[
			"Da solo",
			{
				intimo: 4,
				complesso: 2
			},
			{ company: "solo" }
		],
		[
			"In coppia",
			{
				amore: 4,
				romance: 2
			},
			{ company: "coppia" }
		],
		[
			"Con amici",
			{
				commedia: 3,
				leggero: 2,
				spettacolo: 2
			},
			{ company: "amici" }
		],
		[
			"In famiglia, magari con bambini",
			{
				famiglia: 6,
				animazione: 3,
				semplice: 3,
				leggero: 3
			},
			{
				company: "famiglia",
				kidsOk: true
			}
		]
	]),
	q(3, 1, "Come stai, di testa?", [
		["Stanco: voglio qualcosa di liscio", {
			semplice: 7,
			lento: 3,
			leggero: 3
		}],
		["Normale, aperto a tutto", {
			semplice: 2,
			complesso: 2
		}],
		["Carico: voglio concentrarmi", {
			complesso: 6,
			teso: 2
		}],
		["Irrequieto: ho bisogno di stimolo", {
			veloce: 6,
			spettacolo: 4,
			strano: 2
		}]
	]),
	q(4, 1, "Cosa vuoi portarti via, alla fine?", [
		["Una risata", {
			commedia: 8,
			leggero: 6,
			sollevante: 3
		}],
		["Un nodo in gola", {
			dramma: 6,
			malinconico: 6,
			intimo: 3
		}],
		["Il fiato corto", {
			thriller: 6,
			teso: 7,
			azione: 3
		}],
		["Qualcosa a cui pensare dopo", {
			complesso: 6,
			mistero: 3,
			identita: 3
		}]
	]),
	q(5, 1, "Luce o buio?", [
		["Chiaro, caldo, rassicurante", {
			leggero: 7,
			sollevante: 5,
			speranza: 4
		}],
		["Un po' di entrambi", {
			dramma: 2,
			ironico: 2
		}],
		["Buio, ma elegante", {
			oscuro: 6,
			cinico: 3,
			lento: 2
		}],
		["Nero pesto", {
			oscuro: 8,
			teso: 4,
			horror: 2
		}]
	]),
	q(6, 1, "Vuoi un titolo che conosci già, o qualcosa di nuovo?", [
		["Un classico rassicurante", {
			classico: 7,
			semplice: 2
		}],
		["Famoso, ma non l'ho ancora visto", {
			hollywood: 3,
			spettacolo: 2
		}],
		["Poco noto, da scoprire", {
			europa: 3,
			complesso: 3,
			italiano: 2
		}],
		["Indifferente: conta solo che funzioni", {}]
	]),
	q(7, 1, "Lingua originale, stasera?", [
		["Sì, sempre, con i sottotitoli", {
			europa: 2,
			asia: 2,
			complesso: 1
		}],
		["Va bene, se il film lo merita", { europa: 1 }],
		[
			"Preferisco il doppiaggio",
			{
				hollywood: 3,
				semplice: 2
			},
			{ dubbed: true }
		],
		["Solo italiano", { italiano: 8 }]
	]),
	q(8, 1, "Vuoi essere accompagnato o spiazzato?", [
		["Accompagnato: so già che tipo di viaggio è", {
			semplice: 5,
			classico: 2
		}],
		["Un po' di sorpresa, niente traumi", {
			mistero: 3,
			strano: 2
		}],
		["Voglio uscire dalla mia zona", {
			strano: 6,
			complesso: 4
		}],
		["Mandami altrove, senza preavviso", {
			strano: 8,
			stilizzato: 4
		}]
	]),
	q(9, 1, "Che intensità tolleri stasera?", [
		[
			"Bassa: niente urla, niente sangue",
			{ leggero: 5 },
			{ avoid: ["horror", "teso"] }
		],
		["Media: un po' di tensione va bene", { teso: 3 }],
		["Alta: voglio sentire il corpo", {
			teso: 7,
			thriller: 4,
			azione: 3
		}],
		["Massima, se è al servizio della storia", {
			teso: 6,
			oscuro: 4,
			complesso: 2
		}]
	]),
	q(10, 1, "La fine deve essere felice?", [
		["Sì, o almeno consolatoria", {
			speranza: 7,
			sollevante: 5,
			leggero: 2
		}],
		["Amara va bene, se è onesta", {
			malinconico: 4,
			dramma: 3
		}],
		["Può fare male", {
			oscuro: 4,
			cinico: 4,
			dramma: 3
		}],
		["Aperta, ambigua, da discutere", {
			complesso: 6,
			mistero: 3
		}]
	]),
	q(11, 2, "L'azione, per te, è…", [
		["Il piatto principale", {
			azione: 8,
			veloce: 5,
			spettacolo: 5
		}],
		["Un condimento, se serve", {
			azione: 3,
			avventura: 2
		}],
		["Raramente il motivo per cui scelgo", {
			intimo: 3,
			dialoghi: 2
		}],
		[
			"No, stasera no",
			{},
			{ avoid: ["azione"] }
		]
	]),
	q(12, 2, "La commedia?", [
		["Sì, voglio ridere", {
			commedia: 8,
			leggero: 5,
			ironico: 3
		}],
		["Sì, ma intelligente, non slapstick", {
			commedia: 5,
			ironico: 5,
			dialoghi: 3
		}],
		["Solo se è nera", {
			commedia: 3,
			ironico: 6,
			oscuro: 3,
			cinico: 3
		}],
		[
			"Non stasera",
			{},
			{ avoid: ["commedia"] }
		]
	]),
	q(13, 2, "Il dramma?", [
		["Lo cerco", {
			dramma: 8,
			intimo: 4,
			complesso: 2
		}],
		["Se i personaggi sono veri", {
			dramma: 5,
			vero: 3,
			intimo: 3
		}],
		["A piccole dosi", {
			dramma: 2,
			leggero: 2
		}],
		[
			"Troppo pesante, ora",
			{},
			{ avoid: ["dramma"] }
		]
	]),
	q(14, 2, "Thriller e suspense?", [
		["Sì, voglio il meccanismo", {
			thriller: 8,
			teso: 6,
			mistero: 4
		}],
		["Sì, se è psicologico", {
			thriller: 5,
			complesso: 4,
			intimo: 2
		}],
		["Solo se non è prevedibile", {
			thriller: 3,
			strano: 3
		}],
		[
			"No, troppa ansia",
			{},
			{ avoid: ["thriller", "teso"] }
		]
	]),
	q(15, 2, "Horror?", [
		["Sì, anche fisico", {
			horror: 8,
			teso: 6,
			oscuro: 5
		}],
		["Sì, ma atmosferico, non splatter", {
			horror: 5,
			lento: 3,
			stilizzato: 3,
			oscuro: 4
		}],
		["Solo se c'è un'idea dietro", {
			horror: 3,
			complesso: 3,
			identita: 2
		}],
		[
			"Mai, o quasi",
			{},
			{ avoid: ["horror"] }
		]
	]),
	q(16, 2, "Fantascienza?", [
		["Sì, grandi idee e mondi", {
			scifi: 8,
			complesso: 3,
			spettacolo: 3
		}],
		["Sì, se parla di noi, oggi", {
			scifi: 5,
			identita: 4,
			intimo: 2
		}],
		["Solo avventura spaziale", {
			scifi: 4,
			avventura: 5,
			spettacolo: 4
		}],
		[
			"Non fa per me",
			{},
			{ avoid: ["scifi"] }
		]
	]),
	q(17, 2, "Storie d'amore?", [
		["Sì, voglio innamorarmi un po'", {
			romance: 8,
			amore: 7,
			intimo: 3
		}],
		["Sì, se non è zuccherosa", {
			romance: 4,
			amore: 4,
			dramma: 2,
			ironico: 2
		}],
		["Come sottotrama, va bene", { amore: 2 }],
		[
			"No, stasera no",
			{},
			{ avoid: ["romance", "amore"] }
		]
	]),
	q(18, 2, "Crime, gangster, poliziesco?", [
		["Sì, il mondo di sotto", {
			crime: 8,
			oscuro: 3,
			cinico: 3
		}],
		["Sì, se è teso e preciso", {
			crime: 5,
			thriller: 4,
			teso: 3
		}],
		["Solo se i personaggi restano", {
			crime: 3,
			dramma: 3
		}],
		[
			"Non mi chiama",
			{},
			{ avoid: ["crime"] }
		]
	]),
	q(19, 2, "Fiction o qualcosa di vero?", [
		["Fiction, sempre", {}],
		["Storie vere, o quasi", {
			biografico: 6,
			vero: 7,
			documentario: 2
		}],
		["Documentario, se è cinematografico", {
			documentario: 8,
			vero: 6
		}],
		["Misto: basato su fatti, raccontato da romanzo", {
			biografico: 4,
			vero: 4,
			dramma: 2
		}]
	]),
	q(20, 2, "Animazione per adulti (non solo per bambini)?", [
		["Sì, la considero cinema pieno", {
			animazione: 8,
			stilizzato: 4
		}],
		["Sì, se la storia è adulta", {
			animazione: 5,
			dramma: 2
		}],
		["Solo se è per rilassarmi", {
			animazione: 3,
			leggero: 3,
			famiglia: 2
		}],
		[
			"Preferisco il live action",
			{},
			{ avoid: ["animazione"] }
		]
	]),
	q(21, 3, "L'ironia, nel film, deve…", [
		["Esserci, sempre", {
			ironico: 8,
			commedia: 3
		}],
		["Entrare a momenti giusti", { ironico: 4 }],
		["Restare fuori: voglio serietà", { dramma: 3 }],
		["Essere feroce, quasi crudele", {
			ironico: 7,
			cinico: 6,
			oscuro: 3
		}]
	]),
	q(22, 3, "La malinconia?", [
		["La cerco: è il mio clima", {
			malinconico: 8,
			lento: 4,
			intimo: 3
		}],
		["A piccole dose, come sale", { malinconico: 4 }],
		[
			"No, troppo grigio",
			{
				sollevante: 4,
				leggero: 3
			},
			{ avoid: ["malinconico"] }
		],
		["Sì, se c'è anche una luce in fondo", {
			malinconico: 5,
			speranza: 5
		}]
	]),
	q(23, 3, "Vuoi tensione continua o pause per respirare?", [
		["Continua: niente tregua", {
			teso: 8,
			veloce: 4,
			thriller: 3
		}],
		["Onde: sale e scende", {
			teso: 4,
			dramma: 2
		}],
		["Poche: voglio fluttuare", {
			lento: 6,
			intimo: 3
		}],
		[
			"Quasi zero: pace",
			{
				lento: 5,
				leggero: 4
			},
			{ avoid: ["teso"] }
		]
	]),
	q(24, 3, "Ottimismo o disincanto?", [
		["Voglio uscire meglio di come sono entrato", {
			speranza: 8,
			sollevante: 6
		}],
		["Realista, senza cinismo da bar", {
			vero: 4,
			dramma: 2
		}],
		["Il mondo è storto, e va mostrato", {
			cinico: 7,
			oscuro: 4
		}],
		["Dipende dalla storia, non dal messaggio", { complesso: 3 }]
	]),
	q(25, 3, "Lo strano, il grottesco, l'assurdo?", [
		["Sì, fatemi uscire dalla realtà", {
			strano: 8,
			stilizzato: 4
		}],
		["Un pizzico, non un intero piatto", { strano: 3 }],
		[
			"No: voglio credere a ogni inquadratura",
			{
				vero: 5,
				intimo: 2
			},
			{ avoid: ["strano"] }
		],
		["Sì, se c'è un metodo dietro la follia", {
			strano: 6,
			complesso: 4
		}]
	]),
	q(26, 3, "Sentimentalità: quanto zucchero?", [
		["Tanto: voglio sentire", {
			amore: 5,
			famiglia: 3,
			sollevante: 4,
			romance: 3
		}],
		["Quanto basta, senza sciroppo", {
			intimo: 3,
			dramma: 2
		}],
		["Zero: tagliate gli archi di violini", {
			cinico: 4,
			ironico: 3
		}],
		["Solo se è guadagnata, scena dopo scena", {
			dramma: 4,
			intimo: 3
		}]
	]),
	q(27, 3, "Umorismo nero?", [
		["Il mio preferito", {
			ironico: 7,
			cinico: 5,
			oscuro: 3,
			commedia: 3
		}],
		["A tratti", { ironico: 3 }],
		["No, lo trovo facile o crudele", { leggero: 2 }],
		["Sì, se non ride del dolore altrui", {
			ironico: 4,
			dramma: 2
		}]
	]),
	q(28, 3, "Vuoi un film che ti tiene compagnia o uno che ti osserva?", [
		["Compagnia: è un ospite bravo", {
			leggero: 4,
			dialoghi: 3,
			commedia: 2
		}],
		["Un po' e un po'", {}],
		["Che mi osserva: esco diverso", {
			complesso: 5,
			identita: 4,
			intimo: 3
		}],
		["Che mi mette a disagio, volutamente", {
			oscuro: 5,
			strano: 4,
			teso: 3
		}]
	]),
	q(29, 3, "Pathos e lacrime?", [
		["Sì, se arriva", {
			dramma: 5,
			malinconico: 4,
			intimo: 3
		}],
		["Va bene, ma senza ricatto", { dramma: 3 }],
		["No: resto a distanze di sicurezza", {
			cinico: 3,
			ironico: 2
		}],
		["Le cerco, stasera", {
			dramma: 6,
			malinconico: 5,
			famiglia: 2
		}]
	]),
	q(30, 3, "Quanto vuoi che il film 'si senta' come cinema, non come TV?", [
		["Molto: inquadrature, silenzi, ambizione", {
			stilizzato: 6,
			immagini: 6,
			complesso: 3
		}],
		["Abbastanza: curato, non ostentato", { immagini: 3 }],
		["Poco: voglio la storia, non la lezione", {
			semplice: 5,
			dialoghi: 3
		}],
		["Zero: deve scorrere come acqua", {
			semplice: 7,
			veloce: 3,
			hollywood: 2
		}]
	]),
	q(31, 4, "Quante figure al centro?", [
		["Una: un personaggio, un arco", {
			intimo: 5,
			identita: 3
		}],
		["Due: un rapporto", {
			amore: 4,
			intimo: 4,
			dialoghi: 3
		}],
		["Un gruppo, una banda, una famiglia", {
			famiglia: 4,
			crime: 2
		}],
		["Un coro: tante voci", {
			complesso: 3,
			dramma: 2
		}]
	]),
	q(32, 4, "L'antieroe?", [
		["Sì, i dilemmi sporchi mi interessano", {
			cinico: 5,
			crime: 3,
			oscuro: 3,
			complesso: 2
		}],
		["A tratti: nessuno è solo buono", {
			dramma: 3,
			vero: 2
		}],
		["Preferisco qualcuno da tifare", {
			speranza: 4,
			avventura: 2,
			sollevante: 2
		}],
		["No: voglio una bussola morale chiara", {
			semplice: 3,
			famiglia: 2
		}]
	]),
	q(33, 4, "Storie di coppia?", [
		["Sì, innamoramento", {
			romance: 6,
			amore: 6,
			leggero: 2
		}],
		["Sì, crisi, tempo, usura", {
			amore: 5,
			dramma: 5,
			intimo: 4,
			malinconico: 2
		}],
		["Come parte di un quadro più ampio", { amore: 2 }],
		[
			"Non il centro, stasera",
			{},
			{ avoid: ["romance"] }
		]
	]),
	q(34, 4, "Famiglia, come tema?", [
		["Sì, origini e nodi", {
			famiglia: 8,
			dramma: 4,
			intimo: 3
		}],
		["Sì, se non è melodramma da talk show", {
			famiglia: 4,
			ironico: 2
		}],
		["Solo come sfondo", { famiglia: 1 }],
		[
			"No",
			{},
			{ avoid: ["famiglia"] }
		]
	]),
	q(35, 4, "Amicizia?", [
		["Sì, bande, lealtà, tradimenti", {
			famiglia: 3,
			commedia: 2,
			crime: 2
		}],
		["Sì, due persone che si tengono in vita", {
			intimo: 5,
			dramma: 3
		}],
		["Non è una leva per me", {}],
		["Sì, se fa ridere", {
			commedia: 5,
			leggero: 3
		}]
	]),
	q(36, 4, "Vuoi una protagonista donna al centro?", [
		["Sì, la cerco", {
			identita: 3,
			dramma: 2
		}],
		["Non è un criterio, ma benvenuta", {}],
		["Indifferente", {}],
		["Preferisco storie maschili, stasera", {}]
	]),
	q(37, 4, "Età dei personaggi?", [
		["Giovani, in formazione", {
			identita: 5,
			speranza: 2,
			moderno: 2
		}],
		["Adulti nel mezzo del guado", {
			dramma: 4,
			identita: 3,
			vero: 2
		}],
		["Più avanti, con il tempo addosso", {
			malinconico: 4,
			classico: 2,
			intimo: 3
		}],
		["Misto: generazioni che si scontrano", {
			famiglia: 4,
			dramma: 2
		}]
	]),
	q(38, 4, "Cattivi carismatici?", [
		["Sì, voglio odiare e ammirare", {
			cinico: 4,
			crime: 3,
			thriller: 2,
			potere: 3
		}],
		["Sì, ma non da poster", { complesso: 3 }],
		["Il male come sistema, non come star", {
			potere: 5,
			vero: 3,
			dramma: 2
		}],
		["Preferisco conflitti senza 'cattivo'", {
			intimo: 3,
			dramma: 2
		}]
	]),
	q(39, 4, "Biografie, persone realmente esistite?", [
		["Sì, se c'è un punto di vista", {
			biografico: 8,
			vero: 6
		}],
		["Sì, artisti, scienziati, outsider", {
			biografico: 5,
			identita: 3
		}],
		[
			"No: voglio invenzione",
			{},
			{ avoid: ["biografico"] }
		],
		["Solo se non è un riassunto da Wikipedia", {
			biografico: 4,
			complesso: 2
		}]
	]),
	q(40, 4, "Bambini o adolescenti al centro?", [
		["Sì, coming of age", {
			identita: 5,
			famiglia: 2,
			malinconico: 2
		}],
		["Sì, se non è sdolcinato", {
			identita: 4,
			vero: 2
		}],
		["No, stasera adulti", {}],
		[
			"Sì, e può essere anche per famiglie",
			{
				famiglia: 5,
				animazione: 2,
				semplice: 2
			},
			{ kidsOk: true }
		]
	]),
	q(41, 5, "Città?", [
		["Sì, strade, notti, rumore", {
			crime: 3,
			thriller: 2,
			moderno: 2,
			hollywood: 1
		}],
		["Sì, una capitale europea, un'atmosfera", {
			europa: 4,
			malinconico: 2,
			intimo: 2
		}],
		["No: voglio uscire dalla città", { avventura: 3 }],
		["Roma, Milano, Napoli: l'Italia urbana", { italiano: 6 }]
	]),
	q(42, 5, "Natura, viaggio, strada?", [
		["Sì, paesaggi che lavorano sulla storia", {
			avventura: 5,
			immagini: 4,
			lento: 2
		}],
		["Sì, road movie", {
			avventura: 6,
			identita: 3,
			hollywood: 2
		}],
		["Solo come pausa visiva", { immagini: 2 }],
		["No, restiamo al chiuso", {
			intimo: 4,
			dialoghi: 3
		}]
	]),
	q(43, 5, "Spazio, futuro, altri mondi?", [
		["Sì, portatemi via da qui", {
			scifi: 7,
			fantasy: 3,
			spettacolo: 4,
			avventura: 3
		}],
		["Sì, se resta umano", {
			scifi: 5,
			intimo: 3,
			identita: 3
		}],
		["Fantasy più che scienza", {
			fantasy: 8,
			avventura: 4,
			spettacolo: 3
		}],
		[
			"No, restiamo sulla Terra",
			{},
			{ avoid: ["scifi", "fantasy"] }
		]
	]),
	q(44, 5, "Passato storico?", [
		["Sì, epoche lontane", {
			classico: 3,
			guerra: 2,
			spettacolo: 2,
			complesso: 1
		}],
		["Sì, Novecento, memoria vicina", {
			biografico: 3,
			vero: 3,
			guerra: 2,
			europa: 2
		}],
		[
			"No, voglio contemporaneo",
			{ moderno: 6 },
			{ minYear: 1995 }
		],
		["Indifferente, se la storia tiene", {}]
	]),
	q(45, 5, "Italia, come luogo e lingua?", [
		["Sì, la cerco", { italiano: 8 }],
		["Sì, ma non per forza neorealismo", {
			italiano: 5,
			moderno: 2
		}],
		["A volte, non è un filtro", { italiano: 2 }],
		[
			"Stasera no, voglio altrove",
			{},
			{ avoid: ["italiano"] }
		]
	]),
	q(46, 5, "Interni, case, stanze?", [
		["Sì, il domestico è un campo di battaglia", {
			intimo: 7,
			dramma: 4,
			famiglia: 3,
			dialoghi: 3
		}],
		["Sì, se la messa in scena è precisa", {
			intimo: 4,
			stilizzato: 3
		}],
		["No, claustrofobia no", {
			avventura: 3,
			spettacolo: 2
		}],
		["Una stanza va bene, se c'è mondo fuori dalla finestra", {
			intimo: 3,
			immagini: 2
		}]
	]),
	q(47, 5, "Guerra?", [
		["Sì, come tragedia e sistema", {
			guerra: 8,
			oscuro: 4,
			complesso: 3,
			vero: 3
		}],
		["Sì, se c'è un volto, non solo le truppe", {
			guerra: 5,
			intimo: 3,
			dramma: 3
		}],
		["Solo se non è spettacolo di esplosioni", {
			guerra: 3,
			cinico: 2
		}],
		[
			"No, stasera",
			{},
			{ avoid: ["guerra"] }
		]
	]),
	q(48, 5, "Lavoro, scuola, istituzioni?", [
		["Sì, il quotidiano professionale", {
			vero: 5,
			dramma: 3,
			identita: 2
		}],
		["Sì, satira del potere", {
			potere: 5,
			ironico: 4,
			cinico: 3
		}],
		["No, voglio evadere dal mio", {
			avventura: 3,
			spettacolo: 2,
			fantasy: 2
		}],
		["A tratti, come sfondo credibile", { vero: 2 }]
	]),
	q(49, 5, "Mondo magico, fiaba, mito?", [
		["Sì", {
			fantasy: 8,
			spettacolo: 3,
			animazione: 2
		}],
		["Sì, se è scuro, da bosco", {
			fantasy: 5,
			oscuro: 4,
			stilizzato: 3
		}],
		[
			"No",
			{},
			{ avoid: ["fantasy"] }
		],
		["Solo se ha ironia, non maghetti", {
			fantasy: 3,
			ironico: 4
		}]
	]),
	q(50, 5, "Mare, isole, confine, altrove geografico?", [
		["Sì, luoghi liminali", {
			avventura: 4,
			malinconico: 3,
			immagini: 3
		}],
		["Sì, esotismo intelligente, non cartolina", {
			avventura: 3,
			europa: 2,
			asia: 2
		}],
		["No, restiamo nel noto", {}],
		["Italia di provincia, paesi, spiagge", {
			italiano: 5,
			intimo: 2
		}]
	]),
	q(51, 6, "Ritmo?", [
		["Lento, dilatato, ipnotico", {
			lento: 8,
			immagini: 4,
			intimo: 2
		}],
		["Misurato, da romanzo", {
			lento: 3,
			dialoghi: 3,
			dramma: 2
		}],
		["Svelto, tagli netti", {
			veloce: 7,
			spettacolo: 3
		}],
		["In accelerazione: parte piano, poi corre", {
			veloce: 4,
			teso: 3,
			thriller: 2
		}]
	]),
	q(52, 6, "Dialoghi o immagini?", [
		["Parole: battute, saggi, litigi", {
			dialoghi: 8,
			intimo: 3,
			commedia: 2
		}],
		["Immagini: facce, spazi, silenzi", {
			immagini: 8,
			lento: 3,
			stilizzato: 3
		}],
		["Equilibrio", {
			dialoghi: 3,
			immagini: 3
		}],
		["Musica e montaggio, più che parole", {
			immagini: 5,
			musical: 3,
			stilizzato: 3
		}]
	]),
	q(53, 6, "Durata ideale, in astratto?", [
		[
			"Corto e preciso, sotto i 100'",
			{ breve: 8 },
			{ maxMinutes: 105 }
		],
		[
			"Standard, 100–130'",
			{ breve: 2 },
			{ maxMinutes: 140 }
		],
		["Lungo, se se lo merita", {
			lungo: 7,
			complesso: 3
		}],
		[
			"Più è epico, meglio è",
			{
				lungo: 8,
				spettacolo: 4,
				complesso: 2
			},
			{ minMinutes: 140 }
		]
	]),
	q(54, 6, "Colore?", [
		["Saturi, da manifesto", {
			stilizzato: 5,
			spettacolo: 3
		}],
		["Naturali, luce vera", {
			vero: 4,
			intimo: 2,
			immagini: 2
		}],
		["Scuri, desaturati", {
			oscuro: 4,
			stilizzato: 3
		}],
		["Anche in bianco e nero", {
			classico: 4,
			stilizzato: 4,
			immagini: 3
		}]
	]),
	q(55, 6, "Colonna sonora da protagonista?", [
		["Sì, voglio uscire canticchiando o scosso", {
			musical: 5,
			spettacolo: 3
		}],
		["Sì, se è composizione, non playlist", {
			stilizzato: 3,
			immagini: 2
		}],
		["Discreta, al servizio", {}],
		["Silenzio, o quasi", {
			intimo: 3,
			lento: 2,
			immagini: 2
		}]
	]),
	q(56, 6, "Spettacolo visivo, effetti, scala?", [
		["Sì, voglio il cinema grande", {
			spettacolo: 8,
			azione: 3,
			scifi: 2,
			hollywood: 3
		}],
		["Sì, se non mangia i personaggi", {
			spettacolo: 4,
			dramma: 2
		}],
		[
			"No, scala umana",
			{
				intimo: 6,
				semplice: 2
			},
			{ avoid: ["spettacolo"] }
		],
		["Virtuosismo di messa in scena, non CGI", {
			stilizzato: 6,
			immagini: 5
		}]
	]),
	q(57, 6, "Narrazione lineare o spezzata?", [
		["Lineare, dal punto A al B", { semplice: 6 }],
		["Qualche salto, se è chiaro", { complesso: 2 }],
		["Frammenti, tempi diversi, puzzle", {
			complesso: 7,
			mistero: 3,
			stilizzato: 2
		}],
		["Sogno, loop, realtà porosa", {
			strano: 6,
			complesso: 5,
			stilizzato: 4
		}]
	]),
	q(58, 6, "Il colpo di scena?", [
		["Sì, voglio il tappeto tirato", {
			mistero: 6,
			thriller: 4,
			teso: 2
		}],
		["Sì, ma deve reggere al rewatch", {
			mistero: 4,
			complesso: 3
		}],
		["No: l'arco conta più del twist", {
			dramma: 3,
			intimo: 2
		}],
		["Lo vedo arrivare sempre, quindi non è un criterio", {}]
	]),
	q(59, 6, "Finale aperto?", [
		["Sì, da discutere", {
			complesso: 6,
			mistero: 3
		}],
		["Sì, se non è pigrizia", { complesso: 3 }],
		["No: voglio una chiusura", {
			semplice: 4,
			speranza: 2
		}],
		["Chiusura amara, ma chiusura", {
			cinico: 3,
			dramma: 2
		}]
	]),
	q(60, 6, "Quanto vuoi 'capire tutto' al primo passaggio?", [
		["Tutto, subito, senza compiti a casa", {
			semplice: 8,
			hollywood: 2
		}],
		["Il senso sì, i dettagli possono restare", {
			semplice: 3,
			complesso: 2
		}],
		["Voglio che chieda una seconda visione", {
			complesso: 7,
			stilizzato: 3
		}],
		["Può restare opaco, se è bello", {
			complesso: 5,
			immagini: 4,
			strano: 3
		}]
	]),
	q(61, 7, "Giustizia, colpa, processo?", [
		["Sì", {
			mistero: 4,
			crime: 4,
			thriller: 3,
			potere: 3,
			vero: 2
		}],
		["Sì, come domanda morale, non legale", {
			dramma: 4,
			identita: 3,
			complesso: 2
		}],
		["No", {}],
		["Sì, se è un enigma da seguire", {
			mistero: 6,
			thriller: 4
		}]
	]),
	q(62, 7, "Potere: politica, soldi, gerarchie?", [
		["Sì, voglio vedere chi comanda", {
			potere: 8,
			cinico: 3,
			vero: 3
		}],
		["Sì, in miniatura: una casa, un ufficio", {
			potere: 5,
			intimo: 3,
			famiglia: 2
		}],
		["No, evasione", {
			avventura: 3,
			leggero: 2
		}],
		["Sì, se è satira", {
			potere: 5,
			ironico: 5,
			commedia: 2
		}]
	]),
	q(63, 7, "Identità, maschere, chi siamo?", [
		["Il tema che mi tiene sveglio", {
			identita: 8,
			complesso: 4,
			intimo: 3
		}],
		["Sì, se non è un saggio", {
			identita: 4,
			dramma: 2
		}],
		["No, troppa psicologia", {}],
		["Sì, e può essere anche strano", {
			identita: 6,
			strano: 4
		}]
	]),
	q(64, 7, "Memoria, tempo che passa, rimpianto?", [
		["Sì", {
			malinconico: 6,
			identita: 4,
			lento: 3,
			classico: 2
		}],
		["Sì, se c'è una forma (flashback, diario)", {
			complesso: 3,
			identita: 3
		}],
		["No, restiamo nel presente", {
			moderno: 3,
			veloce: 2
		}],
		["Sì, e può fare male", {
			malinconico: 7,
			dramma: 4
		}]
	]),
	q(65, 7, "Tecnologia, reti, futuro vicino?", [
		["Sì, è il nostro romanzo", {
			scifi: 5,
			moderno: 5,
			identita: 2,
			teso: 2
		}],
		["Sì, se è distopia credibile", {
			scifi: 4,
			cinico: 3,
			potere: 3
		}],
		[
			"No, voglio staccare dagli schermi",
			{},
			{ avoid: ["scifi"] }
		],
		["Solo come sfondo contemporaneo", { moderno: 3 }]
	]),
	q(66, 7, "Classe, soldi, chi resta fuori?", [
		["Sì, è il conflitto vero", {
			potere: 6,
			vero: 5,
			dramma: 3,
			cinico: 2
		}],
		["Sì, all'italiana: furbi e fessi", {
			italiano: 4,
			ironico: 3,
			commedia: 2
		}],
		["No", {}],
		["Sì, se non è un volantino", {
			potere: 4,
			complesso: 2
		}]
	]),
	q(67, 7, "Fede, sacro, dubbio?", [
		["Sì, anche senza essere credente", {
			complesso: 4,
			identita: 3,
			lento: 2
		}],
		["Sì, come cultura e rito", {
			europa: 2,
			classico: 2
		}],
		["No", {}],
		["Sì, se è conflitto interiore, non predica", {
			identita: 4,
			dramma: 3
		}]
	]),
	q(68, 7, "Arte, teatro, cinema sul cinema?", [
		["Sì, meta, bottega, ossessione", {
			identita: 4,
			stilizzato: 4,
			biografico: 2,
			complesso: 2
		}],
		["A tratti", { stilizzato: 2 }],
		["No, troppo autoreferenziale", {}],
		["Sì, se fa ridere del mondo dello spettacolo", {
			ironico: 4,
			commedia: 3
		}]
	]),
	q(69, 7, "Politica esplicita?", [
		["Sì, voglio che prenda posizione", {
			potere: 6,
			vero: 4,
			cinico: 2
		}],
		["Sì, se è incarnata in persone, non in slogan", {
			potere: 4,
			dramma: 3
		}],
		[
			"No, stasera distacco",
			{},
			{ avoid: ["potere"] }
		],
		["Satira, non manifesto", {
			ironico: 5,
			potere: 3
		}]
	]),
	q(70, 7, "Crescita, formazione, diventare qualcuno?", [
		["Sì", {
			identita: 6,
			speranza: 3,
			famiglia: 2
		}],
		["Sì, anche da adulti", {
			identita: 5,
			dramma: 3,
			vero: 2
		}],
		["No, personaggi già formati", { cinico: 2 }],
		["Sì, se è amara, non da libretto", {
			identita: 4,
			malinconico: 3
		}]
	]),
	q(71, 8, "Classici (prima del 1975)?", [
		[
			"Sì, la storia del cinema",
			{ classico: 8 },
			{ maxYear: 1975 }
		],
		["Qualcuno, se è vivo ancora oggi", { classico: 4 }],
		[
			"No, troppa polvere",
			{ moderno: 5 },
			{ minYear: 1990 }
		],
		["Sì, ma parlato o restaurato bene", {
			classico: 5,
			italiano: 2
		}]
	]),
	q(72, 8, "Anni Settanta e Ottanta?", [
		[
			"Il mio territorio",
			{
				classico: 3,
				hollywood: 3
			},
			{
				minYear: 1970,
				maxYear: 1989
			}
		],
		["Sì, certa New Hollywood, certo horror", {
			thriller: 2,
			horror: 2,
			crime: 2
		}],
		["Poco", { moderno: 3 }],
		["Sì, l'Italia di quegli anni", {
			italiano: 5,
			classico: 2
		}]
	]),
	q(73, 8, "Anni Novanta e Duemila?", [
		["Sì, la mia adolescenza in sala", {
			moderno: 4,
			hollywood: 3
		}],
		["Sì, indipendenti americani", {
			hollywood: 3,
			ironico: 2,
			crime: 2
		}],
		["Indifferente", {}],
		["No, troppo 'già visto'", {
			classico: 2,
			moderno: 2
		}]
	]),
	q(74, 8, "Cinema di ora (dal 2018 in poi)?", [
		[
			"Sì, voglio il discorso presente",
			{ moderno: 8 },
			{ minYear: 2018 }
		],
		["Sì, se non è solo algoritmo", {
			moderno: 4,
			complesso: 2
		}],
		[
			"No, troppa fretta contemporanea",
			{ classico: 4 },
			{ maxYear: 2010 }
		],
		["Misto: un nuovo e un classico mi stanno bene", {
			moderno: 3,
			classico: 3
		}]
	]),
	q(75, 8, "Hollywood grande macchina?", [
		["Sì, è il mestiere", {
			hollywood: 8,
			spettacolo: 4,
			semplice: 2
		}],
		["Sì, ma la Hollywood intelligente", {
			hollywood: 5,
			complesso: 2,
			dialoghi: 2
		}],
		[
			"No, troppi franchising",
			{},
			{ avoid: ["hollywood"] }
		],
		["A dose: un blockbuster ogni tanto", {
			hollywood: 3,
			spettacolo: 3
		}]
	]),
	q(76, 8, "Europa (Francia, Nord, Est, UK…)?", [
		["Sì, è casa", {
			europa: 8,
			complesso: 2,
			intimo: 2
		}],
		["Sì, certa Francia, certo Nord", {
			europa: 5,
			malinconico: 2
		}],
		["A volte", { europa: 2 }],
		[
			"No, stasera no",
			{},
			{ avoid: ["europa"] }
		]
	]),
	q(77, 8, "Asia (Corea, Giappone, Cina, Iran…)?", [
		["Sì, la cerco", {
			asia: 8,
			complesso: 2,
			stilizzato: 2
		}],
		["Sì, Corea e Giappone in particolare", {
			asia: 6,
			thriller: 2
		}],
		["Curioso, se mi guidi", { asia: 3 }],
		[
			"No",
			{},
			{ avoid: ["asia"] }
		]
	]),
	q(78, 8, "Altrove: America Latina, Africa, Medio Oriente?", [
		["Sì, apri il mappamondo", {
			vero: 4,
			immagini: 3,
			complesso: 2
		}],
		["Sì, se c'è un film, non un 'esempio'", {
			vero: 3,
			dramma: 2
		}],
		["Non è una priorità", {}],
		["Italia e Occidente mi bastano", {
			hollywood: 2,
			europa: 2,
			italiano: 2
		}]
	]),
	q(79, 8, "Autore forte (lo riconosci dopo due inquadrature)?", [
		["Sì, voglio una voce", {
			stilizzato: 6,
			complesso: 4,
			immagini: 3
		}],
		["Sì, ma non un manierismo", {
			stilizzato: 3,
			dramma: 2
		}],
		["No: mestiere invisibile", {
			semplice: 5,
			hollywood: 3
		}],
		["Dipende se la voce serve la storia", { complesso: 2 }]
	]),
	q(80, 8, "Festival e palme, o sala piena di popcorn?", [
		["Festival, sempre", {
			complesso: 6,
			europa: 3,
			stilizzato: 3
		}],
		["Qualcosa in mezzo: lodato, ma vedibile", {
			complesso: 3,
			hollywood: 2
		}],
		["Popcorn: è festa", {
			spettacolo: 6,
			semplice: 4,
			hollywood: 4,
			leggero: 3
		}],
		["Entrambi, in serate diverse — stasera il primo", {
			complesso: 4,
			intimo: 2
		}]
	]),
	q(81, 9, "Quali piattaforme hai, di solito?", [
		[
			"Netflix",
			{ moderno: 1 },
			{ platforms: ["netflix"] }
		],
		[
			"Prime Video",
			{},
			{ platforms: ["prime"] }
		],
		[
			"Disney+",
			{
				famiglia: 1,
				spettacolo: 1
			},
			{ platforms: ["disney"] }
		],
		[
			"Apple TV",
			{
				moderno: 1,
				intimo: 1
			},
			{ platforms: ["apple"] }
		],
		[
			"NOW / Sky",
			{},
			{ platforms: ["now"] }
		],
		[
			"MUBI",
			{
				europa: 3,
				complesso: 2,
				stilizzato: 2
			},
			{ platforms: ["mubi"] }
		],
		[
			"RaiPlay",
			{
				italiano: 3,
				classico: 1
			},
			{ platforms: ["raiplay"] }
		],
		[
			"Paramount+",
			{ hollywood: 2 },
			{ platforms: ["paramount"] }
		]
	], {
		type: "multi",
		hint: "Se le hai già segnate all'inizio, sono pre-selezionate. Puoi aggiornarle."
	}),
	q(82, 9, "Sottotitoli o doppiaggio, di default?", [
		["Sottotitoli, sempre", {
			europa: 2,
			asia: 2
		}],
		["Dipende dalla lingua e dalla stanchezza", {}],
		[
			"Doppiaggio, se è italiano di mestiere",
			{
				hollywood: 2,
				semplice: 2
			},
			{ dubbed: true }
		],
		["Italiano originale: niente da scegliere", { italiano: 4 }]
	]),
	q(83, 9, "Rewatch o prima visione?", [
		["Prima visione, stasera", { moderno: 2 }],
		["Un rivedere, come una coperta", {
			classico: 3,
			semplice: 2
		}],
		["Indifferente", {}],
		["Prima visione, anche se è un titolo vecchio", { classico: 2 }]
	]),
	q(84, 9, "Ti basta un film, o stai pensando a una serie?", [
		["Un film: inizio, fine, stanotte", { breve: 2 }],
		["Un film lungo va bene, non una serie", { lungo: 2 }],
		["Preferirei una serie, ma proponimi un film che stia in una sera", {
			semplice: 2,
			hollywood: 1
		}],
		["Un film che sembri una miniserie per densità", {
			complesso: 4,
			lungo: 3
		}]
	]),
	q(85, 9, "Quanto conti su voti e recensioni?", [
		["Molto: filtrami il rumore", {
			hollywood: 1,
			semplice: 1
		}],
		["Un po', ma il gusto è mio", {}],
		["Poco: i 7.4 mi dicono quasi niente", {
			complesso: 2,
			strano: 1
		}],
		["Zero: voglio il rischio", {
			strano: 3,
			europa: 2
		}]
	]),
	q(86, 9, "Guardi attento, o il film sta in sottofondo?", [
		["Attento, telefono altrove", {
			complesso: 4,
			intimo: 2,
			immagini: 2
		}],
		["Attento, ma posso pausare", { semplice: 1 }],
		["Mezzo: stasera ho le mani occupate", {
			semplice: 5,
			dialoghi: 3,
			commedia: 2
		}],
		["Sottofondo quasi: voglio compagnia, non impegno", {
			semplice: 7,
			leggero: 5,
			commedia: 3
		}]
	]),
	q(87, 9, "Schermo: TV grande, laptop, telefono?", [
		["TV, come in sala", {
			spettacolo: 4,
			immagini: 3
		}],
		["Laptop, distanza media", {}],
		["Anche il telefono, se è il momento", {
			semplice: 3,
			breve: 2
		}],
		["TV, ma a volume basso, tardi", {
			intimo: 3,
			lento: 2
		}]
	]),
	q(88, 9, "Quanto sei disposto a 'lavorare' sul film?", [
		["Niente: deve arrivarmi", {
			semplice: 7,
			hollywood: 2
		}],
		["Un po': riferimenti, tempi, ellissi", { complesso: 3 }],
		["Tanto: saggio, forma, pazienza", {
			complesso: 8,
			lento: 4,
			stilizzato: 3
		}],
		["Tanto, ma solo se c'è emozione, non solo tesi", {
			complesso: 5,
			intimo: 3,
			dramma: 2
		}]
	]),
	q(89, 9, "Franchise, sequel, universi?", [
		["Sì, voglio il capitolo", {
			hollywood: 5,
			spettacolo: 4,
			azione: 3,
			scifi: 2
		}],
		["Sì, se sta in piedi da solo", {
			hollywood: 3,
			spettacolo: 2
		}],
		["No: una storia, e basta", {
			intimo: 2,
			europa: 2
		}],
		[
			"No, e basta anche con i reboot",
			{},
			{ avoid: ["hollywood"] }
		]
	]),
	q(90, 9, "Dopo il film, vuoi parlarne?", [
		["Sì, è metà del piacere", {
			complesso: 4,
			mistero: 2,
			dialoghi: 2
		}],
		["Sì, se c'è qualcuno sveglio", { dramma: 2 }],
		["No: voglio spegnere e dormire", {
			semplice: 3,
			leggero: 2
		}],
		["No: voglio restare da solo con quello che ho visto", {
			intimo: 4,
			malinconico: 2
		}]
	]),
	q(91, 10, "Jump scare e urla improvvise?", [
		["Sì, anche", {
			horror: 5,
			teso: 4
		}],
		[
			"No, li odio",
			{},
			{ avoid: ["horror"] }
		],
		["Atmosfera sì, scare da luna park no", {
			horror: 2,
			lento: 2,
			oscuro: 3
		}],
		["Indifferente", {}]
	]),
	q(92, 10, "Violenza grafica?", [
		["Tollerata, se serve", {
			oscuro: 3,
			crime: 2,
			teso: 2
		}],
		[
			"No, tagliate",
			{},
			{ avoid: ["horror"] }
		],
		["Sì, se è sgradevole di proposito, non da videogioco", {
			cinico: 3,
			oscuro: 3,
			complesso: 2
		}],
		["Azione stilizzata sì, realismo crudo no", {
			azione: 4,
			spettacolo: 3
		}]
	]),
	q(93, 10, "Storie molto tristi su infanzia e perdita?", [
		["Posso, se è fatto bene", {
			dramma: 3,
			malinconico: 3,
			famiglia: 2
		}],
		[
			"No, non stasera",
			{},
			{ avoid: ["malinconico"] }
		],
		["Sì, è un territorio che mi interessa", {
			dramma: 5,
			malinconico: 4,
			identita: 2
		}],
		["Solo se c'è una luce, alla fine", {
			speranza: 5,
			famiglia: 3,
			dramma: 2
		}]
	]),
	q(94, 10, "Film lenti, dove 'non succede niente'?", [
		["Sì, il niente è il punto", {
			lento: 8,
			immagini: 4,
			intimo: 3
		}],
		["Un po', non due ore di corridoio", { lento: 3 }],
		[
			"No, mi addormento",
			{
				veloce: 6,
				semplice: 3
			},
			{ avoid: ["lento"] }
		],
		["Sì, se la messa in scena è ipnotica", {
			lento: 6,
			stilizzato: 4,
			immagini: 3
		}]
	]),
	q(95, 10, "CGI evidente, facce digitali, mondi di pixel?", [
		["Sì, è cinema", {
			spettacolo: 5,
			scifi: 3,
			hollywood: 3
		}],
		["Sì, se non è il soggetto", { spettacolo: 2 }],
		["No, preferisco materia, costumi, luoghi veri", {
			vero: 4,
			immagini: 3,
			classico: 2
		}],
		[
			"No, mi tira fuori",
			{},
			{ avoid: ["spettacolo"] }
		]
	]),
	q(96, 10, "Film 'difficili': ellissi, tempi lunghi, poco plot?", [
		["Sì", {
			complesso: 8,
			lento: 4,
			europa: 2
		}],
		["Sì, a dose", { complesso: 4 }],
		[
			"No",
			{ semplice: 6 },
			{ avoid: ["complesso"] }
		],
		["Sì, se c'è un centro emotivo", {
			complesso: 5,
			intimo: 4,
			dramma: 2
		}]
	]),
	q(97, 10, "Quanto conta la recitazione, rispetto alla macchina?", [
		["Tutto: voglio volti", {
			intimo: 6,
			dialoghi: 4,
			dramma: 3
		}],
		["Molto, ma anche il quadro", {
			intimo: 3,
			immagini: 3
		}],
		["La macchina può essere la star", {
			stilizzato: 5,
			spettacolo: 3,
			immagini: 3
		}],
		["Equilibrio da studio: attori e inquadratura", { complesso: 2 }]
	]),
	q(98, 10, "Vuoi essere spiazzato sul serio?", [
		["Sì, fuori dai binari", {
			strano: 8,
			complesso: 4
		}],
		["Un po'", { strano: 3 }],
		["No, voglio il genere rispettato", {
			semplice: 4,
			hollywood: 2
		}],
		["Sì, ma non per shock gratuito", {
			strano: 5,
			complesso: 3,
			identita: 2
		}]
	]),
	q(99, 10, "Se un film è 'importante' ma ti annoia, vince…", [
		["L'importanza: cresco", {
			complesso: 5,
			classico: 2
		}],
		["Il piacere: spegniamo", {
			semplice: 5,
			leggero: 3
		}],
		["Un compromesso: importante e vivo", {
			complesso: 3,
			intimo: 3,
			dramma: 2
		}],
		["Il piacere, sempre, senza sensi di colpa", {
			semplice: 6,
			commedia: 2,
			spettacolo: 2
		}]
	]),
	q(100, 10, "Se stasera potessi scegliere un solo criterio, quale?", [
		["L'umore: deve coincidere con me, ora", { intimo: 3 }],
		["Il genere: so cosa voglio", {}],
		["La scoperta: qualcosa che non avrei cliccato", {
			strano: 3,
			europa: 2,
			asia: 2,
			complesso: 2
		}],
		["La compagnia: deve funzionare per chi c'è sul divano", {
			famiglia: 3,
			semplice: 3,
			leggero: 2
		}]
	])
];
if (QUESTIONS.length !== 100) throw new Error(`Expected 100 questions, got ${QUESTIONS.length}`);
var question81 = () => QUESTIONS.find((q) => q.id === 81);
function optionIdsForPlatforms(platforms) {
	const q = question81();
	if (!q) return [];
	const set = new Set(platforms);
	return q.opts.filter((o) => o.f?.platforms?.some((p) => set.has(p))).map((o) => o.id);
}
function platformsFromOptionIds(ids) {
	const q = question81();
	if (!q) return [];
	const found = ids.flatMap((id) => q.opts.find((o) => o.id === id)?.f?.platforms ?? []);
	return PLATFORMS.filter((p) => found.includes(p));
}
var useQuiz = create()(persist((set, get) => ({
	phase: "intro",
	index: 0,
	answers: {},
	platforms: [],
	platformsReturn: "quiz",
	start: () => set({
		phase: "platforms",
		platformsReturn: "quiz",
		index: 0
	}),
	confirmPlatforms: () => set({ phase: get().platformsReturn }),
	setPlatforms: (platforms) => set({
		platforms,
		answers: {
			...get().answers,
			81: optionIdsForPlatforms(platforms)
		}
	}),
	togglePlatform: (platform) => {
		const current = get().platforms;
		const next = current.includes(platform) ? current.filter((p) => p !== platform) : [...current, platform];
		get().setPlatforms(next);
	},
	setAnswer: (questionId, optionIds) => {
		const nextAnswers = {
			...get().answers,
			[questionId]: optionIds
		};
		if (questionId === 81) {
			set({
				answers: nextAnswers,
				platforms: platformsFromOptionIds(optionIds)
			});
			return;
		}
		set({ answers: nextAnswers });
	},
	next: () => {
		const { index } = get();
		if (index >= QUESTIONS.length - 1) {
			set({ phase: "results" });
			return;
		}
		set({ index: index + 1 });
	},
	prev: () => set({ index: Math.max(0, get().index - 1) }),
	skip: () => get().next(),
	goTo: (index) => set({
		index,
		phase: "quiz"
	}),
	finish: () => set({ phase: "results" }),
	reset: () => set({
		phase: "intro",
		index: 0,
		answers: {}
	}),
	editPlatforms: () => set({
		phase: "platforms",
		platformsReturn: "results"
	})
}), { name: "platea-quiz" }));
var POINTS = [
	{
		icon: Clock3,
		title: "Cento domande, dieci atti",
		body: "Genere, tono, ritmo, compagnie. Puoi saltare: il profilo resta utile anche a metà."
	},
	{
		icon: Clapperboard,
		title: "Un film per stasera",
		body: "Non una classifica eterna. Una proposta calibrata su come stai ora, e su quanto tempo hai."
	},
	{
		icon: MonitorPlay,
		title: "Sulle tue piattaforme",
		body: "Prima segnati gli abbonamenti. Poi cerchi su JustWatch, Google e le app che hai già."
	}
];
function Intro() {
	const start = useQuiz((s) => s.start);
	const answers = useQuiz((s) => s.answers);
	const platforms = useQuiz((s) => s.platforms);
	const goTo = useQuiz((s) => s.goTo);
	const ageOk = useLegal((s) => s.ageOk);
	const confirmAge = useLegal((s) => s.confirmAge);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const hasProgress = Object.keys(answers).length > 0;
	const platformLine = platforms.length > 0 ? platforms.map((p) => PLATFORM_META[p].label).join(" · ") : null;
	(0, import_react.useEffect)(() => {
		const unsub = useLegal.persist.onFinishHydration(() => setHydrated(true));
		if (useLegal.persist.hasHydrated()) setHydrated(true);
		return unsub;
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "relative mx-auto flex min-h-dvh max-w-3xl flex-col justify-between px-5 py-10 sm:px-8 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 top-0 h-64 bg-[radial-gradient(ellipse_at_top,color-mix(in_oklab,var(--color-fg)_8%,transparent),transparent_70%)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise-in relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.22em] text-muted uppercase",
						children: "Platea"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 max-w-[14ch] font-display text-4xl italic leading-[1.05] text-fg md:text-[3.35rem]",
						children: "Il film giusto, stasera."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-lg text-base leading-relaxed text-muted",
						children: "Un questionario di gusto, non un test di cinefilia. Prima gli abbonamenti, poi cento domande per capire cosa vuoi vedere adesso."
					}),
					platformLine ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-subtle",
						children: ["Abbonamenti salvati: ", platformLine]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "rise-in rise-in-delay-2 relative mt-12 grid gap-4 sm:grid-cols-3",
				children: POINTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-border bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
							className: "size-4 text-accent",
							strokeWidth: 1.6
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-lg text-fg italic",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: item.body
						})
					]
				}, item.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "rise-in rise-in-delay-4 relative z-10 mt-12 flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-start gap-3 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "mt-1 size-4 shrink-0 accent-accent",
							checked: hydrated && ageOk,
							onChange: (e) => {
								if (e.target.checked) confirmAge();
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Ho almeno ",
							LEGAL.ageMin,
							" anni. Il servizio non è destinato ai minori di ",
							LEGAL.ageMin,
							"."
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row sm:items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								onClick: start,
								disabled: !hydrated || !ageOk,
								className: "min-h-14 w-full sm:w-auto",
								children: platformLine ? "Aggiorna abbonamenti e inizia" : "Scegli le piattaforme"
							}),
							hasProgress ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								size: "lg",
								className: "min-h-14 w-full sm:w-auto",
								disabled: !hydrated || !ageOk,
								onClick: () => goTo(0),
								children: "Riprendi il questionario"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-subtle sm:ml-2",
								children: "Circa 15–20 minuti. Le risposte restano su questo dispositivo."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalFooter, {})
				]
			})
		]
	});
}
function PlatformPicker({ selected, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid grid-cols-1 gap-2 sm:grid-cols-2",
		children: PLATFORMS.map((id) => {
			const on = selected.includes(id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": on,
				onClick: () => onToggle(id),
				className: cn("flex min-h-14 w-full items-center justify-between gap-3 rounded-md border px-4 py-3 text-left transition-[border-color,background-color,transform] duration-150 ease-out", "hover:border-border-strong hover:bg-raised active:scale-[0.99]", on ? "border-accent bg-raised" : "border-border bg-surface"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[0.95rem] text-fg",
					children: PLATFORM_META[id].label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("flex size-6 shrink-0 items-center justify-center rounded-sm border", on ? "border-accent bg-accent text-accent-fg" : "border-border-strong text-transparent"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "size-3.5",
						strokeWidth: 2.2
					})
				})]
			}) }, id);
		})
	});
}
function Platforms() {
	const selected = useQuiz((s) => s.platforms);
	const togglePlatform = useQuiz((s) => s.togglePlatform);
	const confirmPlatforms = useQuiz((s) => s.confirmPlatforms);
	const platformsReturn = useQuiz((s) => s.platformsReturn);
	const count = selected.length;
	const summary = count === 0 ? "Nessun abbonamento selezionato" : count === 1 ? PLATFORM_META[selected[0]].label : `${count} piattaforme`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "mx-auto flex min-h-dvh max-w-2xl flex-col px-5 py-10 sm:px-8 sm:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.22em] text-muted uppercase",
					children: "Abbonamenti"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-3xl italic leading-tight text-fg md:text-4xl",
					children: "Dove guardi, di solito?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-lg text-base leading-relaxed text-muted",
					children: "Segna le piattaforme a cui sei abbonato. I film di stasera verranno ordinati privilegiando quelle librerie. I cataloghi cambiano: non è una garanzia, è una priorità di ricerca."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformPicker, {
					selected,
					onToggle: togglePlatform
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-subtle",
					children: [summary, ". Puoi saltare e scegliere dopo."]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-8 flex flex-col gap-2 border-t border-border pt-5 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: confirmPlatforms,
					className: "min-h-14 w-full sm:w-auto",
					children: count > 0 ? "Continua con queste" : "Salta per ora"
				}), platformsReturn === "results" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "self-center text-xs text-subtle",
					children: "Tornerai ai risultati, ricalcolati."
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalFooter, {})
		]
	});
}
var CHAPTERS = [
	{
		id: 1,
		title: "Stasera",
		subtitle: "Tempo, umore, compagnia"
	},
	{
		id: 2,
		title: "Genere",
		subtitle: "Cosa ti attira, e cosa no"
	},
	{
		id: 3,
		title: "Tono",
		subtitle: "Luce, ombra, ironia"
	},
	{
		id: 4,
		title: "Persone",
		subtitle: "Chi vuoi seguire"
	},
	{
		id: 5,
		title: "Mondi",
		subtitle: "Dove vuoi stare"
	},
	{
		id: 6,
		title: "Forma",
		subtitle: "Ritmo, durata, stile"
	},
	{
		id: 7,
		title: "Temi",
		subtitle: "Di cosa deve parlare"
	},
	{
		id: 8,
		title: "Origini",
		subtitle: "Epoca e geografia"
	},
	{
		id: 9,
		title: "Visione",
		subtitle: "Come e dove guardi"
	},
	{
		id: 10,
		title: "Confini",
		subtitle: "Cose da evitare, e priorità"
	}
];
function QuizView() {
	const index = useQuiz((s) => s.index);
	const answers = useQuiz((s) => s.answers);
	const setAnswer = useQuiz((s) => s.setAnswer);
	const platforms = useQuiz((s) => s.platforms);
	const next = useQuiz((s) => s.next);
	const prev = useQuiz((s) => s.prev);
	const skip = useQuiz((s) => s.skip);
	const finish = useQuiz((s) => s.finish);
	const question = QUESTIONS[index];
	const chapter = CHAPTERS.find((c) => c.id === question.ch);
	const selected = answers[question.id] ?? [];
	const isMulti = question.type === "multi";
	const answeredCount = Object.keys(answers).length;
	const [flash, setFlash] = (0, import_react.useState)(question.id);
	(0, import_react.useEffect)(() => {
		setFlash(question.id);
	}, [question.id]);
	(0, import_react.useEffect)(() => {
		if (question.id !== 81) return;
		if ((answers[81]?.length ?? 0) > 0 || platforms.length === 0) return;
		setAnswer(81, optionIdsForPlatforms(platforms));
	}, [
		question.id,
		answers,
		platforms,
		setAnswer
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "ArrowRight") {
				if (isMulti && selected.length) next();
				else if (!isMulti) skip();
			}
			if (e.key === "ArrowLeft") prev();
			if (e.key === "Enter" && isMulti && selected.length) next();
			const n = Number(e.key);
			if (n >= 1 && n <= question.opts.length) {
				const opt = question.opts[n - 1];
				choose(opt.id);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		question.id,
		selected.join("|"),
		isMulti
	]);
	function choose(id) {
		if (isMulti) {
			const nextIds = selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id];
			setAnswer(question.id, nextIds);
			return;
		}
		setAnswer(question.id, [id]);
		window.setTimeout(() => next(), 140);
	}
	const pct = (index + 1) / QUESTIONS.length * 100;
	const chapterPct = (0, import_react.useMemo)(() => {
		const inChapter = QUESTIONS.filter((q) => q.ch === chapter.id);
		return {
			pos: inChapter.findIndex((q) => q.id === question.id) + 1,
			total: inChapter.length
		};
	}, [chapter.id, question.id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "mx-auto flex min-h-dvh max-w-2xl flex-col px-5 py-6 sm:px-8 sm:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] font-medium tracking-[0.2em] text-muted uppercase",
					children: [
						"Atto ",
						chapter.id,
						" di 10 · ",
						chapter.title
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-subtle",
					children: chapter.subtitle
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs tabular-nums text-muted",
					children: [String(index + 1).padStart(3, "0"), " / 100"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 h-[2px] overflow-hidden rounded-full bg-raised",
				role: "progressbar",
				"aria-valuenow": index + 1,
				"aria-valuemin": 1,
				"aria-valuemax": 100,
				"aria-label": "Avanzamento",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-accent transition-[width] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
					style: { width: `${pct}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in mt-10 flex flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-subtle",
						children: [
							chapter.title,
							" · ",
							chapterPct.pos,
							"/",
							chapterPct.total,
							isMulti ? " · più risposte" : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-xl leading-snug text-fg italic sm:text-2xl",
						children: question.q
					}),
					question.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: question.hint
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 flex flex-col gap-2.5",
						children: question.opts.map((opt, i) => {
							const on = selected.includes(opt.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"data-selected": on,
								onClick: () => choose(opt.id),
								className: cn("flex min-h-14 w-full items-start gap-4 rounded-md border bg-surface px-4 py-3.5 text-left transition-[border-color,background-color,transform] duration-150 ease-out", "hover:border-border-strong hover:bg-raised active:scale-[0.99]", on ? "border-accent bg-raised" : "border-border"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-sm border border-border-strong font-mono text-[11px] text-muted",
									children: i + 1
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[0.95rem] leading-snug text-fg",
									children: opt.label
								})]
							}) }, opt.id);
						})
					})
				]
			}, flash),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-8 flex flex-wrap items-center gap-2 border-t border-border pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: prev,
						disabled: index === 0,
						className: "min-h-11",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Indietro"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: skip,
						className: "min-h-11",
						children: ["Salta", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
					}),
					isMulti ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "ml-auto min-h-11",
						onClick: next,
						disabled: selected.length === 0,
						children: "Continua"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ml-auto" }),
					answeredCount >= 20 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						size: "sm",
						onClick: finish,
						className: "min-h-11",
						children: "Vedi i risultati"
					}) : null
				]
			})
		]
	});
}
function m(id, title, year, runtime, director, country, platforms, synopsis, v, extra) {
	const { kidsOk, ...weights } = v;
	return {
		id,
		title,
		year,
		runtime,
		director,
		country,
		platforms,
		synopsis,
		v: weights,
		originalTitle: extra?.originalTitle,
		kidsOk: extra?.kidsOk ?? kidsOk
	};
}
var MOVIES = [
	m("paradiso", "Nuovo Cinema Paradiso", 1988, 124, "Giuseppe Tornatore", "Italia", [
		"netflix",
		"prime",
		"raiplay"
	], "Un proiezionista di paese e un bambino: memoria, sala, primo amore.", {
		italiano: 9,
		dramma: 7,
		malinconico: 7,
		classico: 6,
		amore: 5,
		famiglia: 5,
		speranza: 5,
		intimo: 6
	}),
	m("bellezza", "La grande bellezza", 2013, 141, "Paolo Sorrentino", "Italia", [
		"netflix",
		"prime",
		"mubi"
	], "Roma notturna, vanità, un romanziere che ha smesso di scrivere.", {
		italiano: 9,
		dramma: 6,
		malinconico: 6,
		stilizzato: 8,
		immagini: 8,
		lento: 5,
		identita: 6,
		cinico: 4,
		lungo: 5
	}),
	m("vita-bella", "La vita è bella", 1997, 116, "Roberto Benigni", "Italia", [
		"prime",
		"raiplay",
		"netflix"
	], "Un padre inventa un gioco per proteggere il figlio nel campo.", {
		italiano: 8,
		dramma: 8,
		commedia: 5,
		famiglia: 7,
		speranza: 6,
		guerra: 5,
		malinconico: 5,
		amore: 4
	}),
	m("gomorra", "Gomorra", 2008, 137, "Matteo Garrone", "Italia", [
		"prime",
		"netflix",
		"raiplay"
	], "Cinque storie nel sistema camorra, senza mitologia da gangster.", {
		italiano: 9,
		crime: 8,
		vero: 8,
		oscuro: 7,
		cinico: 6,
		potere: 7,
		dramma: 6,
		complesso: 5
	}),
	m("perfetti", "Perfetti sconosciuti", 2016, 97, "Paolo Genovese", "Italia", [
		"netflix",
		"prime",
		"raiplay"
	], "Una cena tra amici, i telefoni sul tavolo, le vite che si spaccano.", {
		italiano: 8,
		commedia: 6,
		dramma: 6,
		ironico: 5,
		dialoghi: 8,
		intimo: 7,
		breve: 6,
		famiglia: 3
	}),
	m("mano-dio", "È stata la mano di Dio", 2021, 130, "Paolo Sorrentino", "Italia", ["netflix"], "Napoli, Maradona, un ragazzo e il colpo che gli spezza l'adolescenza.", {
		italiano: 9,
		dramma: 7,
		identita: 7,
		malinconico: 6,
		famiglia: 5,
		stilizzato: 6,
		immagini: 6,
		moderno: 5
	}),
	m("indagine", "Indagine su un cittadino al di sopra di ogni sospetto", 1970, 115, "Elio Petri", "Italia", ["raiplay", "mubi"], "Un commissario uccide e sfida lo Stato a prenderlo.", {
		italiano: 8,
		crime: 7,
		potere: 8,
		cinico: 7,
		classico: 7,
		ironico: 5,
		complesso: 5,
		thriller: 5
	}),
	m("soliti", "I soliti ignoti", 1958, 106, "Mario Monicelli", "Italia", ["raiplay", "prime"], "Un colpo in un ghetto romano: bungling, affetto, Italia del boom.", {
		italiano: 9,
		commedia: 8,
		crime: 5,
		classico: 8,
		ironico: 6,
		leggero: 5,
		famiglia: 3
	}),
	m("dolce-vita", "La dolce vita", 1960, 174, "Federico Fellini", "Italia", [
		"mubi",
		"raiplay",
		"prime"
	], "Un giornalista vaga in una Roma di feste, noia e miracoli finti.", {
		italiano: 9,
		dramma: 6,
		classico: 8,
		stilizzato: 7,
		lungo: 8,
		identita: 6,
		cinico: 5,
		immagini: 7,
		lento: 5
	}),
	m("ottoemezzo", "8½", 1963, 138, "Federico Fellini", "Italia", ["mubi", "raiplay"], "Un regista non riesce a fare il film, e fa questo.", {
		italiano: 9,
		classico: 8,
		complesso: 8,
		stilizzato: 8,
		identita: 8,
		strano: 6,
		lungo: 5,
		immagini: 7
	}),
	m("ladro-biciclette", "Ladri di biciclette", 1948, 89, "Vittorio De Sica", "Italia", [
		"raiplay",
		"mubi",
		"prime"
	], "Un uomo e un bambino cercano una bicicletta, e la dignità.", {
		italiano: 9,
		dramma: 8,
		classico: 9,
		vero: 9,
		famiglia: 6,
		malinconico: 6,
		breve: 6,
		lento: 4
	}),
	m("chiamami", "Chiamami col tuo nome", 2017, 132, "Luca Guadagnino", "Italia", [
		"netflix",
		"prime",
		"mubi"
	], "Un'estate lombarda, un ragazzo, un ospite, il primo amore.", {
		italiano: 6,
		europa: 5,
		romance: 8,
		amore: 8,
		intimo: 8,
		malinconico: 6,
		identita: 5,
		lento: 5,
		immagini: 6
	}),
	m("dogman", "Dogman", 2018, 103, "Matteo Garrone", "Italia", ["prime", "netflix"], "Un toelettatore di cani e un bullo: violenza, lealtà, provincia.", {
		italiano: 8,
		dramma: 7,
		crime: 5,
		oscuro: 7,
		vero: 6,
		intimo: 5,
		cinico: 4
	}),
	m("suburra", "Suburra", 2015, 135, "Stefano Sollima", "Italia", ["netflix", "prime"], "Roma, palazzinari, mafia, Vaticano: tre giorni di potere sporco.", {
		italiano: 8,
		crime: 8,
		teso: 6,
		potere: 7,
		oscuro: 6,
		veloce: 5,
		moderno: 5
	}),
	m("jeeg", "Lo chiamavano Jeeg Robot", 2015, 112, "Gabriele Mainetti", "Italia", [
		"netflix",
		"prime",
		"raiplay"
	], "Un ladruncolo romano diventa, suo malgrado, un supereroe di borgata.", {
		italiano: 8,
		azione: 5,
		strano: 5,
		crime: 4,
		ironico: 5,
		moderno: 5,
		spettacolo: 3
	}),
	m("parasite", "Parasite", 2019, 132, "Bong Joon-ho", "Corea del Sud", [
		"netflix",
		"prime",
		"mubi"
	], "Una famiglia si infiltra in una casa ricca. Poi la casa risponde.", {
		asia: 9,
		thriller: 8,
		dramma: 7,
		ironico: 6,
		potere: 8,
		oscuro: 6,
		complesso: 6,
		moderno: 8,
		teso: 7
	}),
	m("memories-murder", "Memories of Murder", 2003, 131, "Bong Joon-ho", "Corea del Sud", [
		"prime",
		"mubi",
		"netflix"
	], "Un serial killer in provincia, poliziotti goffi, pioggia, nessun lieto fine facile.", {
		asia: 8,
		crime: 8,
		mistero: 7,
		thriller: 6,
		vero: 6,
		cinico: 5,
		ironico: 4,
		complesso: 5
	}),
	m("oldboy", "Oldboy", 2003, 120, "Park Chan-wook", "Corea del Sud", ["prime", "mubi"], "Quindici anni in una stanza, poi la vendetta. Barocco e feroce.", {
		asia: 8,
		thriller: 8,
		oscuro: 8,
		strano: 6,
		stilizzato: 7,
		teso: 7,
		cinico: 6
	}),
	m("decision", "Decision to Leave", 2022, 138, "Park Chan-wook", "Corea del Sud", [
		"mubi",
		"prime",
		"apple"
	], "Un investigatore e una vedova: amore, colpa, montagne e mare.", {
		asia: 8,
		romance: 6,
		mistero: 7,
		thriller: 6,
		stilizzato: 8,
		amore: 6,
		complesso: 6,
		moderno: 7
	}),
	m("shoplifters", "Un affare di famiglia", 2018, 121, "Hirokazu Kore-eda", "Giappone", [
		"mubi",
		"prime",
		"netflix"
	], "Una famiglia di ladruncoli accoglie una bambina. Chi è famiglia, davvero?", {
		asia: 8,
		dramma: 8,
		famiglia: 8,
		intimo: 7,
		vero: 6,
		malinconico: 6,
		lento: 5
	}, { originalTitle: "Manbiki kazoku" }),
	m("drive-car", "Drive My Car", 2021, 179, "Ryusuke Hamaguchi", "Giappone", [
		"mubi",
		"prime",
		"apple"
	], "Un vedovo, una Chevrolet, Chekhov, una autista. Tempo lungo, parole vere.", {
		asia: 8,
		dramma: 8,
		lento: 8,
		dialoghi: 8,
		intimo: 8,
		identita: 6,
		lungo: 8,
		complesso: 6,
		malinconico: 6
	}),
	m("your-name", "Your Name.", 2016, 106, "Makoto Shinkai", "Giappone", [
		"prime",
		"netflix",
		"mubi"
	], "Due adolescenti si scambiano i corpi, e poi il tempo si piega.", {
		asia: 7,
		animazione: 9,
		romance: 7,
		amore: 6,
		stilizzato: 7,
		identita: 5,
		spettacolo: 4,
		famiglia: 3,
		kidsOk: true
	}),
	m("spirited", "La città incantata", 2001, 125, "Hayao Miyazaki", "Giappone", ["netflix", "prime"], "Una bambina in un mondo di spiriti, lavoro, coraggio, ritorno.", {
		asia: 7,
		animazione: 9,
		fantasy: 8,
		avventura: 6,
		famiglia: 6,
		identita: 5,
		spettacolo: 5,
		speranza: 5,
		kidsOk: true
	}),
	m("mononoke", "Princess Mononoke", 1997, 134, "Hayao Miyazaki", "Giappone", ["netflix", "prime"], "Foresta, ferro, dèi feriti: un ragazzo tra due guerre.", {
		asia: 7,
		animazione: 9,
		fantasy: 8,
		avventura: 6,
		oscuro: 4,
		complesso: 4,
		immagini: 6,
		kidsOk: true
	}),
	m("tokyo-story", "Viaggio a Tokyo", 1953, 136, "Yasujirō Ozu", "Giappone", ["mubi", "raiplay"], "Due genitori anziani visitano i figli. Poche parole, tutto il tempo.", {
		asia: 8,
		classico: 9,
		dramma: 8,
		famiglia: 8,
		lento: 8,
		intimo: 8,
		malinconico: 7,
		immagini: 6
	}),
	m("amelie", "Il favoloso mondo di Amélie", 2001, 122, "Jean-Pierre Jeunet", "Francia", [
		"netflix",
		"prime",
		"mubi"
	], "Una cameriera inventa piccole cospirazioni di tenerezza a Montmartre.", {
		europa: 8,
		commedia: 6,
		romance: 6,
		stilizzato: 8,
		leggero: 6,
		speranza: 6,
		amore: 5,
		strano: 3
	}, { originalTitle: "Le Fabuleux Destin d'Amélie Poulain" }),
	m("portrait", "Ritratto della giovane in fiamme", 2019, 121, "Céline Sciamma", "Francia", [
		"mubi",
		"prime",
		"netflix"
	], "Un'isola, un ritratto, due donne, il tempo di uno sguardo.", {
		europa: 8,
		romance: 8,
		amore: 8,
		intimo: 8,
		immagini: 8,
		lento: 6,
		identita: 5,
		classico: 2
	}),
	m("anatomy", "Anatomia di una caduta", 2023, 152, "Justine Triet", "Francia", [
		"mubi",
		"prime",
		"apple"
	], "Un marito cade. Un processo. Un figlio cieco. La verità non sta ferma.", {
		europa: 8,
		mistero: 7,
		dramma: 7,
		dialoghi: 8,
		complesso: 7,
		thriller: 5,
		intimo: 5,
		moderno: 8,
		lungo: 5
	}),
	m("intouchables", "Quasi amici", 2011, 112, "Olivier Nakache, Éric Toledano", "Francia", ["netflix", "prime"], "Un aristocratico paralizzato e il suo assistente: classe, risate, cura.", {
		europa: 6,
		commedia: 7,
		dramma: 5,
		leggero: 5,
		speranza: 5,
		dialoghi: 5,
		famiglia: 3
	}, { originalTitle: "Intouchables" }),
	m("lives-others", "Le vite degli altri", 2006, 137, "Florian Henckel von Donnersmarck", "Germania", [
		"prime",
		"mubi",
		"netflix"
	], "Uno Stasi ascolta una coppia di artisti e inizia a tradire il sistema.", {
		europa: 8,
		dramma: 8,
		thriller: 5,
		potere: 7,
		intimo: 6,
		malinconico: 5,
		vero: 5
	}),
	m("another-round", "Un altro giro", 2020, 117, "Thomas Vinterberg", "Danimarca", [
		"prime",
		"mubi",
		"netflix"
	], "Quattro professori testano l'alcol come medicina. Poi il test scappa.", {
		europa: 8,
		dramma: 6,
		commedia: 5,
		identita: 6,
		ironico: 4,
		vero: 5,
		malinconico: 4
	}, { originalTitle: "Druk" }),
	m("worst-person", "La persona peggiore del mondo", 2021, 128, "Joachim Trier", "Norvegia", [
		"mubi",
		"prime",
		"apple"
	], "Una donna a Oslo cambia vite, amori, idee di sé. Tre capitoli.", {
		europa: 8,
		dramma: 6,
		romance: 5,
		identita: 8,
		ironico: 5,
		moderno: 7,
		intimo: 6,
		amore: 5
	}),
	m("zone", "The Zone of Interest", 2023, 105, "Jonathan Glazer", "UK / Polonia", [
		"mubi",
		"prime",
		"apple"
	], "Una villa idilliaca a un muro da Auschwitz. Il male come giardino.", {
		europa: 7,
		dramma: 7,
		guerra: 7,
		oscuro: 8,
		complesso: 8,
		stilizzato: 7,
		vero: 6,
		lento: 5,
		breve: 3
	}),
	m("godfather", "Il padrino", 1972, 175, "Francis Ford Coppola", "USA", [
		"paramount",
		"prime",
		"now"
	], "Un patriarca, un figlio, una famiglia che è uno Stato.", {
		hollywood: 8,
		crime: 9,
		dramma: 8,
		classico: 8,
		famiglia: 7,
		potere: 8,
		lungo: 8,
		complesso: 5,
		oscuro: 5
	}),
	m("goodfellas", "Quei bravi ragazzi", 1990, 146, "Martin Scorsese", "USA", [
		"netflix",
		"prime",
		"now"
	], "Entrare nella mafia è una festa. Restarci è un crollo.", {
		hollywood: 8,
		crime: 9,
		cinico: 6,
		veloce: 6,
		ironico: 5,
		biografico: 5,
		lungo: 5
	}),
	m("pulp", "Pulp Fiction", 1994, 154, "Quentin Tarantino", "USA", [
		"prime",
		"paramount",
		"netflix"
	], "Los Angeles a capitoli: valigette, balli, miracoli e hamburger.", {
		hollywood: 8,
		crime: 7,
		ironico: 8,
		strano: 5,
		dialoghi: 8,
		complesso: 5,
		stilizzato: 6
	}),
	m("dark-knight", "Il cavaliere oscuro", 2008, 152, "Christopher Nolan", "USA", [
		"netflix",
		"prime",
		"now"
	], "Batman, un clown, una città che prova a restare decente.", {
		hollywood: 8,
		azione: 7,
		thriller: 7,
		oscuro: 6,
		spettacolo: 7,
		complesso: 4,
		teso: 6,
		lungo: 5
	}),
	m("inception", "Inception", 2010, 148, "Christopher Nolan", "USA", ["netflix", "prime"], "Sogni dentro sogni, un furto, un palloncino che non smette di girare.", {
		hollywood: 8,
		scifi: 8,
		thriller: 6,
		complesso: 7,
		spettacolo: 7,
		mistero: 5,
		azione: 5,
		lungo: 5
	}),
	m("interstellar", "Interstellar", 2014, 169, "Christopher Nolan", "USA", [
		"paramount",
		"prime",
		"netflix"
	], "Un padre, il mais che muore, e un buco nero che è anche una stanza.", {
		hollywood: 8,
		scifi: 9,
		dramma: 6,
		spettacolo: 8,
		famiglia: 6,
		speranza: 5,
		lungo: 8,
		immagini: 6
	}),
	m("dune", "Dune", 2021, 155, "Denis Villeneuve", "USA", ["prime", "netflix"], "Sabbia, profezie, un ragazzo e un pianeta che è una trappola.", {
		hollywood: 7,
		scifi: 8,
		spettacolo: 8,
		immagini: 8,
		lento: 4,
		avventura: 5,
		complesso: 4,
		lungo: 6,
		fantasy: 3
	}),
	m("blade2049", "Blade Runner 2049", 2017, 164, "Denis Villeneuve", "USA", ["netflix", "prime"], "Un replicante cerca una verità, e Los Angeles è neve e neon.", {
		hollywood: 6,
		scifi: 9,
		lento: 6,
		immagini: 9,
		identita: 7,
		malinconico: 6,
		spettacolo: 6,
		lungo: 7,
		oscuro: 5
	}),
	m("arrival", "Arrival", 2016, 116, "Denis Villeneuve", "USA", [
		"prime",
		"netflix",
		"apple"
	], "Linguiste e alieni: il tempo è una lingua, il lutto è la grammatica.", {
		scifi: 8,
		dramma: 7,
		identita: 6,
		intimo: 6,
		complesso: 6,
		malinconico: 5,
		famiglia: 4,
		hollywood: 5
	}),
	m("exmachina", "Ex Machina", 2014, 108, "Alex Garland", "UK", [
		"prime",
		"netflix",
		"apple"
	], "Una casa di vetro, un genio, una macchina che forse sente.", {
		scifi: 8,
		thriller: 7,
		intimo: 6,
		teso: 6,
		identita: 6,
		dialoghi: 5,
		europa: 4,
		breve: 4
	}),
	m("her", "Her", 2013, 126, "Spike Jonze", "USA", [
		"prime",
		"netflix",
		"apple"
	], "Un uomo si innamora di un sistema operativo. Los Angeles pastello.", {
		romance: 7,
		scifi: 6,
		amore: 7,
		identita: 7,
		malinconico: 6,
		intimo: 7,
		stilizzato: 5,
		moderno: 5
	}),
	m("lost-translation", "Lost in Translation", 2003, 102, "Sofia Coppola", "USA", [
		"mubi",
		"prime",
		"netflix"
	], "Due insonni a Tokyo, un karaoke, una frase che non sentiamo.", {
		dramma: 6,
		intimo: 8,
		malinconico: 7,
		identita: 5,
		lento: 5,
		asia: 3,
		hollywood: 4,
		breve: 4,
		ironico: 3
	}),
	m("social-network", "The Social Network", 2010, 120, "David Fincher", "USA", ["netflix", "prime"], "Facebook nasce, le amicizie muoiono, Sorkin parla velocissimo.", {
		hollywood: 7,
		dramma: 6,
		biografico: 7,
		dialoghi: 8,
		cinico: 6,
		potere: 6,
		veloce: 6,
		vero: 5
	}),
	m("zodiac", "Zodiac", 2007, 157, "David Fincher", "USA", [
		"prime",
		"netflix",
		"paramount"
	], "Un'ossessione di decenni, un killer, nessuna catarsi facile.", {
		hollywood: 6,
		mistero: 8,
		thriller: 7,
		crime: 6,
		complesso: 6,
		teso: 5,
		vero: 6,
		lungo: 6,
		lento: 3
	}),
	m("se7en", "Seven", 1995, 127, "David Fincher", "USA", [
		"prime",
		"netflix",
		"now"
	], "Due poliziotti, sette peccati, una scatola.", {
		hollywood: 7,
		thriller: 8,
		oscuro: 8,
		crime: 7,
		teso: 7,
		cinico: 6,
		mistero: 5
	}),
	m("gone-girl", "L'amore bugiardo", 2014, 149, "David Fincher", "USA", [
		"prime",
		"netflix",
		"apple"
	], "Una moglie scompare. Il matrimonio è il delitto.", {
		hollywood: 7,
		thriller: 8,
		cinico: 7,
		ironico: 5,
		amore: 4,
		teso: 6,
		complesso: 4,
		dialoghi: 5
	}, { originalTitle: "Gone Girl" }),
	m("fight-club", "Fight Club", 1999, 139, "David Fincher", "USA", [
		"prime",
		"netflix",
		"disney"
	], "Insonnia, sapone, un amico troppo carismatico.", {
		hollywood: 7,
		thriller: 6,
		identita: 7,
		cinico: 7,
		strano: 5,
		stilizzato: 6,
		oscuro: 5
	}),
	m("whiplash", "Whiplash", 2014, 107, "Damien Chazelle", "USA", ["netflix", "prime"], "Un batterista, un maestro crudele, il tempo come violenza.", {
		hollywood: 6,
		dramma: 7,
		identita: 6,
		teso: 8,
		musical: 5,
		intimo: 5,
		veloce: 4,
		breve: 4
	}),
	m("la-la-land", "La La Land", 2016, 128, "Damien Chazelle", "USA", [
		"netflix",
		"prime",
		"now"
	], "Due sognatori a Los Angeles, musica, e il prezzo di farcela.", {
		hollywood: 7,
		musical: 8,
		romance: 7,
		amore: 7,
		malinconico: 5,
		speranza: 4,
		stilizzato: 6,
		spettacolo: 4
	}),
	m("get-out", "Scappa - Get Out", 2017, 104, "Jordan Peele", "USA", [
		"prime",
		"netflix",
		"now"
	], "Un weekend dai suoceri bianchi. L'horror è la villa, e la razza.", {
		hollywood: 6,
		horror: 7,
		thriller: 7,
		ironico: 6,
		teso: 7,
		complesso: 4,
		identita: 5,
		breve: 4
	}),
	m("hereditary", "Hereditary", 2018, 127, "Ari Aster", "USA", [
		"prime",
		"now",
		"paramount"
	], "Una famiglia, un lutto, qualcosa in soffitta che non è metafora.", {
		horror: 8,
		oscuro: 8,
		famiglia: 6,
		teso: 7,
		dramma: 5,
		lento: 3,
		stilizzato: 4
	}),
	m("witch", "The Witch", 2015, 92, "Robert Eggers", "USA", [
		"prime",
		"mubi",
		"netflix"
	], "Puritanesimo, bosco, una capra, la paura come teologia.", {
		horror: 7,
		lento: 6,
		oscuro: 7,
		stilizzato: 6,
		famiglia: 4,
		complesso: 4,
		breve: 6,
		immagini: 5
	}),
	m("madmax", "Mad Max: Fury Road", 2015, 120, "George Miller", "Australia", [
		"netflix",
		"prime",
		"now"
	], "Una fuga nel deserto che è anche un balletto di lamiere.", {
		azione: 9,
		spettacolo: 9,
		veloce: 9,
		stilizzato: 7,
		hollywood: 5,
		avventura: 6,
		immagini: 7
	}),
	m("johnwick", "John Wick", 2014, 101, "Chad Stahelski", "USA", [
		"prime",
		"netflix",
		"paramount"
	], "Un cane, una macchina, un uomo che era uscito e rientra.", {
		azione: 9,
		veloce: 8,
		spettacolo: 6,
		hollywood: 6,
		stilizzato: 5,
		breve: 5,
		crime: 3
	}),
	m("matrix", "Matrix", 1999, 136, "Lana e Lilly Wachowski", "USA", ["prime", "netflix"], "Il mondo è un programma. La scelta è una pillola.", {
		scifi: 9,
		azione: 7,
		complesso: 6,
		spettacolo: 7,
		identita: 6,
		hollywood: 7,
		stilizzato: 7
	}),
	m("alien", "Alien", 1979, 117, "Ridley Scott", "USA / UK", [
		"disney",
		"prime",
		"now"
	], "Uno scafo, una ciurma, qualcosa che non andava ospitato.", {
		horror: 8,
		scifi: 7,
		teso: 8,
		lento: 4,
		classico: 6,
		oscuro: 6,
		hollywood: 5
	}),
	m("jaws", "Lo squalo", 1975, 124, "Steven Spielberg", "USA", [
		"prime",
		"now",
		"paramount"
	], "Una spiaggia, un sindaco, tre uomini e un problema con le pinne.", {
		hollywood: 8,
		thriller: 8,
		avventura: 6,
		classico: 7,
		teso: 7,
		spettacolo: 5,
		semplice: 3
	}),
	m("raiders", "I predatori dell'arca perduta", 1981, 115, "Steven Spielberg", "USA", [
		"prime",
		"disney",
		"paramount"
	], "Un archeologo, i nazisti, e il cinema come giostre.", {
		hollywood: 8,
		avventura: 9,
		azione: 6,
		leggero: 5,
		classico: 6,
		spettacolo: 6,
		speranza: 3,
		kidsOk: true
	}),
	m("jurassic", "Jurassic Park", 1993, 127, "Steven Spielberg", "USA", [
		"prime",
		"netflix",
		"now"
	], "La meraviglia, poi i denti. Un parco, un sistema che si rompe.", {
		hollywood: 8,
		avventura: 8,
		scifi: 5,
		spettacolo: 8,
		famiglia: 4,
		teso: 5,
		kidsOk: true
	}),
	m("diehard", "Die Hard", 1988, 132, "John McTiernan", "USA", [
		"disney",
		"prime",
		"now"
	], "Un poliziotto scalzo in un grattacielo, Natale, vetri.", {
		hollywood: 8,
		azione: 8,
		thriller: 6,
		ironico: 5,
		veloce: 6,
		classico: 5,
		spettacolo: 5
	}),
	m("heat", "Heat", 1995, 170, "Michael Mann", "USA", [
		"prime",
		"now",
		"paramount"
	], "Un ladro e un poliziotto che si riconoscono. Los Angeles notturna.", {
		hollywood: 7,
		crime: 8,
		dramma: 6,
		azione: 5,
		lungo: 8,
		teso: 5,
		identita: 4,
		immagini: 5
	}),
	m("no-country", "Non è un paese per vecchi", 2007, 122, "Joel ed Ethan Coen", "USA", [
		"prime",
		"netflix",
		"paramount"
	], "Una valigia, il Texas, un uomo con una pistola ad aria.", {
		hollywood: 6,
		thriller: 7,
		oscuro: 7,
		cinico: 7,
		crime: 6,
		complesso: 5,
		western: 4,
		teso: 6
	}),
	m("fargo", "Fargo", 1996, 98, "Joel ed Ethan Coen", "USA", [
		"prime",
		"netflix",
		"mubi"
	], "Neve, un rapimento stupido, una sceriffa incinta, un tritacarne.", {
		hollywood: 6,
		crime: 7,
		ironico: 8,
		commedia: 5,
		thriller: 5,
		breve: 6,
		cinico: 4
	}),
	m("grand-budapest", "Grand Budapest Hotel", 2014, 99, "Wes Anderson", "USA", [
		"disney",
		"prime",
		"apple"
	], "Un concierge, un protégé, una facciata rosa, l'Europa che muore.", {
		hollywood: 5,
		europa: 5,
		commedia: 6,
		stilizzato: 9,
		ironico: 6,
		breve: 6,
		avventura: 3,
		malinconico: 3
	}),
	m("moonrise", "Moonrise Kingdom", 2012, 94, "Wes Anderson", "USA", [
		"disney",
		"prime",
		"apple"
	], "Due dodicenni scappano, un'isola, un temporale, una tenda.", {
		commedia: 5,
		amore: 5,
		stilizzato: 8,
		famiglia: 4,
		identita: 4,
		breve: 6,
		leggero: 4,
		kidsOk: true
	}),
	m("everything", "Everything Everywhere All at Once", 2022, 139, "Daniels", "USA", [
		"prime",
		"netflix",
		"apple"
	], "Una lavanderia, le tasse, e tutti i sé possibili.", {
		scifi: 6,
		commedia: 6,
		famiglia: 7,
		identita: 8,
		strano: 8,
		azione: 5,
		moderno: 8,
		spettacolo: 5,
		amore: 4
	}),
	m("moonlight", "Moonlight", 2016, 111, "Barry Jenkins", "USA", [
		"prime",
		"netflix",
		"apple"
	], "Tre età, un ragazzo, la luce di Miami, diventare se stessi.", {
		dramma: 8,
		identita: 9,
		intimo: 8,
		malinconico: 6,
		immagini: 7,
		amore: 5,
		vero: 5,
		hollywood: 4
	}),
	m("lady-bird", "Lady Bird", 2017, 94, "Greta Gerwig", "USA", [
		"prime",
		"netflix",
		"now"
	], "Sacramento, una madre, una figlia, l'ultimo anno prima di partire.", {
		dramma: 6,
		commedia: 5,
		identita: 7,
		famiglia: 7,
		intimo: 6,
		breve: 6,
		ironico: 4,
		amore: 3
	}),
	m("little-women", "Piccole donne", 2019, 135, "Greta Gerwig", "USA", [
		"prime",
		"apple",
		"now"
	], "Quattro sorelle, il tempo che si piega, scrivere per vivere.", {
		dramma: 6,
		famiglia: 7,
		amore: 5,
		identita: 5,
		speranza: 4,
		hollywood: 5,
		classico: 2,
		kidsOk: true
	}),
	m("before-sunrise", "Prima dell'alba", 1995, 101, "Richard Linklater", "USA / Austria", [
		"mubi",
		"prime",
		"netflix"
	], "Un treno, Vienna, una notte di parole che diventano destino.", {
		romance: 8,
		amore: 8,
		dialoghi: 9,
		intimo: 8,
		europa: 5,
		breve: 5,
		identita: 4
	}),
	m("eternal", "Se mi lasci ti cancello", 2004, 108, "Michel Gondry", "USA", [
		"prime",
		"netflix",
		"mubi"
	], "Cancellare un amore dal cervello. Poi il cervello resiste.", {
		romance: 7,
		scifi: 5,
		amore: 8,
		strano: 6,
		identita: 6,
		malinconico: 5,
		stilizzato: 6
	}, { originalTitle: "Eternal Sunshine of the Spotless Mind" }),
	m("truman", "The Truman Show", 1998, 103, "Peter Weir", "USA", [
		"paramount",
		"prime",
		"now"
	], "Una vita in diretta, un cielo di cartone, la porta sul set.", {
		hollywood: 6,
		dramma: 6,
		scifi: 4,
		identita: 7,
		ironico: 5,
		speranza: 4,
		semplice: 3
	}),
	m("oppenheimer", "Oppenheimer", 2023, 180, "Christopher Nolan", "USA", [
		"prime",
		"paramount",
		"now"
	], "Un fisico, una bomba, un'udienza. Il secolo in un volto.", {
		hollywood: 7,
		biografico: 8,
		dramma: 7,
		complesso: 7,
		vero: 6,
		lungo: 8,
		teso: 5,
		potere: 6,
		guerra: 5
	}),
	m("barbie", "Barbie", 2023, 114, "Greta Gerwig", "USA", ["prime", "now"], "Una bambola esce dal rosa e scopre il mondo, e il patriarcato.", {
		commedia: 7,
		identita: 6,
		stilizzato: 7,
		leggero: 5,
		ironico: 6,
		hollywood: 6,
		spettacolo: 4,
		famiglia: 3,
		kidsOk: true
	}),
	m("poor-things", "Povere creature!", 2023, 141, "Yorgos Lanthimos", "UK / Irlanda", [
		"disney",
		"prime",
		"now"
	], "Una donna ri-nata esplora il mondo con curiosità scientifica e scandalo.", {
		europa: 6,
		strano: 8,
		identita: 7,
		ironico: 6,
		stilizzato: 8,
		romance: 3,
		complesso: 5
	}, { originalTitle: "Poor Things" }),
	m("banshees", "Gli spiriti dell'isola", 2022, 114, "Martin McDonagh", "Irlanda / UK", [
		"disney",
		"prime",
		"now"
	], "Due amici, un'isola, una guerra lontana, un dito sul tavolo.", {
		europa: 7,
		dramma: 6,
		commedia: 5,
		ironico: 7,
		dialoghi: 7,
		famiglia: 4,
		cinico: 4,
		intimo: 5
	}, { originalTitle: "The Banshees of Inisherin" }),
	m("aftersun", "Aftersun", 2022, 102, "Charlotte Wells", "UK", [
		"mubi",
		"prime",
		"apple"
	], "Un padre, una figlia, una vacanza. Il ricordo è un video-cassetta.", {
		europa: 7,
		dramma: 8,
		intimo: 9,
		malinconico: 8,
		famiglia: 7,
		identita: 5,
		lento: 5,
		immagini: 6
	}),
	m("past-lives", "Past Lives", 2023, 105, "Celine Song", "USA / Corea", [
		"prime",
		"apple",
		"mubi"
	], "Due amici d'infanzia, ventiquattro anni, una città, una domanda.", {
		romance: 7,
		amore: 7,
		dramma: 6,
		intimo: 8,
		identita: 6,
		malinconico: 6,
		asia: 4,
		moderno: 7
	}),
	m("power-dog", "Il potere del cane", 2021, 126, "Jane Campion", "Nuova Zelanda", ["netflix"], "Un ranch, due fratelli, un silenzio che è una lama.", {
		dramma: 8,
		western: 6,
		oscuro: 6,
		intimo: 6,
		lento: 6,
		identita: 5,
		immagini: 6,
		teso: 4
	}),
	m("roma", "Roma", 2018, 135, "Alfonso Cuarón", "Messico", ["netflix"], "Una domestica, Città del Messico, il 1971 in bianco e nero.", {
		dramma: 8,
		vero: 7,
		famiglia: 6,
		immagini: 8,
		lento: 5,
		identita: 4,
		classico: 3,
		intimo: 6
	}),
	m("pan", "Il labirinto del fauno", 2006, 118, "Guillermo del Toro", "Messico / Spagna", [
		"prime",
		"netflix",
		"now"
	], "Una bambina, un fauno, il fascismo. La fiaba è anche una ferita.", {
		fantasy: 7,
		guerra: 5,
		oscuro: 6,
		identita: 4,
		europa: 5,
		stilizzato: 7,
		famiglia: 3
	}, { originalTitle: "El laberinto del fauno" }),
	m("wild-tales", "Relatos salvajes", 2014, 122, "Damián Szifron", "Argentina", [
		"netflix",
		"prime",
		"mubi"
	], "Sei racconti di vendetta e collasso civile, feroci e comici.", {
		commedia: 6,
		ironico: 8,
		cinico: 6,
		thriller: 4,
		veloce: 5,
		europa: 2,
		vero: 3
	}),
	m("city-of-god", "City of God", 2002, 130, "Fernando Meirelles", "Brasile", [
		"prime",
		"netflix",
		"mubi"
	], "Una favela, due destini, il ritmo di una guerra urbana.", {
		crime: 8,
		dramma: 6,
		veloce: 7,
		vero: 6,
		identita: 4,
		oscuro: 5,
		stilizzato: 5
	}, { originalTitle: "Cidade de Deus" }),
	m("spotlight", "Spotlight", 2015, 129, "Tom McCarthy", "USA", [
		"netflix",
		"prime",
		"now"
	], "Un giornale, una inchiesta, una chiesa. Il mestiere come morale.", {
		dramma: 7,
		vero: 8,
		dialoghi: 7,
		potere: 6,
		complesso: 4,
		hollywood: 5,
		thriller: 3
	}),
	m("big-short", "La grande scommessa", 2015, 130, "Adam McKay", "USA", [
		"prime",
		"netflix",
		"apple"
	], "Il crollo del 2008 spiegato con ironia, rabbia e celebrità.", {
		commedia: 5,
		ironico: 7,
		vero: 7,
		potere: 7,
		biografico: 5,
		dialoghi: 6,
		hollywood: 5
	}),
	m("knives", "Knives Out", 2019, 130, "Rian Johnson", "USA", [
		"prime",
		"netflix",
		"now"
	], "Una villa, un cadavere, un detective con il maglione. Giallo da salotto.", {
		mistero: 8,
		commedia: 6,
		ironico: 6,
		dialoghi: 6,
		hollywood: 6,
		famiglia: 4,
		leggero: 3,
		thriller: 4
	}),
	m("topgun", "Top Gun: Maverick", 2022, 131, "Joseph Kosinski", "USA", [
		"paramount",
		"prime",
		"now"
	], "Un aviatore insegna a volare e a restare. Vertigine analogica.", {
		hollywood: 8,
		azione: 8,
		spettacolo: 8,
		avventura: 5,
		speranza: 4,
		semplice: 4,
		famiglia: 2
	}),
	m("spiderverse", "Spider-Man: Across the Spider-Verse", 2023, 140, "Joaquim Dos Santos et al.", "USA", ["netflix", "prime"], "Miles, infiniti Spider-Man, un'estetica che cambia a ogni scorcio.", {
		animazione: 9,
		azione: 7,
		avventura: 6,
		famiglia: 5,
		stilizzato: 9,
		identita: 5,
		spettacolo: 7,
		hollywood: 6,
		kidsOk: true
	}),
	m("coco", "Coco", 2017, 105, "Lee Unkrich", "USA", ["disney", "prime"], "Un bambino, i morti, la musica, la famiglia come eredità.", {
		animazione: 9,
		famiglia: 8,
		avventura: 5,
		speranza: 6,
		musical: 4,
		identita: 4,
		hollywood: 6,
		kidsOk: true
	}),
	m("inside-out", "Inside Out", 2015, 95, "Pete Docter", "USA", ["disney", "prime"], "Le emozioni in un quartier generale: crescere è anche lasciare andare.", {
		animazione: 9,
		famiglia: 7,
		identita: 6,
		commedia: 4,
		malinconico: 4,
		semplice: 4,
		hollywood: 6,
		breve: 5,
		kidsOk: true
	}),
	m("paddington2", "Paddington 2", 2017, 104, "Paul King", "UK", [
		"prime",
		"netflix",
		"now"
	], "Un orso, un pop-up book, un ladro teatrale. Gentilezza come stile.", {
		commedia: 8,
		famiglia: 8,
		leggero: 8,
		speranza: 7,
		europa: 5,
		semplice: 5,
		breve: 4,
		kidsOk: true
	}),
	m("soul", "Soul", 2020, 100, "Pete Docter", "USA", ["disney"], "Un jazzista muore prima del concerto e deve capire perché vivere.", {
		animazione: 8,
		identita: 7,
		famiglia: 4,
		malinconico: 4,
		speranza: 5,
		hollywood: 5,
		breve: 5,
		kidsOk: true
	}),
	m("sound-metal", "Sound of Metal", 2019, 120, "Darius Marder", "USA", [
		"prime",
		"netflix",
		"apple"
	], "Un batterista perde l'udito. Il silenzio diventa un personaggio.", {
		dramma: 8,
		identita: 7,
		intimo: 7,
		malinconico: 5,
		musical: 3,
		vero: 4,
		hollywood: 4
	}),
	m("father", "The Father", 2020, 97, "Florian Zeller", "UK / Francia", [
		"apple",
		"prime",
		"mubi"
	], "La demenza dal di dentro: stanze che cambiano, volti che mentono.", {
		dramma: 8,
		famiglia: 7,
		complesso: 6,
		intimo: 8,
		malinconico: 6,
		europa: 5,
		breve: 5,
		identita: 5
	}),
	m("marriage", "Storia di un matrimonio", 2019, 137, "Noah Baumbach", "USA", ["netflix"], "Due artisti si separano. New York, avvocati, un figlio in mezzo.", {
		dramma: 8,
		amore: 6,
		dialoghi: 7,
		intimo: 7,
		famiglia: 5,
		vero: 5,
		malinconico: 4
	}, { originalTitle: "Marriage Story" }),
	m("manchester", "Manchester by the Sea", 2016, 137, "Kenneth Lonergan", "USA", [
		"prime",
		"apple",
		"netflix"
	], "Un uomo torna a casa per un funerale e non può perdonarsi.", {
		dramma: 9,
		malinconico: 8,
		famiglia: 6,
		intimo: 7,
		vero: 6,
		lento: 4,
		hollywood: 4
	}),
	m("there-blood", "Il petroliere", 2007, 158, "Paul Thomas Anderson", "USA", [
		"paramount",
		"prime",
		"now"
	], "Petrolio, un predicatore, un uomo che non può fermarsi.", {
		dramma: 8,
		identita: 6,
		potere: 7,
		oscuro: 6,
		lungo: 7,
		complesso: 6,
		classico: 3,
		hollywood: 5
	}, { originalTitle: "There Will Be Blood" }),
	m("phantom", "Il filo nascosto", 2017, 130, "Paul Thomas Anderson", "USA", [
		"prime",
		"apple",
		"mubi"
	], "Londra anni 50, sartoria, spionaggio, un amore che non può dirsi.", {
		dramma: 6,
		romance: 5,
		thriller: 4,
		stilizzato: 7,
		intimo: 6,
		amore: 5,
		lento: 4,
		identita: 4
	}, { originalTitle: "Phantom Thread" }),
	m("bohemian-not", "Amour", 2012, 127, "Michael Haneke", "Francia / Austria", ["mubi", "prime"], "Una coppia anziana, un ictus, la cura come ultima prova d'amore.", {
		europa: 8,
		dramma: 9,
		amore: 7,
		intimo: 8,
		lento: 6,
		malinconico: 7,
		famiglia: 4,
		complesso: 4
	}),
	m("piano", "The Piano", 1993, 121, "Jane Campion", "Nuova Zelanda", ["prime", "mubi"], "Una muta, un piano, una costa. Il desiderio come lingua.", {
		dramma: 7,
		romance: 6,
		immagini: 7,
		identita: 5,
		amore: 6,
		classico: 4,
		lento: 4
	}),
	m("casablanca", "Casablanca", 1942, 102, "Michael Curtiz", "USA", ["prime", "now"], "Un locale, una lettera di transito, l'amore che cede alla storia.", {
		classico: 9,
		romance: 7,
		amore: 7,
		dramma: 6,
		hollywood: 7,
		guerra: 4,
		dialoghi: 7,
		breve: 5
	}),
	m("vertigo", "La donna che visse due volte", 1958, 128, "Alfred Hitchcock", "USA", [
		"prime",
		"mubi",
		"now"
	], "Acrofobia, un ritratto, una donna che è già un'altra.", {
		classico: 9,
		thriller: 8,
		mistero: 7,
		romance: 4,
		stilizzato: 7,
		hollywood: 6,
		identita: 5
	}, { originalTitle: "Vertigo" }),
	m("rear-window", "La finestra sul cortile", 1954, 112, "Alfred Hitchcock", "USA", ["prime", "now"], "Un fotografo gessato guarda i vicini e vede, forse, un omicidio.", {
		classico: 9,
		thriller: 8,
		mistero: 7,
		intimo: 5,
		hollywood: 6,
		dialoghi: 4,
		breve: 3
	}),
	m("psycho", "Psyco", 1960, 109, "Alfred Hitchcock", "USA", [
		"prime",
		"now",
		"paramount"
	], "Un motel, una doccia, una madre. Il genere cambia a metà.", {
		classico: 8,
		thriller: 8,
		horror: 6,
		teso: 7,
		mistero: 6,
		hollywood: 6,
		breve: 4
	}),
	m("2001", "2001: Odissea nello spazio", 1968, 149, "Stanley Kubrick", "UK / USA", ["prime", "now"], "Una scimmia, un monolite, un computer, un feto tra le stelle.", {
		scifi: 9,
		classico: 8,
		complesso: 9,
		immagini: 9,
		lento: 8,
		spettacolo: 6,
		identita: 5,
		lungo: 6
	}),
	m("shining", "Shining", 1980, 144, "Stanley Kubrick", "UK / USA", ["prime", "now"], "Un hotel, l'inverno, un uomo che scrive sempre la stessa riga.", {
		horror: 8,
		oscuro: 8,
		stilizzato: 8,
		teso: 7,
		famiglia: 4,
		classico: 6,
		lento: 4,
		immagini: 6
	}),
	m("silence-lambs", "Il silenzio degli innocenti", 1991, 118, "Jonathan Demme", "USA", [
		"prime",
		"now",
		"paramount"
	], "Una recluta, un mostro in cella, un altro mostro in libertà.", {
		thriller: 8,
		horror: 5,
		teso: 8,
		identita: 4,
		hollywood: 6,
		mistero: 5,
		oscuro: 5
	}),
	m("good-bad", "Il buono, il brutto, il cattivo", 1966, 178, "Sergio Leone", "Italia", [
		"raiplay",
		"prime",
		"mubi"
	], "Tre uomini, una tomba, Ennio Morricone, il deserto come palcoscenico.", {
		italiano: 7,
		western: 9,
		classico: 8,
		avventura: 6,
		spettacolo: 6,
		ironico: 4,
		lungo: 8,
		immagini: 7
	}),
	m("once-west", "C'era una volta il West", 1968, 165, "Sergio Leone", "Italia", [
		"raiplay",
		"prime",
		"mubi"
	], "Una stazione, un'armonica, il tempo che si allunga fino al mito.", {
		italiano: 7,
		western: 9,
		classico: 8,
		lento: 7,
		immagini: 8,
		malinconico: 5,
		lungo: 7,
		spettacolo: 5
	}),
	m("taxi-driver", "Taxi Driver", 1976, 114, "Martin Scorsese", "USA", [
		"prime",
		"netflix",
		"now"
	], "Un reduce, una città, una voce fuori campo. La solitudine come arma.", {
		hollywood: 7,
		dramma: 7,
		oscuro: 8,
		identita: 7,
		cinico: 6,
		classico: 6,
		intimo: 5,
		crime: 4
	}),
	m("apocalypse", "Apocalypse Now", 1979, 153, "Francis Ford Coppola", "USA", ["prime", "now"], "Risalire un fiume per uccidere un colonnello che è già una divinità.", {
		guerra: 9,
		oscuro: 8,
		complesso: 7,
		spettacolo: 6,
		immagini: 8,
		classico: 7,
		lungo: 7,
		identita: 5
	}),
	m("children-men", "I figli degli uomini", 2006, 109, "Alfonso Cuarón", "UK / USA", ["prime", "netflix"], "Nessun bambino nasce più. Un burocrate deve scortare una speranza.", {
		scifi: 7,
		thriller: 6,
		guerra: 4,
		speranza: 5,
		teso: 7,
		stilizzato: 6,
		europa: 4,
		oscuro: 5
	}),
	m("drive", "Drive", 2011, 100, "Nicolas Winding Refn", "USA", [
		"prime",
		"netflix",
		"mubi"
	], "Un stuntman, una giacca scorpione, silenzi e scoppi.", {
		crime: 6,
		azione: 5,
		stilizzato: 8,
		lento: 5,
		intimo: 4,
		oscuro: 5,
		romance: 3,
		breve: 5,
		europa: 3
	}),
	m("nightcrawler", "Nightcrawler", 2014, 117, "Dan Gilroy", "USA", [
		"prime",
		"netflix",
		"now"
	], "Un uomo filma le disgrazie notturne e sale. Los Angeles come preda.", {
		thriller: 7,
		cinico: 8,
		crime: 5,
		identita: 5,
		teso: 6,
		vero: 4,
		hollywood: 5
	}),
	m("sicario", "Sicario", 2015, 121, "Denis Villeneuve", "USA", [
		"prime",
		"netflix",
		"now"
	], "Una agente FBI sul confine. La legge è già un'altra cosa.", {
		thriller: 8,
		crime: 7,
		teso: 8,
		oscuro: 6,
		potere: 5,
		immagini: 6,
		hollywood: 5
	}),
	m("prisoners", "Prisoners", 2013, 153, "Denis Villeneuve", "USA", [
		"prime",
		"netflix",
		"apple"
	], "Due bambine sparite, un padre che non aspetta la polizia.", {
		thriller: 8,
		dramma: 6,
		teso: 8,
		famiglia: 5,
		oscuro: 6,
		mistero: 6,
		lungo: 5,
		hollywood: 5
	}),
	m("knives2", "Glass Onion", 2022, 139, "Rian Johnson", "USA", ["netflix"], "Un'isola, un miliardario, un detective, un giallo da villa tech.", {
		mistero: 7,
		commedia: 6,
		ironico: 6,
		hollywood: 6,
		dialoghi: 5,
		leggero: 4,
		moderno: 5
	}),
	m("jojo", "Jojo Rabbit", 2019, 108, "Taika Waititi", "USA / Nuova Zelanda", [
		"disney",
		"prime",
		"now"
	], "Un bambino nazista ha Hitler come amico immaginario. Poi arriva il mondo.", {
		commedia: 6,
		guerra: 5,
		ironico: 7,
		famiglia: 5,
		speranza: 4,
		identita: 4,
		breve: 4,
		kidsOk: true
	}),
	m("hunt-wilder", "Hunt for the Wilderpeople", 2016, 101, "Taika Waititi", "Nuova Zelanda", [
		"prime",
		"netflix",
		"apple"
	], "Un ragazzino e uno zio burbero fuggono nel bush. Tenerezza goffa.", {
		commedia: 7,
		avventura: 6,
		famiglia: 6,
		leggero: 6,
		speranza: 5,
		identita: 3,
		breve: 5,
		kidsOk: true
	}, { originalTitle: "Hunt for the Wilderpeople" }),
	m("what-we", "What We Do in the Shadows", 2014, 86, "Jemaine Clement, Taika Waititi", "Nuova Zelanda", [
		"prime",
		"netflix",
		"mubi"
	], "Coinquilini vampiri a Wellington, mockumentary, denti e faccende.", {
		commedia: 8,
		ironico: 8,
		horror: 3,
		leggero: 6,
		breve: 8,
		strano: 5,
		europa: 2
	}),
	m("shaun", "L'alba dei morti dementi", 2004, 99, "Edgar Wright", "UK", [
		"prime",
		"netflix",
		"now"
	], "Un commesso pigro, zombie, pub. L'apocalisse come scusa per crescere.", {
		commedia: 8,
		horror: 4,
		ironico: 7,
		veloce: 6,
		europa: 5,
		breve: 6,
		identita: 3
	}, { originalTitle: "Shaun of the Dead" }),
	m("hot-fuzz", "Hot Fuzz", 2007, 121, "Edgar Wright", "UK", [
		"prime",
		"netflix",
		"now"
	], "Un poliziotto di Londra in un paesino troppo tranquillo.", {
		commedia: 8,
		azione: 5,
		ironico: 7,
		mistero: 4,
		veloce: 6,
		europa: 5,
		thriller: 3
	}),
	m("the-menu", "The Menu", 2022, 107, "Mark Mylod", "USA", [
		"disney",
		"prime",
		"now"
	], "Un ristorante impossibile, un cuoco messia, una cena che è una trappola.", {
		thriller: 6,
		ironico: 7,
		cinico: 6,
		commedia: 4,
		teso: 5,
		hollywood: 5,
		breve: 4,
		potere: 4
	}),
	m("nomadland", "Nomadland", 2020, 107, "Chloé Zhao", "USA", [
		"disney",
		"prime",
		"now"
	], "Una donna perde la casa e vive in un furgone, tra deserti e stagioni.", {
		dramma: 8,
		vero: 7,
		lento: 6,
		identita: 6,
		malinconico: 6,
		immagini: 6,
		intimo: 6,
		avventura: 3
	}),
	m("minari", "Minari", 2020, 115, "Lee Isaac Chung", "USA", [
		"prime",
		"apple",
		"mubi"
	], "Una famiglia coreano-americana pianta radici in Arkansas. Fragile, vivo.", {
		dramma: 7,
		famiglia: 8,
		identita: 6,
		vero: 6,
		intimo: 6,
		speranza: 4,
		asia: 3,
		malinconico: 3
	})
];
var AXIS_LABEL = {
	azione: "azione",
	commedia: "commedia",
	dramma: "dramma",
	thriller: "thriller",
	horror: "horror",
	scifi: "fantascienza",
	romance: "romanticismo",
	crime: "crime",
	fantasy: "fantasy",
	animazione: "animazione",
	documentario: "documentario",
	avventura: "avventura",
	guerra: "guerra",
	mistero: "mistero",
	biografico: "biografico",
	western: "western",
	musical: "musical",
	leggero: "leggerezza",
	oscuro: "tono scuro",
	teso: "tensione",
	malinconico: "malinconia",
	sollevante: "sollevamento",
	strano: "stranezza",
	ironico: "ironia",
	lento: "ritmo lento",
	veloce: "ritmo veloce",
	semplice: "chiarezza",
	complesso: "complessità",
	intimo: "intimità",
	spettacolo: "spettacolo",
	stilizzato: "stile",
	dialoghi: "dialoghi",
	immagini: "immagini",
	classico: "classici",
	moderno: "contemporaneo",
	italiano: "cinema italiano",
	hollywood: "Hollywood",
	europa: "Europa",
	asia: "Asia",
	speranza: "speranza",
	cinico: "disincanto",
	vero: "storie vere",
	famiglia: "famiglia",
	amore: "amore",
	potere: "potere",
	identita: "identità",
	breve: "durata breve",
	lungo: "durata lunga"
};
function emptyVector() {
	return Object.fromEntries(AXES.map((a) => [a, 0]));
}
function buildProfile(answers, subscribed = []) {
	const vector = emptyVector();
	const flags = {
		platforms: [],
		avoid: [],
		require: []
	};
	let answered = 0;
	for (const question of QUESTIONS) {
		const picked = answers[question.id];
		if (!picked?.length) continue;
		answered += 1;
		const chapterBoost = question.ch === 1 ? 2.3 : question.ch === 10 ? 1.4 : 1;
		const share = 1 / picked.length;
		for (const optId of picked) {
			const opt = question.opts.find((o) => o.id === optId);
			if (!opt) continue;
			for (const [axis, value] of Object.entries(opt.w)) vector[axis] += value * chapterBoost * share;
			const f = opt.f;
			if (!f) continue;
			if (f.maxMinutes != null) flags.maxMinutes = flags.maxMinutes ? Math.min(flags.maxMinutes, f.maxMinutes) : f.maxMinutes;
			if (f.minMinutes != null) flags.minMinutes = flags.minMinutes ? Math.max(flags.minMinutes, f.minMinutes) : f.minMinutes;
			if (f.minYear != null) flags.minYear = flags.minYear ? Math.max(flags.minYear, f.minYear) : f.minYear;
			if (f.maxYear != null) flags.maxYear = flags.maxYear ? Math.min(flags.maxYear, f.maxYear) : f.maxYear;
			if (f.platforms) flags.platforms = [.../* @__PURE__ */ new Set([...flags.platforms ?? [], ...f.platforms])];
			if (f.avoid) flags.avoid = [.../* @__PURE__ */ new Set([...flags.avoid ?? [], ...f.avoid])];
			if (f.require) flags.require = [.../* @__PURE__ */ new Set([...flags.require ?? [], ...f.require])];
			if (f.company) flags.company = f.company;
			if (f.dubbed) flags.dubbed = true;
			if (f.kidsOk) flags.kidsOk = true;
		}
	}
	if (subscribed.length) flags.platforms = [.../* @__PURE__ */ new Set([...subscribed, ...flags.platforms ?? []])];
	return {
		vector,
		flags,
		answered
	};
}
function topAxes(vector, n = 6) {
	return AXES.map((axis) => ({
		axis,
		value: vector[axis]
	})).filter((x) => x.value > .8).sort((a, b) => b.value - a.value).slice(0, n);
}
function pickArchetype(vector) {
	const packs = [
		{
			name: "Compagnia sul divano",
			line: "Vuoi uscire meglio di come sei entrato.",
			axes: [
				"commedia",
				"leggero",
				"semplice",
				"sollevante",
				"breve"
			]
		},
		{
			name: "Spettatore d'impatto",
			line: "Scala grande, corpo in sala, mestiere visibile.",
			axes: [
				"azione",
				"spettacolo",
				"veloce",
				"hollywood",
				"avventura"
			]
		},
		{
			name: "Volontario al buio",
			line: "Cerchi il nervo scoperto, non il rumore.",
			axes: [
				"horror",
				"teso",
				"oscuro",
				"thriller"
			]
		},
		{
			name: "Cinefilo notturno",
			line: "Tempi lunghi, silenzi, e un dopo-film da metabolizzare.",
			axes: [
				"lento",
				"malinconico",
				"intimo",
				"complesso",
				"immagini"
			]
		},
		{
			name: "Architetto di mondi",
			line: "Idee che restano dopo i titoli di coda.",
			axes: [
				"scifi",
				"complesso",
				"fantasy",
				"spettacolo"
			]
		},
		{
			name: "Sentimentale lucido",
			line: "L'amore sì, lo sciroppo no.",
			axes: [
				"romance",
				"amore",
				"intimo",
				"malinconico"
			]
		},
		{
			name: "Realista da sala",
			line: "Storie italiane, volti, niente smalto da export.",
			axes: [
				"italiano",
				"dramma",
				"vero",
				"crime"
			]
		},
		{
			name: "Cartografo",
			line: "Il sottotitolo non è un ostacolo, è un passaporto.",
			axes: [
				"asia",
				"europa",
				"stilizzato",
				"complesso"
			]
		},
		{
			name: "Cronista del sottobosco",
			line: "Potere, lealtà, e il conto che arriva sempre.",
			axes: [
				"crime",
				"cinico",
				"potere",
				"thriller",
				"oscuro"
			]
		},
		{
			name: "Fiaba adulta",
			line: "Disegno, meraviglia, e un fondo che i bambini non vedono.",
			axes: [
				"animazione",
				"famiglia",
				"fantasy",
				"speranza"
			]
		},
		{
			name: "Custode della pellicola",
			line: "Il nuovo va bene, ma il mestiere vecchio tiene ancora.",
			axes: [
				"classico",
				"hollywood",
				"italiano"
			]
		},
		{
			name: "Fuori registro",
			line: "Vuoi uscire dalla corsia, non solo cambiare canale.",
			axes: [
				"strano",
				"stilizzato",
				"ironico",
				"complesso"
			]
		}
	];
	let best = packs[packs.length - 1];
	let bestScore = -1;
	for (const pack of packs) {
		const score = pack.axes.reduce((n, axis) => n + (vector[axis] ?? 0), 0);
		if (score > bestScore) {
			best = pack;
			bestScore = score;
		}
	}
	if (bestScore < 6) return {
		name: "Spettatore onnivoro",
		line: "Niente etichetta stretta: stasera conta che sia vivo."
	};
	return {
		name: best.name,
		line: best.line
	};
}
function cosine(a, b) {
	let dot = 0;
	let na = 0;
	let nb = 0;
	for (const axis of AXES) {
		const av = a[axis];
		const bv = b[axis] ?? 0;
		dot += av * bv;
		na += av * av;
		nb += bv * bv;
	}
	if (na === 0 || nb === 0) return 0;
	return dot / (Math.sqrt(na) * Math.sqrt(nb));
}
function reasonsFor(movie, profile) {
	const shared = topAxes(profile.vector, 8).filter((t) => (movie.v[t.axis] ?? 0) >= 5).slice(0, 3).map((t) => AXIS_LABEL[t.axis]);
	const out = [];
	if (shared.length) out.push(`Affine per ${shared.join(", ")}`);
	if (profile.flags.maxMinutes && movie.runtime <= profile.flags.maxMinutes) out.push(`Sta nel tempo che hai (${movie.runtime} min)`);
	if (profile.flags.company === "famiglia" && movie.kidsOk) out.push("Adatto a una serata in famiglia");
	const owned = profile.flags.platforms ?? [];
	const on = movie.platforms.filter((p) => owned.includes(p));
	if (on.length) out.push(`Priorità su ${on.map((p) => PLATFORM_META[p].label).join(", ")}`);
	return out.slice(0, 3);
}
function rankMovies(profile) {
	const { vector, flags } = profile;
	const owned = new Set(flags.platforms ?? []);
	return MOVIES.map((movie) => {
		let score = cosine(vector, movie.v) * 100;
		if (flags.maxMinutes && movie.runtime > flags.maxMinutes + 8) score *= .42;
		if (flags.minMinutes && movie.runtime < flags.minMinutes - 10) score *= .75;
		if (flags.minYear && movie.year < flags.minYear) score *= .55;
		if (flags.maxYear && movie.year > flags.maxYear) score *= .55;
		if (flags.kidsOk && flags.company === "famiglia" && !movie.kidsOk) score *= .25;
		if (flags.company === "famiglia" && (movie.v.horror ?? 0) > 5) score *= .2;
		if (flags.avoid) {
			for (const axis of flags.avoid) if ((movie.v[axis] ?? 0) >= 6) score *= .28;
		}
		if (flags.require) {
			for (const axis of flags.require) if ((movie.v[axis] ?? 0) < 5) score *= .5;
		}
		const overlap = owned.size ? movie.platforms.filter((p) => owned.has(p)) : movie.platforms.slice(0, 3);
		if (owned.size && overlap.length) score *= 1.28 + overlap.length * .06;
		if (owned.size && overlap.length === 0) score *= .68;
		return {
			movie,
			score,
			reasons: reasonsFor(movie, profile),
			overlap
		};
	}).filter((m) => m.movie.runtime > 40).sort((a, b) => b.score - a.score);
}
function searchRecipes(profile, matches) {
	const axes = topAxes(profile.vector, 5).map((t) => AXIS_LABEL[t.axis]);
	const first = matches[0]?.movie;
	const q1 = axes.slice(0, 3).join(" ");
	const q2 = first ? `${first.title} ${first.year} streaming` : "film da vedere stasera";
	const q3 = [
		profile.flags.company === "famiglia" ? "film famiglia" : "film",
		axes[0] ?? "da vedere",
		"streaming Italia"
	].join(" ");
	const make = (label, query) => ({
		label,
		query,
		justwatch: `https://www.justwatch.com/it/cerca?q=${encodeURIComponent(query)}`,
		google: `https://www.google.com/search?q=${encodeURIComponent(`${query} dove vederlo streaming`)}`
	});
	return [
		make("Ricerca su misura", q1 || "film streaming"),
		make("Il titolo di stasera", q2),
		make("Sulle tue piattaforme", q3)
	];
}
function movieSearchLinks(movie, platforms) {
	const q = movie.originalTitle ? `${movie.title} ${movie.originalTitle}` : movie.title;
	return {
		justwatch: `https://www.justwatch.com/it/cerca?q=${encodeURIComponent(movie.title)}`,
		google: `https://www.google.com/search?q=${encodeURIComponent(`${movie.title} ${movie.year} streaming Italia`)}`,
		platformLinks: (platforms.length ? platforms : movie.platforms).map((p) => ({
			id: p,
			label: PLATFORM_META[p].label,
			href: PLATFORM_META[p].search(q)
		}))
	};
}
function AdSlot({ format, className }) {
	const consent = useAds((s) => s.consent);
	const live = adsReady() && consent === "all";
	const slot = ADS_CONFIG.slots[format];
	const pushed = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!live || !slot || pushed.current) return;
		try {
			(window.adsbygoogle = window.adsbygoogle || []).push({});
			pushed.current = true;
		} catch {}
	}, [live, slot]);
	if (consent === "none") return null;
	const tall = format === "feed";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		"aria-label": "Pubblicità",
		className: cn("overflow-hidden rounded-md border border-border bg-raised", tall ? "min-h-40" : "min-h-20", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "border-b border-border px-3 py-1.5 text-xs tracking-[0.16em] text-subtle uppercase",
			children: "Pubblicità"
		}), live && slot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ins", {
			className: cn("adsbygoogle block w-full", tall ? "min-h-72" : "min-h-24"),
			"data-ad-client": ADS_CONFIG.client,
			"data-ad-slot": slot,
			"data-ad-format": "auto",
			"data-full-width-responsive": "true"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
			tall,
			waitingConsent: consent !== "all"
		})]
	});
}
function Preview({ tall, waitingConsent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-col items-center justify-center gap-1 px-4 text-center", tall ? "min-h-36 py-8" : "min-h-16 py-4"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: waitingConsent ? "Lo spazio si attiva se accetti gli annunci." : "Anteprima. Qui comparirà un annuncio AdSense dell'editore."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-subtle",
			children: "Non è un inserzionista reale."
		})]
	});
}
function Results() {
	const answers = useQuiz((s) => s.answers);
	const platforms = useQuiz((s) => s.platforms);
	const reset = useQuiz((s) => s.reset);
	const goTo = useQuiz((s) => s.goTo);
	const editPlatforms = useQuiz((s) => s.editPlatforms);
	const profile = buildProfile(answers, platforms);
	const matches = rankMovies(profile).slice(0, 8);
	const tonight = matches[0];
	const archetype = pickArchetype(profile.vector);
	const axes = topAxes(profile.vector, 6);
	const maxAxis = axes[0]?.value || 1;
	const recipes = searchRecipes(profile, matches);
	const owned = platforms.length ? platforms : profile.flags.platforms ?? [];
	const platformLine = owned.length > 0 ? owned.map((p) => PLATFORM_META[p].label).join(" · ") : "Nessun abbonamento indicato";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "mx-auto max-w-3xl px-5 py-10 sm:px-8 sm:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise-in",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium tracking-[0.22em] text-muted uppercase",
						children: [
							"Profilo · ",
							profile.answered,
							" risposte"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-display text-4xl italic leading-[1.1] text-fg md:text-[2.9rem]",
						children: archetype.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-base text-muted",
						children: archetype.line
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rise-in rise-in-delay-1 mt-8 rounded-lg border border-border bg-surface p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xs font-medium tracking-[0.18em] text-subtle uppercase",
							children: "Le tue piattaforme"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-fg",
							children: platformLine
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-subtle",
							children: "I titoli sulle librerie che hai segnato salgono in classifica."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						size: "sm",
						className: "min-h-11",
						onClick: editPlatforms,
						children: "Modifica"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in rise-in-delay-1 mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium tracking-[0.18em] text-subtle uppercase",
					children: "Coordinate"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3",
					children: axes.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid grid-cols-[8.5rem_1fr] items-center gap-3 sm:grid-cols-[10rem_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: AXIS_LABEL[a.axis]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "h-1.5 overflow-hidden rounded-full bg-raised",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block h-full rounded-full bg-accent",
								style: { width: `${Math.max(8, a.value / maxAxis * 100)}%` }
							})
						})]
					}, a.axis))
				})]
			}),
			tonight ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in rise-in-delay-2 mt-12 rounded-xl border border-border bg-surface p-6 sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.18em] text-subtle uppercase",
						children: "Stasera"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-2xl italic leading-tight text-fg sm:text-3xl",
						children: tonight.movie.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, { movie: tonight.movie }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-sm leading-relaxed text-muted",
						children: tonight.movie.synopsis
					}),
					tonight.reasons.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-wrap gap-2",
						children: tonight.reasons.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-full border border-border px-3 py-1 text-xs text-muted",
							children: r
						}, r))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchRow, {
						movie: tonight.movie,
						platforms: tonight.overlap.length ? tonight.overlap : owned
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-muted",
				children: "Rispondi ad almeno qualche domanda per avere una proposta."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, {
				format: "feed",
				className: "mt-10"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium tracking-[0.18em] text-subtle uppercase",
					children: "Altre otto, quasi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 divide-y divide-border border-y border-border",
					children: matches.slice(1).map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "py-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-display text-xl italic text-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mr-3 font-mono text-xs not-italic text-subtle",
										children: i + 2
									}), m.movie.title]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 font-mono text-xs tabular-nums text-subtle",
									children: m.movie.year
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, { movie: m.movie }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: m.movie.synopsis
							}),
							m.reasons[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-subtle",
								children: m.reasons[0]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchRow, {
								movie: m.movie,
								platforms: m.overlap,
								compact: true
							})
						]
					}, m.movie.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12 rounded-lg border border-border bg-surface p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							className: "size-4 text-accent",
							strokeWidth: 1.6
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl italic",
							children: "Cerca sulle piattaforme"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "I cataloghi si muovono. Queste ricerche aprono JustWatch Italia o Google con la query giusta per il tuo profilo."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 space-y-4",
						children: recipes.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-fg",
								children: r.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-subtle",
								children: r.query
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
									href: r.justwatch,
									children: "JustWatch"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
									href: r.google,
									children: "Google"
								})]
							})
						] }, r.label))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-12 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => goTo(0),
					className: "min-h-12",
					children: "Rifinisci le risposte"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					onClick: reset,
					className: "min-h-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Ricomincia"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalFooter, {})
		]
	});
}
function Meta({ movie }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-2 text-sm text-subtle",
		children: [
			movie.director,
			" · ",
			movie.year,
			" · ",
			movie.runtime,
			" min · ",
			movie.country,
			movie.originalTitle && movie.originalTitle !== movie.title ? ` · ${movie.originalTitle}` : ""
		]
	});
}
function SearchRow({ movie, platforms, compact }) {
	const links = movieSearchLinks(movie, platforms);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: compact ? "mt-3 flex flex-wrap gap-2" : "mt-6 flex flex-wrap gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
				href: links.justwatch,
				children: "Dove vederlo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
				href: links.google,
				children: "Cerca in rete"
			}),
			links.platformLinks.slice(0, compact ? 2 : 4).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
				href: p.href,
				children: p.label
			}, p.id))
		]
	});
}
function OutLink({ href, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href,
		target: "_blank",
		rel: "noreferrer",
		className: "inline-flex min-h-10 items-center gap-1 rounded-sm border border-border-strong bg-raised px-3 text-xs font-medium text-fg transition-colors duration-150 hover:border-accent",
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-3.5 text-muted" })]
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const phase = useQuiz((s) => s.phase);
	(0, import_react.useEffect)(() => {
		const unsub = useQuiz.persist.onFinishHydration(() => setReady(true));
		if (useQuiz.persist.hasHydrated()) setReady(true);
		return unsub;
	}, []);
	if (!ready || phase === "intro") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Intro, {});
	if (phase === "platforms") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Platforms, {});
	if (phase === "quiz") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizView, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {});
}
//#endregion
export { Home as component };
