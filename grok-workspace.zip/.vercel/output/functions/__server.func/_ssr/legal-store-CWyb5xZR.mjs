import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/legal-store-CWyb5xZR.js
var useLegal = create()(persist((set) => ({
	ageOk: false,
	confirmAge: () => set({ ageOk: true })
}), { name: "platea-legal" }));
function wipeLocalData() {
	try {
		localStorage.removeItem("platea-quiz");
		localStorage.removeItem("platea-ads");
		localStorage.removeItem("platea-legal");
	} catch {}
	location.assign("/");
}
//#endregion
export { wipeLocalData as n, useLegal as t };
