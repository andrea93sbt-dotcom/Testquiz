import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ImageDown, c as ArrowUpRight, n as Share2, o as Copy, r as RotateCcw, s as Check } from "../_libs/lucide-react.mjs";
import { C as questionsFor, E as useAds, _ as CATALOG_SIZE, d as unlockAudio, f as useQuiz, g as PLATFORM_META, h as PLATFORMS, i as LEGAL, o as Button, p as optionIdsForPlatforms, s as cn, u as blip, w as useLegal, x as pickSeenTrios, y as movieById } from "./router-DEhEfwv_.mjs";
import { t as LegalFooter } from "./legal-footer-V7DmZbK1.mjs";
import { i as shareResult, r as drawSharePng, t as copyShareUrl } from "./share-Bk2LE1Z7.mjs";
import { a as Plot, c as Trailer, d as pickArchetype, f as rankMovies, g as youtubeSearchUrl, h as useFilmMeta, i as Availability, l as buildProfile, m as topAxes, n as AdSlot, o as Poster, p as searchRecipes, r as AppBar, s as Tags, t as AXIS_LABEL, u as movieSearchLinks } from "./film-card-BRhH8_dR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-62S5I-Mc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Intro() {
	const start = useQuiz((s) => s.start);
	const startShort = useQuiz((s) => s.startShort);
	const startSeen = useQuiz((s) => s.startSeen);
	const answers = useQuiz((s) => s.answers);
	const platforms = useQuiz((s) => s.platforms);
	const resume = useQuiz((s) => s.resume);
	const ageOk = useLegal((s) => s.ageOk);
	const setAge = useLegal((s) => s.setAge);
	const consent = useAds((s) => s.consent);
	const seenTrios = useQuiz((s) => s.seenTrios);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const hasProgress = Object.keys(answers).length > 0 || seenTrios.length > 0;
	const platformLine = platforms.length > 0 ? platforms.map((p) => PLATFORM_META[p].label).join(" · ") : null;
	const canPlay = hydrated && ageOk && consent === "all";
	(0, import_react.useEffect)(() => {
		const done = () => {
			if (useLegal.persist.hasHydrated() && useAds.persist.hasHydrated()) setHydrated(true);
		};
		const a = useLegal.persist.onFinishHydration(done);
		const b = useAds.persist.onFinishHydration(done);
		done();
		return () => {
			a();
			b();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh overflow-hidden bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-0 opacity-40",
			style: {
				backgroundImage: "url(/sprites/sky.jpg)",
				backgroundSize: "cover",
				backgroundPosition: "center"
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			id: "contenuto",
			className: "relative z-10 mx-auto flex min-h-dvh max-w-xl flex-col px-5 py-10 sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "rise-in rounded-md border border-border bg-surface/95 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-[0.22em] text-ticket uppercase",
							children: "Platea"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 font-display text-4xl italic leading-tight text-fg sm:text-5xl",
							children: "Cosa vedi stasera?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-base leading-relaxed text-muted",
							children: "Rispondi a qualche domanda e ti consiglio un film. Tre modi: uno veloce, uno preciso, oppure a partire dai film che hai già visto."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 max-w-md text-base leading-relaxed text-muted",
							children: [
								"Nel catalogo ci sono ",
								CATALOG_SIZE.toLocaleString("it-IT"),
								" film. Se esiste il titolo italiano, usiamo quello."
							]
						}),
						platformLine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-fg",
							children: platformLine
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 flex flex-col gap-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-3 text-sm leading-relaxed text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1 size-4 shrink-0 accent-accent",
								checked: hydrated && ageOk,
								onChange: (e) => setAge(e.target.checked)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Ho almeno ",
								LEGAL.ageMin,
								" anni."
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "lg",
									disabled: !canPlay,
									className: "min-h-14 w-full",
									onClick: () => {
										unlockAudio();
										blip("start");
										startShort();
									},
									children: "Quiz breve · 20 domande"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "-mt-1 text-sm text-subtle",
									children: "Cinque minuti. Basta per un consiglio."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									size: "lg",
									disabled: !canPlay,
									className: "min-h-14 w-full",
									onClick: () => {
										unlockAudio();
										blip("start");
										start();
									},
									children: "Quiz completo · 100 domande"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "-mt-1 text-sm text-subtle",
									children: "Più lungo, più preciso."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									size: "lg",
									disabled: !canPlay,
									className: "min-h-14 w-full",
									onClick: () => {
										unlockAudio();
										blip("start");
										startSeen();
									},
									children: "Film che hai già visto"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "-mt-1 text-sm text-subtle",
									children: "Dieci volte, tre titoli. TV se ti è piaciuto, tavolo se non l'hai visto, cestino se non ti è piaciuto."
								}),
								hasProgress ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "lg",
									className: "min-h-12 w-full",
									disabled: !canPlay,
									onClick: () => resume(),
									children: "Continua da dove ti eri fermato"
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-subtle",
							children: "Al computer: frecce o WASD. Al telefono: tocca la risposta, oppure scorri verso una sala."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, { format: "banner" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-auto pt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalFooter, {})
				})
			]
		})]
	});
}
function PlatformPicker({ selected, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid grid-cols-1 gap-2 sm:grid-cols-2",
		children: PLATFORMS.map((id) => {
			const on = selected.includes(id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": on,
				onClick: () => {
					unlockAudio();
					blip(on ? "skip" : "ok");
					onToggle(id);
				},
				className: cn("flex min-h-14 w-full items-center justify-between gap-3 pixel-chip px-4 py-3 text-left transition-transform duration-150 ease-out", "hover:border-border-strong active:scale-[0.99]", on ? "border-accent bg-raised" : "border-border bg-surface"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[0.95rem] text-fg",
					children: PLATFORM_META[id].label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("text-xs", on ? "text-accent" : "text-subtle"),
					children: on ? "Sì" : ""
				})]
			}) }, id);
		})
	});
}
function Platforms() {
	const selected = useQuiz((s) => s.platforms);
	const togglePlatform = useQuiz((s) => s.togglePlatform);
	const confirmPlatforms = useQuiz((s) => s.confirmPlatforms);
	const platformsReturn = useQuiz((s) => s.platformsReturn);
	const count = selected.length;
	const summary = count === 0 ? "Nessuna selezionata" : count === 1 ? PLATFORM_META[selected[0]].label : `${count} piattaforme`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "mx-auto flex min-h-dvh max-w-2xl flex-col px-4 py-6 sm:px-8 sm:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.22em] text-ticket uppercase",
					children: "Piattaforme"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-3xl italic leading-tight text-fg md:text-4xl",
					children: "Su quali piattaforme sei abbonato?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-lg text-base leading-relaxed text-muted",
					children: "Segna quelle che hai. Così i film da cercare lì salgono in lista. I cataloghi cambiano: non è una garanzia, è solo un aiuto."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformPicker, {
					selected,
					onToggle: togglePlatform
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-subtle",
					children: [summary, ". Puoi anche saltare."]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-8 flex flex-col gap-2 border-t border-border pt-5 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: confirmPlatforms,
					className: "min-h-14 w-full sm:w-auto",
					children: count > 0 ? "Continua" : "Salta"
				}), platformsReturn === "results" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "self-center text-xs text-subtle",
					children: "Poi torni alla lista, con l'ordine aggiornato."
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalFooter, {})
		]
	});
}
var CHAPTERS = [
	{
		id: 1,
		title: "Stasera",
		subtitle: "Quanto tempo hai, con chi sei"
	},
	{
		id: 2,
		title: "Che tipo di film",
		subtitle: "Azione, commedia, horror…"
	},
	{
		id: 3,
		title: "Che umore",
		subtitle: "Leggero o pesante"
	},
	{
		id: 4,
		title: "I personaggi",
		subtitle: "Chi vuoi seguire"
	},
	{
		id: 5,
		title: "Dove è ambientato",
		subtitle: "Città, spazio, Italia…"
	},
	{
		id: 6,
		title: "Come è fatto",
		subtitle: "Ritmo, durata, stile"
	},
	{
		id: 7,
		title: "Di cosa parla",
		subtitle: "I temi"
	},
	{
		id: 8,
		title: "Da dove viene",
		subtitle: "Anno e paese"
	},
	{
		id: 9,
		title: "Come lo guardi",
		subtitle: "Piattaforme e abitudini"
	},
	{
		id: 10,
		title: "Cosa evitare",
		subtitle: "Cose che non vuoi"
	}
];
var W = 400;
var H = 300;
var DIRS = [
	"up",
	"left",
	"right",
	"down"
];
var SLOTS = {
	up: {
		x: 200,
		y: 96
	},
	left: {
		x: 62,
		y: 186
	},
	right: {
		x: 338,
		y: 186
	},
	down: {
		x: 200,
		y: 276
	}
};
var HOME = {
	x: 200,
	y: 168
};
var POSTER_LIFT = 52;
var SALE = {
	up: {
		sprite: "/sprites/cinema-gold.png",
		color: "#f0c43a",
		name: "Aurora"
	},
	left: {
		sprite: "/sprites/cinema-pink.png",
		color: "#e24b6e",
		name: "Rosa"
	},
	right: {
		sprite: "/sprites/cinema-teal.png",
		color: "#3ec9b0",
		name: "Lido"
	},
	down: {
		sprite: "/sprites/cinema-blue.png",
		color: "#7aa6ff",
		name: "Stella"
	}
};
var CACHE = /* @__PURE__ */ new Map();
function sprite(src) {
	let img = CACHE.get(src);
	if (!img) {
		img = new Image();
		img.crossOrigin = "anonymous";
		img.src = src;
		CACHE.set(src, img);
	}
	return img;
}
function PlazaCanvas(props) {
	const wrapRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const propsRef = (0, import_react.useRef)(props);
	propsRef.current = props;
	const aimRef = (0, import_react.useRef)(() => {});
	const [hot, setHot] = (0, import_react.useState)(null);
	const hotRef = (0, import_react.useRef)(setHot);
	hotRef.current = setHot;
	(0, import_react.useEffect)(() => {
		const canvasEl = canvasRef.current;
		const wrapEl = wrapRef.current;
		if (!canvasEl || !wrapEl) return;
		const ctxEl = canvasEl.getContext("2d");
		if (!ctxEl) return;
		const canvas = canvasEl;
		const wrap = wrapEl;
		const ctx = ctxEl;
		let dead = false;
		let raf = 0;
		const keys = /* @__PURE__ */ new Set();
		let swipe = null;
		let reduced = false;
		try {
			reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		} catch {}
		const player = {
			x: HOME.x,
			y: HOME.y,
			dir: "down",
			walking: false,
			frame: 0,
			acc: 0
		};
		let target = null;
		let entering = null;
		let enterT = 0;
		let trauma = 0;
		let bob = 0;
		let last = performance.now();
		let lastIndex = propsRef.current.index;
		let committed = false;
		const particles = [];
		let fxFrame = 0;
		let starPhase = 0;
		const sources = [
			"/sprites/player.png",
			"/sprites/fx.png",
			"/sprites/sky.jpg",
			"/sprites/ground.png",
			"/sprites/prop-lamp.png",
			"/sprites/prop-popcorn.png",
			"/sprites/prop-reels.png",
			...Object.values(SALE).map((s) => s.sprite)
		];
		for (const src of sources) sprite(src);
		function burst(x, y, color, n = 12) {
			const room = 80 - particles.length;
			const count = Math.max(0, Math.min(n, room));
			for (let i = 0; i < count; i++) {
				const a = Math.random() * Math.PI * 2;
				const s = 20 + Math.random() * 70;
				particles.push({
					x,
					y,
					vx: Math.cos(a) * s,
					vy: Math.sin(a) * s - 20,
					life: 0,
					max: .28 + Math.random() * .28,
					color,
					size: 1 + Math.random() * 2
				});
			}
		}
		function dirFromCode(code) {
			if (code === "ArrowUp" || code === "KeyW") return "up";
			if (code === "ArrowDown" || code === "KeyS") return "down";
			if (code === "ArrowLeft" || code === "KeyA") return "left";
			if (code === "ArrowRight" || code === "KeyD") return "right";
			return null;
		}
		function syncHot(dir) {
			hotRef.current(dir);
		}
		function resetPlayer() {
			player.x = HOME.x;
			player.y = HOME.y;
			player.dir = "down";
			player.walking = false;
			player.frame = 0;
			target = null;
			entering = null;
			enterT = 0;
			committed = false;
			trauma = 0;
			syncHot(null);
		}
		function aim(dir) {
			const p = propsRef.current;
			const slot = DIRS.indexOf(dir);
			if (slot < 0 || slot >= p.options.length) {
				blip("skip");
				return;
			}
			if (entering || committed) return;
			if (target === dir && player.walking) return;
			unlockAudio();
			target = dir;
			player.dir = dir;
			player.walking = true;
			syncHot(dir);
			blip("step");
			burst(player.x, player.y + 8, "#ffd84a", 5);
		}
		aimRef.current = aim;
		function commit(dir) {
			if (committed || entering) return;
			entering = dir;
			enterT = 0;
			trauma = Math.min(1, trauma + .4);
			blip("ok");
			burst(SLOTS[dir].x, SLOTS[dir].y - 8, SALE[dir].color, 16);
			burst(SLOTS[dir].x, SLOTS[dir].y - 8, "#ffd84a", 10);
		}
		function finishEnter() {
			if (committed || dead) return;
			const dir = entering;
			entering = null;
			target = null;
			player.walking = false;
			if (!dir) return;
			const opt = propsRef.current.options[DIRS.indexOf(dir)];
			if (!opt) {
				resetPlayer();
				return;
			}
			committed = true;
			propsRef.current.onPick([opt.id]);
		}
		const onKey = (e) => {
			const dir = dirFromCode(e.code);
			if (dir) {
				e.preventDefault();
				keys.add(e.code);
				aim(dir);
			}
			if (e.code === "Escape" || e.code === "Backspace") {
				e.preventDefault();
				propsRef.current.onSkip();
			}
		};
		const onUp = (e) => keys.delete(e.code);
		const onBlur = () => keys.clear();
		const onDown = (e) => {
			if (e.target.closest("[data-dir]")) return;
			swipe = {
				x: e.clientX,
				y: e.clientY
			};
			try {
				wrap.setPointerCapture(e.pointerId);
			} catch {}
		};
		const onMove = (e) => {
			if (!swipe) return;
			const dx = e.clientX - swipe.x;
			const dy = e.clientY - swipe.y;
			if (Math.hypot(dx, dy) < 36) return;
			swipe = null;
			if (Math.abs(dx) > Math.abs(dy)) aim(dx > 0 ? "right" : "left");
			else aim(dy > 0 ? "down" : "up");
		};
		const onPtrUp = (e) => {
			if (!swipe) return;
			const rect = canvas.getBoundingClientRect();
			if (rect.width < 1 || rect.height < 1) {
				swipe = null;
				return;
			}
			const sx = (e.clientX - rect.left) / rect.width * W;
			const sy = (e.clientY - rect.top) / rect.height * H;
			swipe = null;
			let best = null;
			let bestD = 56;
			for (const d of DIRS) {
				const s = SLOTS[d];
				const dist = Math.hypot(sx - s.x, sy - (s.y - 28));
				if (dist < bestD) {
					bestD = dist;
					best = d;
				}
			}
			if (best) aim(best);
		};
		window.addEventListener("keydown", onKey, { capture: true });
		window.addEventListener("keyup", onUp);
		window.addEventListener("blur", onBlur);
		wrap.addEventListener("pointerdown", onDown);
		wrap.addEventListener("pointermove", onMove);
		wrap.addEventListener("pointerup", onPtrUp);
		wrap.addEventListener("pointercancel", () => {
			swipe = null;
		});
		window.__controlsTest = {
			getX: () => player.x,
			getY: () => player.y,
			getYaw: () => {
				return {
					left: .4,
					right: -.4,
					up: 0,
					down: 0
				}[player.dir];
			},
			getSpeed: () => player.walking || Boolean(entering) ? 1 : 0,
			setKeys: (codes) => {
				keys.clear();
				for (const c of codes) {
					keys.add(c);
					const d = dirFromCode(c);
					if (d) aim(d);
				}
			}
		};
		function resize() {
			const r = wrap.getBoundingClientRect();
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			const cssW = Math.max(1, Math.round(r.width));
			const cssH = Math.max(1, Math.round(r.height));
			canvas.style.width = `${cssW}px`;
			canvas.style.height = `${cssH}px`;
			canvas.width = Math.round(cssW * dpr);
			canvas.height = Math.round(cssH * dpr);
			ctx.setTransform(cssW * dpr / W, 0, 0, cssH * dpr / H, 0, 0);
			ctx.imageSmoothingEnabled = false;
		}
		resize();
		const ro = new ResizeObserver(resize);
		ro.observe(wrap);
		function drawSprite(img, sx, sy, sw, sh, dx, dy, dw, dh) {
			if (!img.complete || img.naturalWidth === 0) return;
			ctx.drawImage(img, sx, sy, sw, sh, Math.round(dx), Math.round(dy), dw, dh);
		}
		function roundRect(x, y, w, h, r) {
			const rr = Math.min(r, w / 2, h / 2);
			ctx.beginPath();
			ctx.moveTo(x + rr, y);
			ctx.arcTo(x + w, y, x + w, y + h, rr);
			ctx.arcTo(x + w, y + h, x, y + h, rr);
			ctx.arcTo(x, y + h, x, y, rr);
			ctx.arcTo(x, y, x + w, y, rr);
			ctx.closePath();
		}
		function frame(now) {
			if (dead) return;
			let dt = (now - last) / 1e3;
			last = now;
			if (dt > .1) dt = .1;
			bob += dt;
			starPhase += dt;
			fxFrame += dt * 8;
			trauma = Math.max(0, trauma - dt * 2.2);
			if (propsRef.current.index !== lastIndex) {
				lastIndex = propsRef.current.index;
				resetPlayer();
			}
			const dest = target ? SLOTS[target] : null;
			if (dest && !entering && !committed) {
				const dx = dest.x - player.x;
				const dy = dest.y + 10 - player.y;
				const dist = Math.hypot(dx, dy);
				const spd = 110;
				if (dist < 10) {
					player.x = dest.x;
					player.y = dest.y + 10;
					player.walking = false;
					commit(target);
				} else {
					player.x += dx / dist * spd * dt;
					player.y += dy / dist * spd * dt;
					player.walking = true;
					player.acc += dt * 8;
					if (player.acc > 1) {
						player.acc -= 1;
						player.frame = (player.frame + 1) % 4;
					}
				}
			}
			if (entering) {
				enterT += dt;
				if (enterT > .28) finishEnter();
			}
			for (let i = particles.length - 1; i >= 0; i--) {
				const p = particles[i];
				p.life += dt;
				p.x += p.vx * dt;
				p.y += p.vy * dt;
				p.vy += 80 * dt;
				if (p.life >= p.max) particles.splice(i, 1);
			}
			const shake = trauma * trauma;
			const ox = reduced ? 0 : (Math.random() * 2 - 1) * 5 * shake;
			const oy = reduced ? 0 : (Math.random() * 2 - 1) * 5 * shake;
			ctx.imageSmoothingEnabled = false;
			ctx.clearRect(0, 0, W, H);
			const sky = sprite("/sprites/sky.jpg");
			if (sky.complete && sky.naturalWidth) ctx.drawImage(sky, 0, 0, W, H);
			else {
				ctx.fillStyle = "#1a0820";
				ctx.fillRect(0, 0, W, H);
			}
			ctx.fillStyle = "#ffe7a8";
			for (let i = 0; i < 18; i++) {
				const tw = (Math.sin(starPhase * 3 + i * 1.7) + 1) / 2;
				if (tw < .4) continue;
				ctx.globalAlpha = tw * .8;
				ctx.fillRect((i * 37 + 11) % W, 4 + i * 13 % 36, 1, 1);
			}
			ctx.globalAlpha = 1;
			ctx.save();
			ctx.translate(Math.round(ox), Math.round(oy));
			roundRect(36, 54, 328, 230, 18);
			ctx.fillStyle = "#3a1840";
			ctx.fill();
			ctx.strokeStyle = "#f0c43a";
			ctx.lineWidth = 1.5;
			ctx.stroke();
			const ground = sprite("/sprites/ground.png");
			if (ground.complete && ground.naturalWidth) {
				ctx.save();
				roundRect(40, 58, 320, 222, 16);
				ctx.clip();
				ctx.globalAlpha = .62;
				ctx.drawImage(ground, 28, 50, 344, 236);
				ctx.restore();
			}
			ctx.save();
			roundRect(40, 58, 320, 222, 16);
			ctx.clip();
			for (let y = 62; y < 276; y += 10) for (let x = 44; x < 356; x += 12) {
				const lit = ((x + y) / 8 + Math.floor(bob * 2)) % 7 === 0;
				ctx.fillStyle = lit ? "rgba(240,196,58,0.18)" : "rgba(20,8,24,0.12)";
				ctx.fillRect(x, y, 10, 8);
			}
			ctx.restore();
			ctx.beginPath();
			ctx.ellipse(HOME.x, HOME.y + 10, 28, 10, 0, 0, Math.PI * 2);
			ctx.fillStyle = "rgba(240,196,58,0.16)";
			ctx.fill();
			ctx.strokeStyle = "rgba(240,196,58,0.45)";
			ctx.lineWidth = 1;
			ctx.stroke();
			const opts = propsRef.current.options.slice(0, 4);
			for (let i = 0; i < 4; i++) {
				if (!opts[i]) continue;
				const dir = DIRS[i];
				const slot = SLOTS[dir];
				const sala = SALE[dir];
				const glow = target === dir || entering === dir;
				ctx.strokeStyle = sala.color;
				ctx.globalAlpha = glow ? .7 : .28 + .16 * Math.abs(Math.sin(bob * 3 + i));
				ctx.lineWidth = glow ? 2 : 1.5;
				ctx.beginPath();
				ctx.moveTo(HOME.x, HOME.y);
				ctx.lineTo(slot.x, slot.y);
				ctx.stroke();
				ctx.globalAlpha = 1;
			}
			const lamp = sprite("/sprites/prop-lamp.png");
			const pop = sprite("/sprites/prop-popcorn.png");
			const reels = sprite("/sprites/prop-reels.png");
			const bobY = reduced ? 0 : Math.sin(bob * 2) * 2;
			if (lamp.complete) {
				ctx.drawImage(lamp, 44, 72 + bobY, 26, 26);
				ctx.drawImage(lamp, 330, 72 - bobY, 26, 26);
			}
			if (pop.complete) ctx.drawImage(pop, 48, 232, 28, 28);
			if (reels.complete) ctx.drawImage(reels, 324, 230, 30, 30);
			const playerImg = sprite("/sprites/player.png");
			const fxImg = sprite("/sprites/fx.png");
			const ents = [];
			function drawCinema(dir, i) {
				if (!opts[i]) return;
				const slot = SLOTS[dir];
				const sala = SALE[dir];
				const img = sprite(sala.sprite);
				const bounce = reduced ? 0 : Math.sin(bob * 2.4 + i) * 1.4;
				const glow = target === dir || entering === dir;
				const scale = entering === dir ? 1 + enterT * .22 : glow ? 1.04 : 1;
				const dw = 92 * scale;
				const dh = 88 * scale;
				ents.push({
					y: slot.y,
					z: 1,
					draw: () => {
						if (glow) {
							ctx.fillStyle = sala.color;
							ctx.globalAlpha = .22;
							ctx.beginPath();
							ctx.ellipse(slot.x, slot.y + 8, 30, 8, 0, 0, Math.PI * 2);
							ctx.fill();
							ctx.globalAlpha = 1;
						}
						if (img.complete && img.naturalWidth) ctx.drawImage(img, slot.x - dw / 2, slot.y - dh + bounce, dw, dh);
						else {
							ctx.fillStyle = glow ? sala.color : "#5a2260";
							ctx.fillRect(slot.x - 28, slot.y - 44, 56, 48);
						}
						const mx = slot.x;
						const my = slot.y - dh + bounce + 6;
						ctx.fillStyle = sala.color;
						ctx.globalAlpha = .55 + .45 * Math.abs(Math.sin(bob * 8 + i));
						ctx.fillRect(mx - 28, my, 56, 7);
						ctx.globalAlpha = 1;
						for (let k = 0; k < 7; k++) {
							ctx.fillStyle = Math.sin(bob * 14 + i + k) > 0 ? "#fff6c2" : sala.color;
							ctx.fillRect(mx - 26 + k * 8, my + 1, 5, 5);
						}
					}
				});
			}
			drawCinema("up", 0);
			drawCinema("left", 1);
			drawCinema("right", 2);
			drawCinema("down", 3);
			ents.push({
				y: player.y,
				z: 2,
				draw: () => {
					if (playerImg.complete && playerImg.naturalWidth) {
						const row = player.dir === "down" ? 0 : player.dir === "left" ? 1 : player.dir === "right" ? 2 : 3;
						const col = player.walking ? player.frame : 0;
						if (!(entering && enterT > .16)) {
							const squash = player.walking ? 1 : 1 + Math.sin(bob * 5) * .03;
							drawSprite(playerImg, col * 96, row * 96, 96, 96, player.x - 16, player.y - 28 / squash, 32, 32 * squash);
						}
					} else {
						ctx.fillStyle = "#ff4f8b";
						ctx.fillRect(player.x - 4, player.y - 10, 8, 12);
					}
				}
			});
			ents.sort((a, b) => a.y - b.y || a.z - b.z);
			for (const e of ents) e.draw();
			if (fxImg.complete && fxImg.naturalWidth && (entering || trauma > .2)) {
				const f = Math.floor(fxFrame) % 4;
				const at = entering ? SLOTS[entering] : {
					x: player.x,
					y: player.y
				};
				ctx.drawImage(fxImg, f % 2 * 128, Math.floor(f / 2) * 128, 128, 128, at.x - 22, at.y - 32, 44, 44);
			}
			for (const p of particles) {
				ctx.globalAlpha = 1 - p.life / p.max;
				ctx.fillStyle = p.color;
				ctx.fillRect(Math.round(p.x), Math.round(p.y), p.size, p.size);
			}
			ctx.globalAlpha = 1;
			ctx.restore();
			raf = requestAnimationFrame(frame);
		}
		raf = requestAnimationFrame(frame);
		return () => {
			dead = true;
			cancelAnimationFrame(raf);
			window.removeEventListener("keydown", onKey, { capture: true });
			window.removeEventListener("keyup", onUp);
			window.removeEventListener("blur", onBlur);
			wrap.removeEventListener("pointerdown", onDown);
			wrap.removeEventListener("pointermove", onMove);
			wrap.removeEventListener("pointerup", onPtrUp);
			ro.disconnect();
			delete window.__controlsTest;
		};
	}, []);
	const opts = props.options.slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "px-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [props.chapter, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-subtle",
							children: [
								" ",
								"· ",
								props.index + 1,
								"/",
								props.total
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-2xl italic leading-snug text-fg sm:text-3xl",
						children: props.question
					}),
					props.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: props.hint
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: wrapRef,
				className: "relative mt-4 aspect-[4/3] w-full overflow-hidden rounded-md bg-bg ring-2 ring-accent/35 touch-none",
				style: { imageRendering: "pixelated" },
				"aria-label": "Piazza dei cinema: ogni locandina è una risposta",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: canvasRef,
					className: "block h-full w-full",
					style: { imageRendering: "pixelated" }
				}), DIRS.map((dir, i) => {
					const option = opts[i];
					if (!option) return null;
					const slot = SLOTS[dir];
					const sala = SALE[dir];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Locandina, {
						dir,
						name: sala.name,
						color: sala.color,
						label: option.label,
						hot: hot === dir,
						left: `${slot.x / W * 100}%`,
						top: `${(slot.y - POSTER_LIFT) / H * 100}%`,
						onChoose: () => aimRef.current(dir)
					}, option.id);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-center text-sm leading-relaxed text-subtle",
				children: "Ogni palazzo è un cinema: la locandina è la risposta. Toccala, oppure cammina verso la sala."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: props.onSkip,
				className: "mx-auto mt-1 min-h-11 px-3 text-sm text-muted underline-offset-2 hover:text-fg hover:underline",
				children: "Salta questa domanda"
			})
		]
	});
}
function Locandina({ dir, name, color, label, hot, left, top, onChoose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"data-dir": dir,
		"data-hot": hot ? "true" : "false",
		"aria-label": `Cinema ${name}: ${label}`,
		onPointerDown: (e) => e.stopPropagation(),
		onClick: () => {
			unlockAudio();
			onChoose();
		},
		className: "locandina min-h-11",
		style: {
			left,
			top,
			["--sala"]: color
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "locandina-marquee",
			children: name.toUpperCase()
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "locandina-sheet",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "locandina-title",
				children: label
			})
		})]
	});
}
function QuizView() {
	const index = useQuiz((s) => s.index);
	const mode = useQuiz((s) => s.mode);
	const answers = useQuiz((s) => s.answers);
	const setAnswer = useQuiz((s) => s.setAnswer);
	const platforms = useQuiz((s) => s.platforms);
	const next = useQuiz((s) => s.next);
	const skip = useQuiz((s) => s.skip);
	const finish = useQuiz((s) => s.finish);
	const deck = questionsFor(mode === "short" ? "short" : "quiz");
	const safeIndex = Math.max(0, Math.min(index, deck.length - 1));
	const question = deck[safeIndex];
	const chapter = question ? CHAPTERS.find((c) => c.id === question.ch) : void 0;
	(0, import_react.useEffect)(() => {
		if (index >= deck.length) finish();
	}, [
		index,
		deck.length,
		finish
	]);
	(0, import_react.useEffect)(() => {
		if (!question || question.id !== 81) return;
		if ((answers[81]?.length ?? 0) > 0 || platforms.length === 0) return;
		setAnswer(81, optionIdsForPlatforms(platforms));
	}, [
		question,
		answers,
		platforms,
		setAnswer
	]);
	if (!question || !chapter) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		id: "contenuto",
		className: "mx-auto max-w-xl px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Hai finito le domande."
		})
	});
	const opts = question.opts.slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative min-h-dvh bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			id: "contenuto",
			className: "mx-auto flex min-h-dvh max-w-3xl flex-col px-3 py-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBar, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlazaCanvas, {
					question: question.q,
					hint: question.hint,
					chapter: chapter.title,
					index: safeIndex,
					total: deck.length,
					options: opts,
					onPick: (ids) => {
						setAnswer(question.id, ids);
						if (safeIndex >= deck.length - 1) finish();
						else next();
					},
					onSkip: () => {
						if (safeIndex >= deck.length - 1) finish();
						else skip();
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, {
					format: "banner",
					className: "mt-4"
				})
			]
		})
	});
}
function ShareBar({ card, titles }) {
	const [note, setNote] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-2 sm:flex-row",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "min-h-12",
					onClick: async () => {
						const result = await shareResult(card);
						setNote(result === "copied" ? "Ho copiato testo e link." : result === "shared" ? "Inviato." : "");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), "Mandalo a un amico"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					className: "min-h-12",
					onClick: async () => {
						const ok = await copyShareUrl(card);
						setNote(ok ? "Link copiato." : "Non riesco a copiare il link.");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copia il link"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					className: "min-h-12",
					onClick: async () => {
						try {
							const blob = await drawSharePng(card, titles);
							const href = URL.createObjectURL(blob);
							const a = document.createElement("a");
							a.href = href;
							a.download = "platea.png";
							a.click();
							URL.revokeObjectURL(href);
							setNote("Immagine salvata.");
						} catch {
							setNote("Non sono riuscito a salvare l'immagine.");
						}
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageDown, { className: "size-4" }), "Salva l'immagine"]
				})
			]
		}), note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 flex items-center gap-2 text-sm text-ok",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), note]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-subtle",
			children: "Chi apre il link vede il risultato. Le tue risposte restano solo sul tuo telefono."
		})]
	});
}
function Results() {
	const answers = useQuiz((s) => s.answers);
	const platforms = useQuiz((s) => s.platforms);
	const seenVerdicts = useQuiz((s) => s.seenVerdicts);
	const reset = useQuiz((s) => s.reset);
	const goTo = useQuiz((s) => s.goTo);
	const editPlatforms = useQuiz((s) => s.editPlatforms);
	const mode = useQuiz((s) => s.mode);
	const profile = buildProfile(answers, platforms, seenVerdicts);
	const matches = rankMovies(profile).slice(0, 12);
	const tonight = matches[0];
	const archetype = pickArchetype(profile.vector);
	const axes = topAxes(profile.vector, 6);
	const maxAxis = axes[0]?.value || 1;
	const recipes = searchRecipes(profile, matches);
	const owned = platforms.length ? platforms : profile.flags.platforms ?? [];
	const platformLine = owned.length > 0 ? owned.map((p) => PLATFORM_META[p].label).join(" · ") : "Nessuna piattaforma segnata";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative min-h-dvh",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			id: "contenuto",
			className: "relative z-10 mx-auto max-w-xl px-4 py-8 sm:px-8 sm:py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBar, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "rise-in",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-medium tracking-[0.18em] text-ticket uppercase",
							children: [
								profile.answered,
								" risposte · ",
								CATALOG_SIZE.toLocaleString("it-IT"),
								" film"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 font-display text-4xl italic leading-[1.08] text-fg md:text-5xl",
							children: archetype.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base text-muted",
							children: archetype.line
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareBar, {
							card: {
								a: archetype.name,
								l: archetype.line,
								m: matches.map((item) => item.movie.id),
								n: profile.answered
							},
							titles: matches.map((item) => item.movie.title)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-6 flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						children: platformLine
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						size: "sm",
						className: "min-h-11",
						onClick: editPlatforms,
						children: "Le tue piattaforme"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, {
					format: "banner",
					className: "mt-10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mt-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-4",
						children: axes.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid grid-cols-[7.5rem_1fr] items-center gap-3 sm:grid-cols-[9rem_1fr]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: AXIS_LABEL[a.axis]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "h-2 overflow-hidden bg-raised",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block h-full bg-accent",
									style: { width: `${Math.max(8, a.value / maxAxis * 100)}%` }
								})
							})]
						}, a.axis))
					})
				}),
				tonight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tonight, {
					movie: tonight.movie,
					reasons: tonight.reasons,
					owned
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-12 text-muted",
					children: "Rispondi a qualche domanda, così ti propongo un film."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, {
					format: "feed",
					className: "mt-12"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mt-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "divide-y divide-border border-y border-border",
						children: matches.slice(1).map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MovieRow, {
								movie: m.movie,
								index: i + 2,
								owned
							})
						}, m.movie.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, {
					format: "box",
					className: "mt-12"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mt-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-4",
						children: recipes.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-fg",
							children: r.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
								href: r.justwatch,
								children: "JustWatch"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
								href: r.google,
								children: "Google"
							})]
						})] }, r.label))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "mt-12 flex flex-col gap-3 sm:flex-row",
					children: [mode === "quiz" || mode === "short" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => goTo(0),
						className: "min-h-12",
						children: mode === "short" ? "Rifai le 20 domande" : "Cambia qualche risposta"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						onClick: reset,
						className: "min-h-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Ricomincia da capo"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalFooter, {})
			]
		})
	});
}
function Tonight({ movie, reasons, owned }) {
	const meta = useFilmMeta(movie);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-10 pixel-panel p-5 sm:p-7",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-[0.18em] text-accent uppercase",
			children: "Il film di stasera"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-col gap-5 sm:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
				movie,
				meta,
				size: "hero"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl italic leading-tight text-fg",
						children: movie.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, { movie }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plot, {
							movie,
							meta
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trailer, {
						movie,
						meta
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Availability, {
						movie,
						owned
					}),
					reasons.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-wrap gap-2",
						children: reasons.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-full border border-border px-3 py-1 text-xs text-muted",
							children: r
						}, r))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchRow, {
						movie,
						platforms: owned
					})
				]
			})]
		})]
	});
}
function MovieRow({ movie, index, owned }) {
	const meta = useFilmMeta(movie);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
			movie,
			meta,
			size: "row"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-display text-xl italic text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-3 font-mono text-xs not-italic text-subtle",
							children: index
						}), movie.title]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 font-mono text-xs tabular-nums text-subtle",
						children: movie.year
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, { movie }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plot, {
						movie,
						meta,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Availability, {
					movie,
					owned
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchRow, {
					movie,
					platforms: owned,
					compact: true
				})
			]
		})]
	});
}
function Meta({ movie }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-2 text-sm text-subtle",
		children: [
			movie.year,
			" · ",
			movie.runtime,
			" min",
			movie.director ? ` · ${movie.director}` : "",
			movie.originalTitle && movie.originalTitle !== movie.title ? ` · ${movie.originalTitle}` : ""
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tags, { movie })] });
}
function SearchRow({ movie, platforms, compact }) {
	const links = movieSearchLinks(movie, platforms);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: compact ? "mt-3 flex flex-wrap gap-2" : "mt-6 flex flex-wrap gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
				href: links.justwatch,
				children: "Dove vederlo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
				href: youtubeSearchUrl(movie),
				children: "Trailer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutLink, {
				href: links.google,
				children: "Cerca"
			})
		]
	});
}
function OutLink({ href, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href,
		target: "_blank",
		rel: "noreferrer",
		className: "inline-flex min-h-10 items-center gap-1 rounded-sm border border-border-strong bg-raised px-3 text-xs font-medium text-fg transition-colors duration-150 hover:border-accent",
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-3.5 text-muted" })]
	});
}
var ZONES = [
	{
		id: "like",
		title: "TV",
		hint: "L'ho visto e mi è piaciuto"
	},
	{
		id: "unseen",
		title: "Tavolo",
		hint: "Non l'ho visto"
	},
	{
		id: "dislike",
		title: "Cestino",
		hint: "L'ho visto e non mi è piaciuto"
	}
];
var SPRITE = {
	like: "0 0",
	unseen: "-64px 0",
	dislike: "0 -64px"
};
function SeenView() {
	const round = useQuiz((s) => s.seenRound);
	const trios = useQuiz((s) => s.seenTrios);
	const verdicts = useQuiz((s) => s.seenVerdicts);
	const placeSeen = useQuiz((s) => s.placeSeen);
	const unplaceSeen = useQuiz((s) => s.unplaceSeen);
	const nextSeenRound = useQuiz((s) => s.nextSeenRound);
	(0, import_react.useEffect)(() => {
		if (trios.length === 0) useQuiz.setState({
			seenTrios: pickSeenTrios(),
			seenRound: 0
		});
	}, [trios.length]);
	const ids = trios[round] ?? [];
	const movies = (0, import_react.useMemo)(() => ids.map((id) => movieById(id)).filter((m) => Boolean(m)), [ids]);
	const placed = movies.filter((m) => verdicts[m.id]).length;
	const allIn = movies.length > 0 && placed === movies.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "mx-auto flex min-h-dvh max-w-xl flex-col px-4 py-4 sm:px-6 sm:py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Turno ",
					Math.min(round + 1, 10),
					" di 10"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl italic text-fg",
				children: "Hai già visto questi film?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-base leading-relaxed text-muted",
				children: "Tre titoli. Trascinali, oppure tocca il film e poi dove va: TV se ti è piaciuto, tavolo se non l'hai visto, cestino se non ti è piaciuto."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortBoard, {
				movies,
				verdicts,
				onPlace: (id, v) => {
					unlockAudio();
					blip(v === "like" ? "ok" : v === "dislike" ? "skip" : "swipe");
					placeSeen(id, v);
				},
				onUnplace: unplaceSeen
			}, round),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-subtle",
				children: allIn ? "Ok, tutti e tre." : `${placed} di ${movies.length} a posto`
			}),
			allIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "mt-4 min-h-12",
				onClick: nextSeenRound,
				children: round >= 9 ? "Vedi i consigli" : "Prossimo turno"
			}) : null
		]
	});
}
function SortBoard({ movies, verdicts, onPlace, onUnplace }) {
	const boardRef = (0, import_react.useRef)(null);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const dragRef = (0, import_react.useRef)(null);
	const [ghost, setGhost] = (0, import_react.useState)(null);
	const hand = movies.filter((m) => !verdicts[m.id]);
	const hitZone = (clientX, clientY) => {
		const root = boardRef.current;
		if (!root) return null;
		const nodes = root.querySelectorAll("[data-zone]");
		for (const node of nodes) {
			const r = node.getBoundingClientRect();
			if (clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom) return node.dataset.zone;
		}
		return null;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: boardRef,
		className: "mt-5 flex flex-1 flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: ZONES.map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropZone, {
					zone: z,
					hot: picked !== null,
					movies: movies.filter((m) => verdicts[m.id] === z.id),
					onClick: () => {
						if (!picked) return;
						onPlace(picked, z.id);
						setPicked(null);
					},
					onReturn: onUnplace
				}, z.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [hand.map((movie) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilmChip, {
					movie,
					selected: picked === movie.id,
					hidden: ghost?.id === movie.id,
					onPointerDown: (e) => {
						unlockAudio();
						const el = e.currentTarget;
						try {
							el.setPointerCapture(e.pointerId);
						} catch {}
						setPicked(movie.id);
						dragRef.current = {
							id: movie.id,
							ox: 56,
							oy: 40
						};
						setGhost({
							id: movie.id,
							x: e.clientX,
							y: e.clientY
						});
					},
					onPointerMove: (e) => {
						if (dragRef.current?.id !== movie.id) return;
						setGhost({
							id: movie.id,
							x: e.clientX,
							y: e.clientY
						});
					},
					onPointerUp: (e) => {
						if (dragRef.current?.id !== movie.id) return;
						const zone = hitZone(e.clientX, e.clientY);
						dragRef.current = null;
						setGhost(null);
						if (zone) {
							onPlace(movie.id, zone);
							setPicked(null);
						}
					}
				}, movie.id)), hand.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "col-span-3 py-4 text-center text-sm text-muted",
					children: "Ok, tutti e tre."
				}) : null]
			}),
			ghost ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed z-40 w-28 rounded-md border border-accent bg-surface p-2 opacity-90 shadow-lg",
				style: {
					left: ghost.x - 56,
					top: ghost.y - 40
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "line-clamp-2 text-xs text-fg",
					children: movies.find((m) => m.id === ghost.id)?.title
				})
			}) : null
		]
	});
}
function DropZone({ zone, hot, movies, onClick, onReturn }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-zone": zone.id,
		onClick,
		onKeyDown: (e) => {
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault();
				onClick();
			}
		},
		role: "button",
		tabIndex: 0,
		className: cn("min-h-40 rounded-md border px-2 py-3 text-left", hot ? "border-accent bg-raised" : "border-border bg-surface"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mx-auto mb-2 block size-16",
				style: {
					backgroundImage: "url(/sprites/room.png)",
					backgroundRepeat: "no-repeat",
					backgroundSize: "128px 128px",
					backgroundPosition: SPRITE[zone.id],
					imageRendering: "pixelated"
				},
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm font-medium text-fg",
				children: zone.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-center text-xs leading-snug text-muted",
				children: zone.hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-1",
				children: movies.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: (e) => {
						e.stopPropagation();
						onReturn(m.id);
					},
					className: "block w-full truncate rounded-sm bg-raised px-1.5 py-1 text-left text-xs text-fg",
					children: m.title
				}) }, m.id))
			})
		]
	});
}
function FilmChip({ movie, selected, hidden, onPointerDown, onPointerMove, onPointerUp }) {
	const meta = useFilmMeta(movie);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onPointerDown,
		onPointerMove,
		onPointerUp,
		onPointerCancel: onPointerUp,
		className: cn("touch-none rounded-md border bg-surface p-2 text-left", selected ? "border-accent" : "border-border", hidden ? "opacity-40" : ""),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
				movie,
				meta,
				size: "row"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 line-clamp-2 text-sm font-medium leading-snug text-fg",
				children: movie.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-0.5 text-xs text-subtle",
				children: [movie.year, movie.director ? ` · ${movie.director}` : ""]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tags, {
				movie,
				compact: true,
				linked: false
			})
		]
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const phase = useQuiz((s) => s.phase);
	const consent = useAds((s) => s.consent);
	const ageOk = useLegal((s) => s.ageOk);
	(0, import_react.useEffect)(() => {
		const done = () => {
			if (useQuiz.persist.hasHydrated() && useAds.persist.hasHydrated() && useLegal.persist.hasHydrated()) setReady(true);
		};
		const u1 = useQuiz.persist.onFinishHydration(done);
		const u2 = useAds.persist.onFinishHydration(done);
		const u3 = useLegal.persist.onFinishHydration(done);
		done();
		return () => {
			u1();
			u2();
			u3();
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-dvh bg-bg" });
	if (consent !== "all" || !ageOk || phase === "intro") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Intro, {});
	if (phase === "platforms") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Platforms, {});
	if (phase === "quiz") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizView, {});
	if (phase === "seen") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeenView, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {});
}
//#endregion
export { Home as component };
