import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as useAds, i as LEGAL, w as useLegal } from "./router-DEhEfwv_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/must-consent-ChFSqNr8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MustConsent({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	const consent = useAds((s) => s.consent);
	const ageOk = useLegal((s) => s.ageOk);
	const setAge = useLegal((s) => s.setAge);
	(0, import_react.useEffect)(() => {
		const done = () => {
			if (useAds.persist.hasHydrated() && useLegal.persist.hasHydrated()) setReady(true);
		};
		const a = useAds.persist.onFinishHydration(done);
		const b = useLegal.persist.onFinishHydration(done);
		done();
		return () => {
			a();
			b();
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-dvh bg-bg" });
	if (consent !== "all" || !ageOk) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "mx-auto flex min-h-dvh max-w-xl flex-col px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-[0.22em] text-ticket uppercase",
				children: "Platea"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl italic text-fg",
				children: "Prima una cosa"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-base leading-relaxed text-muted",
				children: [
					"Per vedere questa pagina accetta gli annunci (il riquadro in basso) e conferma di avere almeno ",
					LEGAL.ageMin,
					" anni."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-6 flex items-start gap-3 text-sm leading-relaxed text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "mt-1 size-4 shrink-0 accent-accent",
					checked: ageOk,
					onChange: (e) => setAge(e.target.checked)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Ho almeno ",
					LEGAL.ageMin,
					" anni."
				] })]
			})
		]
	});
	return children;
}
//#endregion
export { MustConsent as t };
