import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useAds } from "./router-DAzBTxrJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/legal-footer-EkpRMsjk.js
var import_jsx_runtime = require_jsx_runtime();
/** Dati del titolare: completali prima di una pubblicazione con dominio e AdSense. */
var LEGAL = {
	appName: "Platea",
	ageMin: 16,
	controllerName: "",
	controllerEmail: "",
	jurisdiction: "Italia",
	lastUpdated: "7 settembre 2026",
	supervisory: "Garante per la protezione dei dati personali — Piazza Venezia 11, 00187 Roma — https://www.garanteprivacy.it"
};
function controllerLabel() {
	return LEGAL.controllerName.trim() || "l'editore che pubblica questa copia di Platea";
}
var LINKS = [
	{
		to: "/privacy",
		label: "Privacy"
	},
	{
		to: "/cookie",
		label: "Cookie"
	},
	{
		to: "/termini",
		label: "Termini"
	},
	{
		to: "/accessibilita",
		label: "Accessibilità"
	}
];
function LegalFooter() {
	const consent = useAds((s) => s.consent);
	const resetConsent = useAds((s) => s.resetConsent);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		"aria-label": "Informazioni legali",
		className: "mt-10 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-border pt-5 text-xs text-subtle",
		children: [LINKS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: l.to,
			className: "min-h-11 inline-flex items-center underline-offset-2 hover:text-muted hover:underline",
			children: l.label
		}, l.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: resetConsent,
			className: "min-h-11 inline-flex items-center underline-offset-2 hover:text-muted hover:underline",
			children: consent === "unknown" ? "Scegli i cookie" : "Gestisci i cookie"
		})]
	});
}
//#endregion
export { LegalFooter as n, controllerLabel as r, LEGAL as t };
