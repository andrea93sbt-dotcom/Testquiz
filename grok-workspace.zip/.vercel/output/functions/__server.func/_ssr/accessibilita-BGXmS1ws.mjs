import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as LEGAL } from "./router-DEhEfwv_.mjs";
import { t as LegalPage } from "./legal-page-4iKQo5OE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/accessibilita-BGXmS1ws.js
var import_jsx_runtime = require_jsx_runtime();
function A11yPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Accessibilità",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Platea è pensata per essere usabile, in linea con i principi della Direttiva (UE) 2019/882 e delle WCAG 2.2 livello AA, per quanto applicabile a un quiz sul web." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Cosa c'è" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Lingua della pagina dichiarata (italiano)." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Contrasto alto su fondo scuro." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Aree cliccabili di almeno 44px, navigazione da tastiera." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stati di focus visibili; rispetto di «prefers-reduced-motion»." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Finestra di consenso con titolo e testo alternativo." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Puoi saltare le domande. Gli annunci restano accesi per usare l'app." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Limiti noti" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Il quiz completo è lungo: puoi salvare in locale e uscire dopo venti risposte. I siti di terzi aperti dai link (JustWatch, piattaforme) hanno la loro accessibilità, fuori dal nostro controllo." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Segnalazioni" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				LEGAL.controllerEmail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"Scrivi a ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `mailto:${LEGAL.controllerEmail}`,
						children: LEGAL.controllerEmail
					}),
					"."
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "L'editore deve pubblicare un recapito in questa pagina." }),
				" ",
				"In Italia puoi anche rivolgerti all'AgID o all'autorità competente in materia di accessibilità."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "Torna a Platea"
			}) })
		]
	});
}
//#endregion
export { A11yPage as component };
