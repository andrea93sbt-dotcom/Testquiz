import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useQuiz, o as Button, r as Route$4, y as movieById } from "./router-DEhEfwv_.mjs";
import { t as LegalFooter } from "./legal-footer-V7DmZbK1.mjs";
import { n as decodeShare } from "./share-Bk2LE1Z7.mjs";
import { t as MustConsent } from "./must-consent-ChFSqNr8.mjs";
import { a as Plot, h as useFilmMeta, i as Availability, n as AdSlot, o as Poster, r as AppBar, s as Tags } from "./film-card-BRhH8_dR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/condividi-KY5zhV_M.js
var import_jsx_runtime = require_jsx_runtime();
function CondividiRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MustConsent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CondividiPage, {}) });
}
function CondividiPage() {
	const { p } = Route$4.useSearch();
	const owned = useQuiz((s) => s.platforms);
	const card = p ? decodeShare(p) : null;
	const movies = card ? card.m.map((id) => movieById(id)).filter((m) => Boolean(m)) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "mx-auto min-h-dvh max-w-xl px-4 py-8 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBar, {}),
			!card || movies.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl italic text-fg",
					children: "Questo link non funziona."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: "Fai il quiz e poi condividilo di nuovo."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-6 min-h-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						children: "Vai all'inizio"
					})
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-medium tracking-[0.18em] text-ticket uppercase",
					children: [
						"Il risultato di un amico · ",
						card.n,
						" risposte"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-4xl italic leading-tight text-fg",
					children: card.a
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-base text-muted",
					children: card.l
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-6 min-h-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						children: "Fai anche tu il quiz"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, {
					format: "banner",
					className: "mt-10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-10 divide-y divide-border border-y border-border",
					children: movies.map((movie, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "py-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SharedRow, {
							movie,
							index: i + 1,
							owned
						})
					}, movie.id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalFooter, {})
			})
		]
	});
}
function SharedRow({ movie, index, owned }) {
	const meta = useFilmMeta(movie);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
			movie,
			meta,
			size: index === 1 ? "hero" : "row"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl italic text-fg",
					children: movie.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-subtle",
					children: [
						movie.year,
						" · ",
						movie.runtime,
						" min",
						movie.director ? ` · ${movie.director}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tags, {
					movie,
					compact: index > 1
				}),
				index === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plot, {
						movie,
						meta,
						compact: true
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Availability, {
					movie,
					owned
				})
			]
		})]
	});
}
//#endregion
export { CondividiRoute as component };
