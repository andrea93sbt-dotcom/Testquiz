import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as wipeLocalData, a as controllerLabel, i as LEGAL, o as Button } from "./router-DEhEfwv_.mjs";
import { t as LegalPage } from "./legal-page-4iKQo5OE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-yO49guk8.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	const who = controllerLabel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Privacy",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Qui spieghiamo che dati usa Platea, come previsto dagli articoli 13 e 14 del GDPR e del d.lgs. 196/2003. Platea è un quiz sui film che gira nel tuo browser." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "1. Chi è il titolare" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Il titolare è ",
				who,
				".",
				LEGAL.controllerEmail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					" ",
					"Recapito:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `mailto:${LEGAL.controllerEmail}`,
						children: LEGAL.controllerEmail
					}),
					"."
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" ", "L'editore deve indicare nome, recapito e, se tenuta, la partita IVA in questa pagina prima di una pubblicazione commerciale."] })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "2. Che dati restano, e dove" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Non c'è un account. Non mandiamo le tue risposte a un nostro server. Restano solo su questo telefono o computer:" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "le risposte al quiz e le piattaforme che hai segnato;" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "la scelta sugli annunci e la conferma dell'età;" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "se accetti gli annunci, Google può trattare identificatori, IP approssimato e dati di navigazione, secondo la sua informativa." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "nei risultati il browser può chiedere a Wikipedia locandina e trama, e a Wikidata l'identificativo del trailer YouTube (titolo e codice IMDb, non le tue risposte). Se avvii il trailer, YouTube può trattare dati di riproduzione secondo la sua informativa." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Non trattiamo dati sulla salute o sull'orientamento. Non profiliamo i tuoi gusti fuori da questo dispositivo." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "3. Perché li usiamo" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Per farti il quiz e i consigli (art. 6.1.b GDPR: è il servizio che hai chiesto)." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Per ricordare la tua scelta sugli annunci (art. 6.1.c / 6.1.f GDPR e art. 122 del Codice Privacy)." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Per la pubblicità di terzi, solo se dici di sì (art. 6.1.a GDPR e direttiva ePrivacy). Puoi ritirare il consenso in qualsiasi momento, con la stessa facilità con cui l'hai dato." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "4. Dati fuori dall'Europa" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Il quiz in sé non manda dati all'estero. Se accetti gli annunci, Google LLC (Stati Uniti) può trattare dati. Google aderisce al Data Privacy Framework UE-USA e usa clausole contrattuali tipo. Senza consenso, lo script di AdSense non viene caricato." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "5. Per quanto tempo" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I dati sul dispositivo restano finché non li cancelli, non pulisci il browser o non usi il pulsante sotto. Google conserva i propri dati secondo i suoi termini." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "6. I tuoi diritti" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Puoi chiedere accesso, correzione, cancellazione, limitazione, opposizione, portabilità, revoca del consenso, e fare reclamo all'autorità. Per i dati che stanno solo sul dispositivo, la cancellazione è immediata:" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				className: "min-h-11",
				onClick: wipeLocalData,
				children: "Cancella i dati su questo dispositivo"
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Reclamo: ",
				LEGAL.supervisory,
				". Puoi anche rivolgerti all'autorità del tuo Paese UE."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "7. Minori" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Il servizio è per chi ha almeno ",
				LEGAL.ageMin,
				" anni (pubblicità inclusa). Non è per chi ha meno di 16 anni."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "8. Cookie" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Il dettaglio è nella ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/cookie",
					children: "pagina sui cookie"
				}),
				"."
			] })
		]
	});
}
//#endregion
export { PrivacyPage as component };
