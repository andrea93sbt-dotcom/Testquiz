import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as controllerLabel, i as LEGAL } from "./router-DEhEfwv_.mjs";
import { t as LegalPage } from "./legal-page-4iKQo5OE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/termini-DfZDngFd.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LegalPage, {
		title: "Termini di utilizzo",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Usando Platea accetti questi termini. Se non li accetti, non usare l'app. Il servizio è per chi ha almeno ",
				LEGAL.ageMin,
				" anni."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "1. Cos'è Platea" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Un quiz gratuito per consigliare un film. Non è il catalogo ufficiale di Netflix, Prime Video o altre piattaforme. I link di ricerca aprono siti di altri. I film in streaming cambiano senza preavviso." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "2. Chi lo pubblica" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Il servizio è pubblicato da ",
				controllerLabel(),
				"."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "3. Diritti sui film" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Marchi, titoli e opere citati appartengono ai rispettivi titolari. Platea non rivendica diritti sui film. Li nominiamo per indicarti una possibile visione. Non offriamo copie né streaming. Il catalogo di 5000 titoli usa titolo (in italiano se Wikidata lo ha), anno, durata, genere, paese, regia, interpreti e argomenti da fonti pubbliche (dataset IMDb e Wikidata). Locandine e trame, se ci sono, arrivano da Wikipedia (licenza CC BY-SA). I link “dove si vede” aprono JustWatch: non è un catalogo ufficiale delle piattaforme." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "4. Pubblicità" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Gli annunci, se ci sono, sono di terzi e sono etichettati come tali (Regolamento UE 2022/2065, DSA). Non sono un consiglio di Platea." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "5. Nessuna garanzia" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I consigli sono un confronto tra le tue risposte e il catalogo, non un parere professionale. Nei limiti di legge non rispondiamo di errori del catalogo, di interruzioni o di contenuti aperti tramite link esterni (JustWatch, Google, piattaforme)." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "6. Acquisti" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nessun acquisto dentro l'app. Nessun abbonamento a Platea. Non pre-selezioniamo caselle sul consenso. I prezzi di terzi, se compaiono in un annuncio, sono responsabilità dell'inserzionista." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "7. Legge e foro" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Si applica il diritto ",
				LEGAL.jurisdiction === "Italia" ? "italiano" : LEGAL.jurisdiction,
				" e, per i consumatori UE, le norme inderogabili del Paese di residenza (Reg. 1215/2012, direttiva 2011/83/UE)."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/privacy",
					children: "Privacy"
				}),
				" · ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/cookie",
					children: "Cookie"
				})
			] })
		]
	});
}
//#endregion
export { TermsPage as component };
