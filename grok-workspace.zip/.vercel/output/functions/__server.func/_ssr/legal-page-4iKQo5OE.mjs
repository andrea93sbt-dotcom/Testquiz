import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as LEGAL } from "./router-DEhEfwv_.mjs";
import { t as LegalFooter } from "./legal-footer-V7DmZbK1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/legal-page-4iKQo5OE.js
var import_jsx_runtime = require_jsx_runtime();
function LegalPage({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "contenuto",
		className: "mx-auto max-w-2xl px-5 py-10 sm:px-8 sm:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium tracking-[0.22em] text-muted uppercase",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-fg",
						children: "Platea"
					}),
					" · ",
					LEGAL.lastUpdated
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-3xl italic leading-tight text-fg md:text-4xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "legal-prose mt-8 space-y-4 text-sm leading-relaxed text-muted [&_a]:text-fg [&_a]:underline [&_a]:underline-offset-2 [&_h2]:mt-8 [&_h2]:font-display [&_h2]:text-xl [&_h2]:italic [&_h2]:text-fg [&_ul]:list-disc [&_ul]:space-y-1 [&_ul]:pl-5",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalFooter, {})
		]
	});
}
//#endregion
export { LegalPage as t };
