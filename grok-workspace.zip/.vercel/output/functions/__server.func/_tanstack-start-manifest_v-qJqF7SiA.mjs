//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-qJqF7SiA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/accessibilita",
			"/cookie",
			"/privacy",
			"/termini"
		],
		preloads: ["/assets/index-BbL3Fq1N.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BbL3Fq1N.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CDNhneOg.js",
			"/assets/legal-footer-CsvqtX9f.js",
			"/assets/legal-store-CkHdJNzS.js"
		]
	},
	"/accessibilita": {
		filePath: "/workspace/src/routes/accessibilita.tsx",
		children: void 0,
		preloads: [
			"/assets/accessibilita-By_9oHzK.js",
			"/assets/legal-footer-CsvqtX9f.js",
			"/assets/legal-page-Chmgf2Ku.js"
		]
	},
	"/cookie": {
		filePath: "/workspace/src/routes/cookie.tsx",
		children: void 0,
		preloads: ["/assets/cookie-CsUxg8O4.js", "/assets/legal-page-Chmgf2Ku.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-CBCIfH1V.js",
			"/assets/legal-footer-CsvqtX9f.js",
			"/assets/legal-page-Chmgf2Ku.js",
			"/assets/legal-store-CkHdJNzS.js"
		]
	},
	"/termini": {
		filePath: "/workspace/src/routes/termini.tsx",
		children: void 0,
		preloads: [
			"/assets/termini-Bf8_bfGu.js",
			"/assets/legal-footer-CsvqtX9f.js",
			"/assets/legal-page-Chmgf2Ku.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
